
import React, { useState, useEffect, useMemo } from 'react';
import { ArrowLeft, Copy, Check, FileText, Trash2, Settings, ListFilter } from 'lucide-react';
import { ExtractedData, Page6State } from '../types';

interface PageBOMProps {
    data: ExtractedData | null;
    page6State: Page6State;
    windingNames: string[];
    onBack: () => void;
    windingCount: number;
}

// MROUND Helper
const mround = (val: number, multiple: number) => {
    if (!multiple) return val;
    return Math.round(val / multiple) * multiple;
};

// Ceiling Helper
const ceiling = (val: number, multiple: number) => {
    if (!multiple) return val;
    return Math.ceil(val / multiple) * multiple;
};

// Floor Helper
const floor = (val: number, multiple: number) => {
    if (!multiple) return val;
    return Math.floor(val / multiple) * multiple;
};

// Apply Rounding Helper
const applyRounding = (val: number, mode: 'C' | 'F' | 'M') => {
    switch (mode) {
        case 'C': return ceiling(val, 0.0625);
        case 'F': return floor(val, 0.0625);
        case 'M': return mround(val, 0.0625);
        default: return val;
    }
};

const PageBOM: React.FC<PageBOMProps> = ({ data, page6State, windingNames, onBack, windingCount }) => {
    const [copySuccess, setCopySuccess] = useState(false);
    const [bomRows, setBomRows] = useState<any[]>([]);
    // Explicitly type `deletedRowIndices` as `Set<number>`
    const [deletedRowIndices, setDeletedRowIndices] = useState<Set<number>>(() => new Set());

    // State for Custom Winding Designations (LV, HV, etc.)
    const [customDesignations, setCustomDesignations] = useState<string[]>(() => {
        if (windingCount === 2) return ['LV', 'HV'];
        if (windingCount === 3) return ['LV1', 'LV2', 'HV'];
        return Array.from({length: windingCount}, (_, i) => `W${i+1}`);
    });

    // State for Item Number Bases
    const [itemBases, setItemBases] = useState({
        start: 8020, // For Tubes/Sticks
        ser: 8035,
        ks: 8040,
        angleSector: 8045,
        angleCap: 8050,
        idSeal: 8055,
        odSeal: 8060,
        headSheet: 8070
    });

    // Update designations if winding count changes
    useEffect(() => {
        setCustomDesignations(prev => {
            if (prev.length === windingCount) return prev;
            if (windingCount === 2) return ['LV', 'HV'];
            if (windingCount === 3) return ['LV1', 'LV2', 'HV'];
            return Array.from({length: windingCount}, (_, i) => `W${i+1}`);
        });
    }, [windingCount]);

    const handleDesignationChange = (index: number, value: string) => {
        const newDesignations = [...customDesignations];
        newDesignations[index] = value;
        setCustomDesignations(newDesignations);
    };

    const handleBaseChange = (key: keyof typeof itemBases, value: number) => {
        setItemBases(prev => ({ ...prev, [key]: value }));
    };

    // 1. Re-calculate Stack Data including Height H logic
    const processedStack = useMemo(() => {
        const { items, baseOD, tubeTolerance } = page6State;
        let currentOD = ceiling(baseOD, 0.0625) + 0.5;

        const wdgSpace = data?.brackets.wdgSpace || 0;
        const topDist = data?.brackets.top || 0;
        const ks1 = data?.wdg1.ksCircle || 0;
        const ks2 = data?.wdg2.ksCircle || 0;
        const ks3 = data?.wdg3.ksCircle || 0;

        return items.map((item, index) => {
            const calculatedID = currentOD;
            let calculatedOD = calculatedID + (item.thk * 2);
            
            // Apply Rounding if set
            if (item.roundingMode === 'M') calculatedOD = mround(calculatedOD, 0.0625);
            else if (item.roundingMode === 'F') calculatedOD = floor(calculatedOD, 0.0625);
            else if (item.roundingMode === 'C') calculatedOD = ceiling(calculatedOD, 0.0625);

            const tubeListID = mround(calculatedID, 0.0625);
            const calculatedL = mround((item.thk + tubeListID) * Math.PI, 0.0625) + 4;
            
            // --- HEIGHT CALCULATION LOGIC ---
            let calculatedH = wdgSpace;
            const lowerName = item.name.toLowerCase();
            if (lowerName.includes('core tube')) {
                calculatedH = (wdgSpace + topDist) - tubeTolerance;
            } else if (lowerName.includes('major 1')) {
                if (ks1 > 0 && ks1 === ks2) {
                    calculatedH = wdgSpace - 0.5;
                } else {
                    calculatedH = wdgSpace;
                }
            } else if (lowerName.includes('major 2')) {
                if (ks2 > 0 && ks2 === ks3) {
                    calculatedH = wdgSpace - 0.5;
                } else {
                    calculatedH = wdgSpace;
                }
            } else if (lowerName.includes('major')) {
                if (ks1 > 0 && ks1 === ks2) {
                    calculatedH = wdgSpace - 0.5;
                } else {
                    calculatedH = wdgSpace;
                }
            } else if (lowerName.includes('cover')) {
                calculatedH = wdgSpace;
            }
            // -------------------------------
            
            currentOD = calculatedOD;
            return { ...item, calculatedID, calculatedOD, tubeListID, calculatedL, calculatedH };
        });
    }, [page6State, data]);

    // Helper to calculate Head Sheet values (duplicated from Page6.tsx)
    const getHeadSheetValues = useMemo(() => {
        if (!data || !page6State.headSheet) return { a: 0, b: 0, c: 0, e: 0, f: 0, g: 0 };
        
        const { headSheet } = page6State;
        const outmostWdgKey = `wdg${windingCount}` as 'wdg1' | 'wdg2' | 'wdg3';
        const outmostWdg = data[outmostWdgKey];
        
        // A = CEILING(Outmost ID, 0.0625)
        const outmostId = parseFloat(String(outmostWdg?.id || '0'));
        const a = ceiling(outmostId, 0.0625);
        
        // B = MROUND(Outmost OD + 4, 0.0625)
        const outmostOd = parseFloat(String(outmostWdg?.od || '0'));
        const b = mround(outmostOd + 4, 0.0625);
        
        // C = Leg Center - 0.75
        const legCenter = parseFloat(data.core.legCenter || '0');
        const c = legCenter > 0 ? legCenter - 0.75 : 0;
        
        // D is input from page6State.headSheet.d
        const d = headSheet.d;
        
        // E = C + 2*D
        const e = c + 2 * d;
        
        // F = MROUND(C / 4, 0.0625)
        const f = mround(c / 4, 0.0625);
        
        // G = F + 6
        const g = f + 6;
        
        return { a, b, c, e, f, g };
    }, [data, page6State.headSheet, windingCount]);

    // 2. Generate BOM Rows
    useEffect(() => {
        if (!data) return;

        const tubeRows: any[] = [];
        const stickRows: any[] = [];
        const serRows: any[] = [];
        const ksRows: any[] = [];
        const asRows: any[] = [];
        const acRows: any[] = [];
        const idSealRows: any[] = [];
        const odSealRows: any[] = [];
        const headSheetRows: any[] = [];

        const windingIndices = processedStack.map((it, idx) => it.type === 'winding' ? idx : -1).filter(i => i !== -1);
        
        const getAssociatedWindingIdx = (index: number) => {
            let prevWdgIdx = -1;
            let nextWdgIdx = -1;
            for (let i = windingIndices.length - 1; i >= 0; i--) {
                if (windingIndices[i] < index) { prevWdgIdx = windingIndices[i]; break; }
            }
            for (let i = 0; i < windingIndices.length; i++) {
                if (windingIndices[i] > index) { nextWdgIdx = windingIndices[i]; break; }
            }
            if (nextWdgIdx !== -1 && (prevWdgIdx === -1 || (nextWdgIdx - index) < (index - prevWdgIdx))) return windingIndices.indexOf(nextWdgIdx);
            if (prevWdgIdx !== -1) return windingIndices.indexOf(prevWdgIdx);
            return -1;
        };
        
        const getWindingDesignation = (idx: number) => customDesignations[idx] || `W${idx+1}`;

        const getPartNumber = (item: any, idx: number, vendor: string) => {
             const associatedIdx = getAssociatedWindingIdx(idx);
             if (associatedIdx === -1) return '-';
             
             const key = `wdg${associatedIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
             const height = parseFloat(String(data[key]?.wireSpaceMech || '0'));
             const isLong = height > 83;
             
             if (vendor === 'ENPAY') {
                 if (Math.abs(item.thk - 0.236) < 0.02) return isLong ? '1211860T1' : '1211860T';
                 if (Math.abs(item.thk - 0.315) < 0.02) return isLong ? '1211863T1' : '1211863T';
                 if (Math.abs(item.thk - 0.394) < 0.02) return isLong ? '1211865T1' : '1211865T';
             } else {
                 if (Math.abs(item.thk - 0.236) < 0.02) return isLong ? '121186012' : '121186011';
                 if (Math.abs(item.thk - 0.315) < 0.02) return isLong ? '121186312' : '121186311';
                 if (Math.abs(item.thk - 0.394) < 0.02) return isLong ? '121186512' : '121186511';
             }
             return `12${getWindingDesignation(associatedIdx)}`;
        };

        // --- 1. Process Tubes and Sticks ---
        processedStack.forEach((item, idx) => {
            if (item.isTube && item.thk > 0) {
                 tubeRows.push({
                     group: 'tube',
                     vtcPn: '12CY', qty: 3, desc: '', partDes: item.name,
                     length: item.calculatedL.toFixed(4), width: item.calculatedH.toFixed(4), height: item.thk.toFixed(3), sheetNo: ''
                 });
            }
            
            const nameLower = item.name.toLowerCase();
            if (nameLower.includes('duct') || nameLower.includes('stk') || nameLower.includes('winding stick')) {
                 const associatedIdx = getAssociatedWindingIdx(idx);
                 let hasLock = false;
                 let nextWdgItemIdx = -1;
                 for (let i = 0; i < windingIndices.length; i++) {
                     if (windingIndices[i] > idx) { nextWdgItemIdx = windingIndices[i]; break; }
                 }
                 if (nextWdgItemIdx !== -1 && (nextWdgItemIdx - idx) === 1) {
                     hasLock = true;
                 }

                 let wdgIdxForKs = associatedIdx;
                 if (hasLock) {
                      const nextWdgOrderIdx = windingIndices.indexOf(nextWdgItemIdx);
                      if (nextWdgOrderIdx !== -1) wdgIdxForKs = nextWdgOrderIdx;
                 }
                 
                 const wdgKey = wdgIdxForKs !== -1 ? `wdg${wdgIdxForKs+1}` : null;
                 const ksWidth = wdgKey ? (data[wdgKey as any]?.ksWidth || 0) : 0;
                 const ksCircle = wdgKey ? parseFloat(String(data[wdgKey as any]?.ksCircle || '0')) : 0;
                 const radialBuild = wdgKey ? parseFloat(String(data[wdgKey as any]?.radial || '0')) : 0;
                 const wDesignation = wdgIdxForKs !== -1 ? getWindingDesignation(wdgIdxForKs) : 'UNK';

                 if (hasLock) {
                     const isOutermostOfPair = wdgIdxForKs === windingCount - 1;
                     const lockPartNo = isOutermostOfPair ? '12HS' : '12LS';
                     stickRows.push({
                         group: 'stick', vtcPn: lockPartNo, qty: (ksCircle * 3).toFixed(0), desc: '',
                         partDes: `${wDesignation} LOCK STICKS`, length: radialBuild.toFixed(3),
                         width: ksWidth, height: item.thk.toFixed(3), sheetNo: ''
                     });
                 }

                 const plainQty = hasLock ? (ksCircle * 3) : (ksCircle * 2 * 3);
                 if (plainQty > 0) {
                     stickRows.push({
                         group: 'stick', vtcPn: getPartNumber(item, idx, page6State.selectedVendor), qty: plainQty.toFixed(0), desc: '',
                         partDes: `${wDesignation} PLAIN STICKS`, length: radialBuild.toFixed(3),
                         width: ksWidth, height: item.thk.toFixed(3), sheetNo: ''
                     });
                 }
            }
        });

        // --- 2. Process Accessories ---
        for (let i = 0; i < windingCount; i++) {
             const serKey = `wdg${i + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
             const serW = data[serKey];
             const serOd = parseFloat(String(serW?.od || '0'));
             if (serOd > 0) {
                 const washerOd = ceiling(serOd, 0.0625);
                 serRows.push({
                     group: 'ser', originalIndex: i, vtcPn: '12118892', qty: 6, desc: '',
                     partDes: `${getWindingDesignation(i)} SER`, length: washerOd.toFixed(4),
                     width: washerOd.toFixed(4), height: '0.250', sheetNo: ''
                 });
             }
             
             const accData = page6State.windingAccessories[i];
             if (!accData) continue;
             const ksCircle = parseFloat(String(data[`wdg${i + 1}` as any]?.ksCircle || '0'));

             const wStats = data[serKey];
             const w = parseFloat(String(wStats?.ksWidth || '0'));
             let t = 0;
             if (wStats?.ksThk) {
                 const clean = String(wStats.ksThk).split('/')[0].trim();
                 t = parseFloat(clean) || 0;
             }
             const radial = parseFloat(String(wStats?.radial || '0'));
             const paper = parseFloat(String(wStats?.paperInsul || '0'));
             let lBase = radial;
             const isOutermost = i === windingCount - 1;
             if (isOutermost) lBase += paper;
             const calculationMethod = isOutermost ? 'ceiling' : 'mround';
             let l = 0;
             if (calculationMethod === 'ceiling') l = ceiling(lBase, 0.0625);
             else l = mround(lBase, 0.0625);
             const fl = l + 0.5;

             ksRows.push({
                  group: 'ks', originalIndex: i, vtcPn: accData.vtcPart, qty: accData.ksQty, desc: '',
                  partDes: `${getWindingDesignation(i)} KEY SPACER`, length: fl.toFixed(4),
                  width: w.toFixed(4), height: t.toFixed(4), sheetNo: ''
             });

             const asItem = accData.asItemIndex > -1 && accData.asItemIndex < processedStack.length ? processedStack[accData.asItemIndex] : null;
             const asIr = asItem ? mround(asItem.calculatedOD / 2, 0.0625) : 0;
             const asL = ksCircle > 0 ? mround((asIr * 2 * Math.PI) / (ksCircle / 2) + 4, 0.25) : 0;
             
             const acItem = accData.acItemIndex > -1 && accData.acItemIndex < processedStack.length ? processedStack[accData.acItemIndex] : null;
             const acIr = acItem ? mround(acItem.calculatedOD / 2, 0.0625) : 0;
             const acL = ksCircle > 0 ? mround((acIr * 2 * Math.PI) / (ksCircle / 2) + 4, 0.25) : 0;

             asRows.push({
                  group: 'as', originalIndex: i, vtcPn: accData.asVtcPart, qty: (ksCircle * 3).toFixed(0), desc: '',
                  partDes: `${getWindingDesignation(i)} ANGLE SECTOR`, length: asL.toFixed(4),
                  width: accData.asH, height: accData.asT, sheetNo: ''
             });

             acRows.push({
                  group: 'ac', originalIndex: i, vtcPn: accData.acVtcPart, qty: (ksCircle * 3).toFixed(0), desc: '',
                  partDes: `${getWindingDesignation(i)} ANGLE CAP`, length: acL.toFixed(4),
                  width: accData.acH, height: accData.acT, sheetNo: ''
             });
        }

        // --- 3. Process Seals ---
        processedStack.forEach((item, idx) => {
             if (item.type === 'winding') {
                 const idState = page6State.idSealState[item.id];
                 const odState = page6State.odSealState[item.id];
                 const wIdx = windingIndices.indexOf(idx);
                 
                 // Calculate Dimensions for ID OGW (Dim B = OD)
                 const idSealRounding = page6State.idSealRounding || { id: 'C', od: 'F' };
                 const idDimB = applyRounding(item.calculatedOD, idSealRounding.od).toFixed(4);

                 if (idState) {
                      idSealRows.push({
                          group: 'idSeal', originalIndex: wIdx, vtcPn: idState.vtcPart,
                          qty: idState.qtyOpt === 3 ? 3 : idState.qtyOpt === 5 ? 6 : 9, desc: '',
                          partDes: `${getWindingDesignation(wIdx)} ID OGW`, 
                          length: idDimB, // L = OD (B)
                          width: idDimB,  // H = OD (B)
                          height: idState.t.toFixed(4), // T = T
                          sheetNo: '20'
                      });
                 }
                 
                 // Calculate Dimensions for OD OGW (Dim B = OD of next item)
                 const nextItem = idx < processedStack.length - 1 ? processedStack[idx + 1] : null;
                 const odSealRounding = page6State.odSealRounding || { id: 'C', od: 'F' };
                 const odDimB = nextItem ? applyRounding(nextItem.calculatedOD, odSealRounding.od).toFixed(4) : '0.0000';

                 if (odState && idState) {
                      odSealRows.push({
                          group: 'odSeal', originalIndex: wIdx, vtcPn: odState.vtcPart || idState.vtcPart,
                          qty: ((idState.qtyOpt + 1) / 2) * 3, desc: '',
                          partDes: `${getWindingDesignation(wIdx)} OD OGW`, 
                          length: odDimB, // L = OD (B)
                          width: odDimB,  // H = OD (B)
                          height: odState.t.toFixed(4), // T = T
                          sheetNo: '20'
                      });
                 }
             }
        });

        // --- 4. Process Head Sheet ---
        if (page6State.headSheet) {
             headSheetRows.push({
                 group: 'headSheet', vtcPn: page6State.headSheet.vtcPart, qty: page6State.headSheet.qty, desc: '',
                 partDes: 'TOP & BOTTOM HEAD SHEET', length: getHeadSheetValues.e.toFixed(4),
                 width: getHeadSheetValues.b.toFixed(4), height: page6State.headSheet.t.toFixed(4), sheetNo: ''
             });
        }
        
        // --- 5. Assign Item Numbers and combine ---
        const finalRows: any[] = [];
        let itemNoCounter = itemBases.start;
        tubeRows.forEach(r => { r.itemNo = itemNoCounter++; });
        stickRows.forEach(r => { r.itemNo = itemNoCounter++; });
        finalRows.push(...tubeRows, ...stickRows);

        itemNoCounter = itemBases.ser;
        serRows.sort((a,b) => a.originalIndex - b.originalIndex);
        serRows.forEach(r => { r.itemNo = itemNoCounter++; });
        finalRows.push(...serRows);
        
        itemNoCounter = itemBases.ks;
        ksRows.sort((a,b) => a.originalIndex - b.originalIndex);
        ksRows.forEach(r => { r.itemNo = itemNoCounter++; });
        finalRows.push(...ksRows);

        itemNoCounter = itemBases.angleSector;
        asRows.sort((a,b) => a.originalIndex - b.originalIndex);
        asRows.forEach(r => { r.itemNo = itemNoCounter++; });
        finalRows.push(...asRows);

        itemNoCounter = itemBases.angleCap;
        acRows.sort((a,b) => a.originalIndex - b.originalIndex);
        acRows.forEach(r => { r.itemNo = itemNoCounter++; });
        finalRows.push(...acRows);
        
        itemNoCounter = itemBases.idSeal;
        idSealRows.sort((a,b) => a.originalIndex - b.originalIndex);
        idSealRows.forEach(r => { r.itemNo = itemNoCounter++; });
        finalRows.push(...idSealRows);
        
        itemNoCounter = itemBases.odSeal;
        odSealRows.sort((a,b) => a.originalIndex - b.originalIndex);
        odSealRows.forEach(r => { r.itemNo = itemNoCounter++; });
        finalRows.push(...odSealRows);

        itemNoCounter = itemBases.headSheet;
        headSheetRows.forEach(r => { r.itemNo = itemNoCounter++; });
        finalRows.push(...headSheetRows);
        
        setBomRows(finalRows);
    }, [processedStack, page6State, data, windingNames, windingCount, customDesignations, itemBases, getHeadSheetValues]);

    const handleCopyTable = () => {
        const header = "Item No#\tVTC PN#\tQuantity\tDescription\tPart Des.\tL\tH\tT\tSheet No#";
        const body = bomRows
            .filter((_, idx) => !deletedRowIndices.has(idx))
            .map(r => `${r.itemNo}\t${r.vtcPn}\t${r.qty}\t${r.desc}\t${r.partDes}\t${r.length}\t${r.width}\t${r.height}\t${r.sheetNo}`)
            .join('\n');
        navigator.clipboard.writeText(`${header}\n${body}`).then(() => {
            setCopySuccess(true);
            setTimeout(() => setCopySuccess(false), 2000);
        });
    };

    const updateRow = (index: number, field: string, value: string) => {
        const newRows = [...bomRows];
        newRows[index] = { ...newRows[index], [field]: value };
        setBomRows(newRows);
    };

    const deleteRow = (index: number) => {
        setDeletedRowIndices(prev => new Set(prev).add(index));
    };

    return (
        <div className="space-y-6 animate-fadeIn pb-12">
            <div className="flex items-center justify-between mb-4">
                <button onClick={onBack} className="flex items-center text-slate-600 hover:text-slate-900 transition-colors bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm hover:shadow-md">
                    <ArrowLeft className="w-4 h-4 mr-2" /> Back to Main
                </button>
                <div className="flex items-center space-x-3">
                    <button 
                        onClick={handleCopyTable}
                        className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-bold text-sm shadow-sm"
                    >
                        {copySuccess ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                        {copySuccess ? 'Copied!' : 'Copy Table'}
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
                {/* Winding Designation Settings */}
                <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200">
                    <h3 className="text-sm font-bold text-slate-700 mb-3 flex items-center">
                        <Settings className="w-4 h-4 mr-2 text-indigo-500" />
                        Winding Designations
                    </h3>
                    <div className="flex gap-3 overflow-x-auto pb-2">
                        {customDesignations.map((name, idx) => (
                            <div key={idx} className="flex flex-col">
                                <label className="text-[10px] uppercase text-slate-500 font-bold mb-1">Winding {idx + 1}</label>
                                <input
                                    type="text"
                                    value={name}
                                    onChange={(e) => handleDesignationChange(idx, e.target.value)}
                                    className="border border-slate-300 rounded px-2 py-1 text-sm font-bold w-20 text-center focus:border-indigo-500 outline-none focus:ring-1 focus:ring-indigo-200 bg-slate-50 focus:bg-white transition-all"
                                />
                            </div>
                        ))}
                    </div>
                </div>

                {/* Item Numbering Settings */}
                <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200">
                    <h3 className="text-sm font-bold text-slate-700 mb-3 flex items-center">
                        <ListFilter className="w-4 h-4 mr-2 text-indigo-500" />
                        Item Number Bases
                    </h3>
                    <div className="grid grid-cols-4 gap-3">
                        <div className="flex flex-col">
                            <label className="text-[9px] uppercase text-slate-500 font-bold">Start</label>
                            <input type="number" value={itemBases.start} onChange={e => handleBaseChange('start', parseInt(e.target.value))} className="border rounded px-1 py-0.5 text-xs font-mono" />
                        </div>
                        <div className="flex flex-col">
                            <label className="text-[9px] uppercase text-slate-500 font-bold">SER</label>
                            <input type="number" value={itemBases.ser} onChange={e => handleBaseChange('ser', parseInt(e.target.value))} className="border rounded px-1 py-0.5 text-xs font-mono" />
                        </div>
                        <div className="flex flex-col">
                            <label className="text-[9px] uppercase text-slate-500 font-bold">KS</label>
                            <input type="number" value={itemBases.ks} onChange={e => handleBaseChange('ks', parseInt(e.target.value))} className="border rounded px-1 py-0.5 text-xs font-mono" />
                        </div>
                        <div className="flex flex-col">
                            <label className="text-[9px] uppercase text-slate-500 font-bold">AS</label>
                            <input type="number" value={itemBases.angleSector} onChange={e => handleBaseChange('angleSector', parseInt(e.target.value))} className="border rounded px-1 py-0.5 text-xs font-mono" />
                        </div>
                         <div className="flex flex-col">
                            <label className="text-[9px] uppercase text-slate-500 font-bold">AC</label>
                            <input type="number" value={itemBases.angleCap} onChange={e => handleBaseChange('angleCap', parseInt(e.target.value))} className="border rounded px-1 py-0.5 text-xs font-mono" />
                        </div>
                        <div className="flex flex-col">
                            <label className="text-[9px] uppercase text-slate-500 font-bold">ID Seal</label>
                            <input type="number" value={itemBases.idSeal} onChange={e => handleBaseChange('idSeal', parseInt(e.target.value))} className="border rounded px-1 py-0.5 text-xs font-mono" />
                        </div>
                        <div className="flex flex-col">
                            <label className="text-[9px] uppercase text-slate-500 font-bold">OD Seal</label>
                            <input type="number" value={itemBases.odSeal} onChange={e => handleBaseChange('odSeal', parseInt(e.target.value))} className="border rounded px-1 py-0.5 text-xs font-mono" />
                        </div>
                         <div className="flex flex-col">
                            <label className="text-[9px] uppercase text-slate-500 font-bold">Head</label>
                            <input type="number" value={itemBases.headSheet} onChange={e => handleBaseChange('headSheet', parseInt(e.target.value))} className="border rounded px-1 py-0.5 text-xs font-mono" />
                        </div>
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center">
                    <FileText className="w-5 h-5 mr-2 text-indigo-600" />
                    <h3 className="font-bold text-lg text-slate-800">Bill of Materials</h3>
                </div>
                
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left border-collapse">
                        <thead>
                            <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                                <th className="px-4 py-3 border-r border-slate-200 w-10"></th>
                                <th className="px-4 py-3 border-r border-slate-200 w-20">Item No#</th>
                                <th className="px-4 py-3 border-r border-slate-200 w-32">VTC PN#</th>
                                <th className="px-4 py-3 border-r border-slate-200 w-20 text-center">Quantity</th>
                                <th className="px-4 py-3 border-r border-slate-200 w-20">Description</th>
                                <th className="px-4 py-3 border-r border-slate-200 w-32">Part Des.</th>
                                <th className="px-4 py-3 border-r border-slate-200 w-24 text-right">L</th>
                                <th className="px-4 py-3 border-r border-slate-200 w-24 text-right">H</th>
                                <th className="px-4 py-3 border-r border-slate-200 w-24 text-right">T</th>
                                <th className="px-4 py-3 w-24 text-center">Sheet No#</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(() => {
                                let lastGroup: string | null = null;
                                let isGray = true; // First group will be white (toggles to false)

                                return bomRows.map((row, idx) => {
                                    if (deletedRowIndices.has(idx)) {
                                        return null;
                                    }

                                    if (row.group !== lastGroup) {
                                        isGray = !isGray;
                                        lastGroup = row.group;
                                    }
                                    const rowClass = isGray ? 'bg-slate-50 hover:bg-slate-100' : 'bg-white hover:bg-slate-50';

                                    return (
                                        <tr key={idx} className={`${rowClass} group transition-colors duration-150`}>
                                            <td className="px-2 py-2 border-r border-slate-100 text-center">
                                                <button 
                                                    onClick={() => deleteRow(idx)}
                                                    className="text-slate-300 hover:text-red-500 transition-colors p-1"
                                                    title="Remove Item"
                                                >
                                                    <Trash2 className="w-4 h-4" />
                                                </button>
                                            </td>
                                            <td className="px-4 py-2 border-r border-slate-100 font-mono text-slate-600">{row.itemNo}</td>
                                            <td className="px-4 py-2 border-r border-slate-100 font-bold text-slate-800">
                                                <input 
                                                    type="text" 
                                                    value={row.vtcPn} 
                                                    onChange={(e) => updateRow(idx, 'vtcPn', e.target.value)}
                                                    className="w-full bg-transparent focus:outline-none focus:border-b focus:border-indigo-500 font-mono"
                                                />
                                            </td>
                                            <td className="px-4 py-2 border-r border-slate-100 text-center font-mono">{row.qty}</td>
                                            <td className="px-4 py-2 border-r border-slate-100 text-slate-700 w-20">
                                                <input 
                                                    type="text" 
                                                    value={row.desc} 
                                                    onChange={(e) => updateRow(idx, 'desc', e.target.value)}
                                                    className="w-full bg-transparent focus:outline-none focus:border-b focus:border-indigo-500"
                                                />
                                            </td>
                                            <td className="px-4 py-2 border-r border-slate-100">
                                                <input 
                                                    type="text" 
                                                    value={row.partDes} 
                                                    onChange={(e) => updateRow(idx, 'partDes', e.target.value)}
                                                    className="w-full bg-transparent focus:outline-none focus:border-b focus:border-indigo-500 text-slate-800 font-medium"
                                                />
                                            </td>
                                            <td className="px-4 py-2 border-r border-slate-100 text-right font-mono text-slate-600">{row.length}</td>
                                            <td className="px-4 py-2 border-r border-slate-100 text-right font-mono text-slate-600">{row.width}</td>
                                            <td className="px-4 py-2 border-r border-slate-100 text-right font-mono text-slate-600 font-bold">{row.height}</td>
                                            <td className="px-4 py-2 text-center">
                                                <input 
                                                    type="text" 
                                                    value={row.sheetNo} 
                                                    onChange={(e) => updateRow(idx, 'sheetNo', e.target.value)}
                                                    className="w-full text-center bg-transparent focus:outline-none focus:border-b focus:border-indigo-500 text-slate-500"
                                                />
                                            </td>
                                        </tr>
                                    );
                                });
                            })()}
                            {bomRows.length === 0 && (
                                <tr>
                                    <td colSpan={10} className="px-6 py-8 text-center text-slate-400">
                                        No items found. Ensure Radial calculation (Page 6) is populated.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
                {deletedRowIndices.size > 0 && (
                    <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 text-xs flex items-center justify-between">
                        <span className="text-slate-500">{deletedRowIndices.size} item(s) hidden.</span>
                        <button 
                            onClick={() => setDeletedRowIndices(new Set())}
                            className="text-indigo-600 hover:text-indigo-800 font-bold"
                        >
                            Restore All
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default PageBOM;

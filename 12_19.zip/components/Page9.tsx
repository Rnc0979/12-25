
import React, { useEffect, useState } from 'react';
import { ArrowLeft, FileSpreadsheet, Loader2, AlertCircle, CheckCircle2, Activity, ZoomIn, ZoomOut, Zap, Thermometer, Table, ChevronDown, Link as LinkIcon, RefreshCw } from 'lucide-react';
import * as XLSX from 'xlsx';
import { HyperFormula } from 'hyperformula';
import { ExtractedData } from '../types';

interface Page9Props {
  onBack: () => void;
  data: ExtractedData | null;
  windingNames: string[];
  windingCount: number;
}

type LoadingStage = 'idle' | 'fetching' | 'parsing' | 'initializing' | 'ready' | 'error';

type CellData = {
  value: any;
  isFormula: boolean;
};

// Helper to evaluate limits with support for operators (>, <, >=, <=)
const checkLimit = (val: number, limit: any, isMinCol: boolean): boolean => {
    if (limit === null || limit === undefined || limit === '') return true;
    const str = String(limit).trim();
    if (str === '') return true;
    
    // Check for explicit operators
    if (str.startsWith('>=')) return val >= parseFloat(str.substring(2));
    if (str.startsWith('>')) return val > parseFloat(str.substring(1));
    if (str.startsWith('<=')) return val <= parseFloat(str.substring(2));
    if (str.startsWith('<')) return val < parseFloat(str.substring(1));
    
    // Default assumption for plain numbers
    const num = parseFloat(str);
    if (!isNaN(num)) {
        return isMinCol ? val >= num : val <= num;
    }
    
    return true; // Ignore invalid limits
};

const FILES = [
    { id: '1.xlsx', name: 'CTC Calculation', icon: Zap },
    { id: '2.xlsx', name: 'Core Temperature', icon: Thermometer }
];

const Page9: React.FC<Page9Props> = ({ onBack, data, windingNames, windingCount }) => {
  const [stage, setStage] = useState<LoadingStage>('fetching');
  const [statusMessage, setStatusMessage] = useState<string>('Initializing...');
  const [error, setError] = useState<string | null>(null);
  const [gridData, setGridData] = useState<CellData[][]>([]);
  const [hfInstance, setHfInstance] = useState<HyperFormula | null>(null);
  
  // File & Sheet Management
  const [currentFile, setCurrentFile] = useState<string>(FILES[0].id);
  const [sheetNames, setSheetNames] = useState<string[]>([]);
  const [currentSheetName, setCurrentSheetName] = useState<string>('');
  
  // Editing State
  const [activeCell, setActiveCell] = useState<{r: number, c: number} | null>(null);
  const [editValue, setEditValue] = useState<string | null>(null);
  
  // Zoom State
  const [zoomLevel, setZoomLevel] = useState<number>(1.0);
  
  // Winding selection for data linking
  // Default to Winding 2 (index 1) if 3 windings exist, else Winding 1 (index 0)
  const [selectedWindingIndex, setSelectedWindingIndex] = useState(windingCount === 3 ? 1 : 0);

  // Update default selection when winding count changes
  useEffect(() => {
     setSelectedWindingIndex(windingCount === 3 ? 1 : 0);
  }, [windingCount]);

  // Robust range detection
  const getSheetRange = (ws: XLSX.WorkSheet) => {
    if (ws['!ref']) return XLSX.utils.decode_range(ws['!ref']);
    
    // Fallback: Scan all keys to find extents
    let minR = Infinity, minC = Infinity, maxR = -Infinity, maxC = -Infinity;
    let hasData = false;

    Object.keys(ws).forEach(key => {
        if (key.startsWith('!')) return; // Skip metadata
        const cell = XLSX.utils.decode_cell(key);
        minR = Math.min(minR, cell.r);
        minC = Math.min(minC, cell.c);
        maxR = Math.max(maxR, cell.r);
        maxC = Math.max(maxC, cell.c);
        hasData = true;
    });

    if (!hasData) return { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } };
    return { s: { r: minR, c: minC }, e: { r: maxR, c: maxC } };
  };

  const loadExcel = async (fileId: string, useSample: boolean = false) => {
    try {
      setError(null);
      setGridData([]);
      // Reset sheet names temporarily to avoid mismatch during load
      setSheetNames([]);
      
      let sheetsContent: Record<string, any[][]> = {};
      let loadedSheetNames: string[] = [];
      let definedNames: any[] = [];

      if (useSample) {
          setStage('parsing');
          setStatusMessage('Loading Sample Data...');
          loadedSheetNames = ['Sample Calculation', 'Helper Data'];
          sheetsContent['Sample Calculation'] = [
              ['Input A', 'Input B', 'Sum', 'Min', 'Max', 'Check', 'Value'],
              [10, 20, '=A2+B2', 0, 100, '', 30],
              [15, 30, '=A3+B3', 0, 40, '', 45],
              [5, 5, '=A4+B4', 10, 20, '', 10]
          ];
          sheetsContent['Helper Data'] = [
              ['Key', 'Value'],
              ['Key', 999]
          ];
          definedNames = [{ Name: 'MY_VAR', Ref: "'Sample Calculation'!$A$2" }];
      } else {
          setStage('fetching');
          setStatusMessage(`Fetching ${fileId}...`);

          // Match the folder name case from the file structure (excel)
          const filePath = `/excel/${encodeURIComponent(fileId)}`;
          console.log(`Attempting to fetch Excel file from: ${filePath}`);
          
          const response = await fetch(filePath);
          
          const contentType = response.headers.get('content-type');
          if (!response.ok || (contentType && contentType.includes('text/html'))) {
              throw new Error(`File not found at '${filePath}'. Ensure it exists in 'public/excel/'. Status: ${response.status}`);
          }
          
          const arrayBuffer = await response.arrayBuffer();
          
          setStage('parsing');
          setStatusMessage('Parsing Workbook data...');
          
          const workbook = XLSX.read(arrayBuffer, { type: 'array' });
          if (workbook.SheetNames.length === 0) throw new Error("Excel file appears to be empty.");
          
          loadedSheetNames = workbook.SheetNames;
          
          // Extract Defined Names (Named Ranges) - Critical for formulas like "AANTALDRADEN"
          if (workbook.Workbook && workbook.Workbook.Names) {
              definedNames = workbook.Workbook.Names;
          }

          // Process ALL sheets
          loadedSheetNames.forEach(name => {
              const worksheet = workbook.Sheets[name];
              const range = getSheetRange(worksheet);
              const rows = range.e.r + 1;
              const cols = range.e.c + 1;
              const sheetData: any[][] = [];
              
              for (let r = 0; r < rows; ++r) {
                const rowData = [];
                for (let c = 0; c < cols; ++c) {
                  const cellAddress = XLSX.utils.encode_cell({ r, c });
                  const cell = worksheet[cellAddress];
                  let val = null;
                  if (cell) {
                    if (cell.f) {
                        val = `=${cell.f}`; // Formula
                    } else {
                        val = cell.v; // Value
                        // FIX: Escape literal strings starting with '=' so HyperFormula doesn't treat them as broken formulas
                        if (typeof val === 'string' && val.startsWith('=')) {
                            val = `'${val}`;
                        }
                    }
                  }
                  rowData.push(val);
                }
                sheetData.push(rowData);
              }
              sheetsContent[name] = sheetData;
          });
      }

      setSheetNames(loadedSheetNames);
      const displaySheet = loadedSheetNames[0];
      setCurrentSheetName(displaySheet);

      setStage('initializing');
      setStatusMessage('Spinning up Calculation Engine...');

      // Small delay to allow UI update before heavy lifting
      await new Promise(resolve => setTimeout(resolve, 100));

      if (typeof HyperFormula === 'undefined') {
          throw new Error("HyperFormula engine failed to load. Please refresh the page.");
      }

      let hf;
      try {
           hf = HyperFormula.buildFromSheets(sheetsContent, {
            licenseKey: 'gpl-v3',
          });
      } catch (e) {
          console.error("HyperFormula build error:", e);
          throw new Error("Failed to initialize calculation engine.");
      }

      // Register Named Ranges (Defined Names)
      if (definedNames && definedNames.length > 0) {
          console.log(`Registering ${definedNames.length} named ranges...`);
          definedNames.forEach(dn => {
              try {
                  if (dn.Name && dn.Ref) {
                      hf.addNamedExpression(dn.Name, dn.Ref);
                  }
              } catch (e) {
                  console.warn(`Failed to register named range ${dn.Name}:`, e);
              }
          });
      }
      
      setHfInstance(hf);
      updateGridFromHf(hf, displaySheet);
      setStage('ready');

    } catch (err: any) {
      console.error("Excel load error:", err);
      setError(err.message || "An unexpected error occurred.");
      setStage('error');
    }
  };

  // Load when currentFile changes
  useEffect(() => {
    loadExcel(currentFile);
  }, [currentFile]);

  const updateGridFromHf = (hf: HyperFormula, sheet: string) => {
    if (!hf) return;
    const sheetId = hf.getSheetId(sheet);
    if (sheetId === undefined) return;
    
    const dims = hf.getSheetDimensions(sheetId);
    // Ensure we render at least some grid even if empty
    const width = Math.max(dims.width, 10);
    const height = Math.max(dims.height, 40);

    const newGrid: CellData[][] = [];
    for (let r = 0; r < height; r++) {
      const row: CellData[] = [];
      for (let c = 0; c < width; c++) {
        const cellVal = hf.getCellValue({ sheet: sheetId, row: r, col: c });
        const isFormula = hf.doesCellHaveFormula({ sheet: sheetId, row: r, col: c });
        
        let finalVal = cellVal;
        if (typeof cellVal === 'object' && cellVal !== null && 'message' in cellVal) {
             console.warn(`Error at [${r},${c}]:`, cellVal);
             finalVal = '#ERR'; 
        }

        row.push({ value: finalVal, isFormula });
      }
      newGrid.push(row);
    }
    setGridData(newGrid);
  };

  const handleCellChange = (value: string) => {
    if (!hfInstance || !activeCell) return;
    
    // 1. Update local edit state immediately for UI responsiveness
    setEditValue(value);

    // 2. Parse value for the engine
    const sheetId = hfInstance.getSheetId(currentSheetName);
    if (sheetId === undefined) return;

    let valToSet: string | number = value;
    // Only convert to number if it's NOT a formula and IS a valid number
    if (!value.startsWith('=') && !isNaN(Number(value)) && value.trim() !== '') {
        // Fix: Don't convert if it ends in a decimal point (user is typing "0.")
        if (!value.endsWith('.')) {
             valToSet = Number(value);
        }
    }

    try {
        // 3. Send to engine
        hfInstance.setCellContents({ sheet: sheetId, row: activeCell.r, col: activeCell.c }, [[valToSet]]);
        // 4. Update grid data (this updates all OTHER cells derived from this one)
        updateGridFromHf(hfInstance, currentSheetName);
    } catch (e) {
        console.error("Calculation error", e);
    }
  };

  const handleFocus = (r: number, c: number, currentVal: any) => {
      // When focusing, if it's a formula, we want to edit the formula, not the result.
      const sheetId = hfInstance?.getSheetId(currentSheetName);
      let editVal = currentVal;
      
      if (hfInstance && sheetId !== undefined) {
          const serialized = hfInstance.getCellSerialized({ sheet: sheetId, row: r, col: c });
          if (serialized !== undefined) {
              editVal = serialized; 
          }
      }

      setActiveCell({ r, c });
      setEditValue(editVal === null ? '' : String(editVal));
  };

  const getColumnLabel = (index: number) => {
      let label = '';
      let i = index;
      while (i >= 0) {
          label = String.fromCharCode((i % 26) + 65) + label;
          i = Math.floor(i / 26) - 1;
      }
      return label;
  };

  const switchSheet = (name: string) => {
      if (!hfInstance) return;
      setCurrentSheetName(name);
      updateGridFromHf(hfInstance, name);
  };

  const adjustZoom = (delta: number) => {
      setZoomLevel(prev => {
          const newZoom = Math.max(0.2, Math.min(3.0, prev + delta));
          return parseFloat(newZoom.toFixed(1));
      });
  };

  // Format value for display (when not editing)
  const getDisplayValue = (val: any, colIdx: number) => {
      if (val === null || val === undefined) return '';
      if (val === '#ERR') return '#ERR';

      if (typeof val === 'number') {
          // Column G (index 6) requested to have 3 decimal places
          if (colIdx === 6) {
              return val.toFixed(3);
          }
          // General heuristic for other floats to keep UI clean
          if (!Number.isInteger(val)) {
              // Up to 4 decimals, but remove trailing zeros if not in Col G
              return parseFloat(val.toFixed(4)).toString();
          }
      }
      return val;
  };

  const getSheetIcon = (name: string) => {
      const lower = name.toLowerCase();
      if (lower.includes('ctc')) return <Zap className="w-3 h-3 mr-1.5 text-amber-500" />;
      if (lower.includes('temp')) return <Thermometer className="w-3 h-3 mr-1.5 text-rose-500" />;
      return <Table className="w-3 h-3 mr-1.5 text-slate-400" />;
  };

  const handleLinkData = () => {
    if (!data || !hfInstance) return;

    const sheetId = hfInstance.getSheetId(currentSheetName);
    if (sheetId === undefined) return;

    const wKey = `wdg${selectedWindingIndex + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
    const wData = data[wKey];
    if (!wData) return;

    // G8 = No of strands (row 7, col 6)
    // G10 = thickness (row 9, col 6)
    // G11 = width (row 10, col 6)
    // G12 = winding ID (row 11, col 6)
    // G15 = KS/circle (row 14, col 6)
    // G16 = ks/circle width (row 15, col 6)

    const updates = [
        { r: 7, c: 6, val: wData.strands },
        { r: 9, c: 6, val: wData.bareThk },
        { r: 10, c: 6, val: wData.bareWidth },
        { r: 11, c: 6, val: wData.id },
        { r: 14, c: 6, val: wData.ksCircle },
        { r: 15, c: 6, val: wData.ksWidth },
    ];

    const changes = [];
    updates.forEach(u => {
        let v = u.val;
        if (v !== null && v !== undefined) {
             // Basic cleaning if it's a string, removing non-numeric chars except . and -
             // If it's already a number, parseFloat handles it fine or returns as is.
             // Special case: if val contains "/", take first part? No, let's assume raw or simple numbers for now as per extraction
             if (typeof v === 'string') {
                 v = parseFloat(v.replace(/[^\d.-]/g, ''));
             }
             if (!isNaN(v)) {
                 changes.push({ row: u.r, col: u.c, value: v });
             }
        }
    });

    if (changes.length > 0) {
        // HyperFormula setCellContents processes one cell at a time if given as (row, col)
        // Or can process a block. We'll do individual updates for simplicity as they are scattered.
        changes.forEach(c => {
             hfInstance.setCellContents({ sheet: sheetId, row: c.row, col: c.col }, [[c.value]]);
        });
        updateGridFromHf(hfInstance, currentSheetName);
    }
  };

  const hasContent = gridData.length > 0 && gridData.some(row => row.some(cell => cell.value !== null && cell.value !== undefined && cell.value !== ''));

  return (
    <div className="flex flex-col h-screen bg-slate-50 animate-fadeIn">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-6 py-3 flex justify-between items-center shadow-sm z-40 relative h-16">
        
        {/* Left: Back & File Selection */}
        <div className="flex items-center space-x-4 z-10">
            <button 
                onClick={onBack}
                className="flex items-center text-slate-500 hover:text-slate-800 transition-colors bg-slate-50 hover:bg-slate-100 px-3 py-2 rounded-lg border border-slate-200 shadow-sm"
            >
                <ArrowLeft className="w-4 h-4 mr-2" /> Back
            </button>
            
            <div className="h-8 w-px bg-slate-200 mx-2"></div>

            {/* Workbook Selector */}
            <div className="relative group">
                <div className="flex items-center space-x-2 bg-slate-100 hover:bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 cursor-pointer transition-all">
                    <FileSpreadsheet className="w-4 h-4 text-indigo-600" />
                    <select 
                        value={currentFile} 
                        onChange={(e) => setCurrentFile(e.target.value)}
                        className="bg-transparent text-sm font-bold text-slate-700 focus:outline-none cursor-pointer appearance-none pr-6"
                    >
                        {FILES.map(f => (
                            <option key={f.id} value={f.id}>{f.name}</option>
                        ))}
                    </select>
                    <ChevronDown className="w-3 h-3 text-slate-400 absolute right-3 pointer-events-none" />
                </div>
            </div>

            {/* Status Indicator */}
            <div className="flex items-center ml-2">
                {stage === 'ready' ? (
                        <span className="flex items-center text-[10px] text-emerald-600 font-medium bg-emerald-50 px-2 py-1 rounded-full border border-emerald-100">
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Ready
                        </span>
                ) : stage === 'error' ? (
                        <span className="flex items-center text-[10px] text-red-600 font-medium bg-red-50 px-2 py-1 rounded-full border border-red-100">
                        <AlertCircle className="w-3 h-3 mr-1" />
                        Error
                        </span>
                ) : (
                        <span className="flex items-center text-[10px] text-indigo-600 font-medium bg-indigo-50 px-2 py-1 rounded-full border border-indigo-100">
                        <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                        {statusMessage}
                        </span>
                )}
            </div>
        </div>

        {/* Center: Sheet Switcher (Absolute Positioned for Center Alignment) */}
        {sheetNames.length > 0 && (
            <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 z-0">
                <div className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200 shadow-inner">
                    {sheetNames.map((name) => {
                        const isActive = currentSheetName === name;
                        return (
                            <button
                                key={name}
                                onClick={() => switchSheet(name)}
                                className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all flex items-center ${
                                    isActive 
                                    ? 'bg-white text-indigo-600 shadow-sm ring-1 ring-black/5' 
                                    : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200/50'
                                }`}
                            >
                                {getSheetIcon(name)}
                                {name}
                            </button>
                        );
                    })}
                </div>
            </div>
        )}

        {/* Right: Tools */}
        <div className="flex items-center space-x-4 z-10">
             
             {/* Data Link Control */}
             {data && (
                <div className="flex items-center bg-amber-50 rounded-lg p-1 border border-amber-100 shadow-sm">
                     <select
                         className="bg-transparent text-xs font-bold text-amber-800 focus:outline-none px-2 py-1 cursor-pointer"
                         value={selectedWindingIndex}
                         onChange={(e) => setSelectedWindingIndex(parseInt(e.target.value))}
                     >
                         {windingNames.slice(0, windingCount).map((name, i) => (
                             <option key={i} value={i}>{name}</option>
                         ))}
                     </select>
                     <button
                         onClick={handleLinkData}
                         className="ml-1 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded text-xs font-bold transition-colors flex items-center"
                     >
                         <LinkIcon className="w-3 h-3 mr-1.5" />
                         Link Data
                     </button>
                </div>
             )}

             {/* Legend */}
             <div className="hidden lg:flex items-center space-x-3 text-[10px] font-medium bg-slate-100 p-1.5 rounded-lg border border-slate-200">
                <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-yellow-100 border border-yellow-200 rounded-sm"></div>
                    <span className="text-slate-600">Input</span>
                </div>
                <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-blue-100 border border-blue-200 rounded-sm"></div>
                    <span className="text-slate-600">Limits</span>
                </div>
                <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-emerald-200 border border-emerald-300 rounded-sm"></div>
                    <span className="text-slate-600">Pass</span>
                </div>
                <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-red-200 border border-red-300 rounded-sm"></div>
                    <span className="text-slate-600">Fail</span>
                </div>
             </div>
             
             {/* Zoom Controls */}
             <div className="flex items-center space-x-1 bg-white rounded-md border border-slate-200 p-0.5 shadow-sm">
                 <button onClick={() => adjustZoom(-0.1)} className="p-1.5 hover:bg-slate-50 rounded text-slate-500 hover:text-indigo-600 transition-colors" title="Zoom Out">
                     <ZoomOut className="w-3.5 h-3.5" />
                 </button>
                 <span className="text-[10px] font-bold text-slate-700 w-8 text-center select-none font-mono">
                     {Math.round(zoomLevel * 100)}%
                 </span>
                 <button onClick={() => adjustZoom(0.1)} className="p-1.5 hover:bg-slate-50 rounded text-slate-500 hover:text-indigo-600 transition-colors" title="Zoom In">
                     <ZoomIn className="w-3.5 h-3.5" />
                 </button>
             </div>

             <div className={`px-3 py-1.5 border rounded text-[10px] font-semibold transition-colors flex items-center ${stage === 'ready' ? 'bg-amber-50 border-amber-100 text-amber-700' : 'bg-slate-100 border-slate-200 text-slate-400'}`}>
                <Activity className="w-3 h-3 mr-1.5" />
                Client-Side Engine
             </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-6 relative bg-slate-50/50">
        
        {stage !== 'ready' && stage !== 'error' && (
            <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center">
                <div className="bg-white p-8 rounded-2xl shadow-xl border border-slate-100 flex flex-col items-center max-w-sm w-full">
                    <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center mb-4">
                        <Loader2 className="w-6 h-6 text-indigo-600 animate-spin" />
                    </div>
                    <h3 className="text-slate-800 font-bold text-lg mb-1">Loading Excel Data</h3>
                    <p className="text-slate-500 text-sm text-center">{statusMessage}</p>
                    <div className="w-full bg-slate-100 rounded-full h-1.5 mt-6 overflow-hidden">
                        <div 
                            className="bg-indigo-500 h-full transition-all duration-500 ease-out" 
                            style={{ 
                                width: stage === 'fetching' ? '30%' : stage === 'parsing' ? '60%' : '90%' 
                            }}
                        />
                    </div>
                </div>
            </div>
        )}

        {stage === 'error' && (
            <div className="flex flex-col items-center justify-center h-full">
                <div className="bg-red-50 border border-red-200 p-8 rounded-xl max-w-md text-center shadow-sm">
                    <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
                        <AlertCircle className="w-6 h-6 text-red-600" />
                    </div>
                    <h3 className="text-red-900 font-bold text-lg mb-2">Could Not Load File</h3>
                    <p className="text-red-700 text-sm mb-6">{error}</p>
                    <div className="flex justify-center space-x-3">
                        <button 
                            onClick={() => loadExcel(currentFile, false)}
                            className="px-4 py-2 bg-white border border-red-200 text-red-700 rounded-lg text-sm font-bold hover:bg-red-50 transition-all shadow-sm"
                        >
                            Retry File
                        </button>
                        <button 
                            onClick={() => loadExcel(currentFile, true)}
                            className="px-4 py-2 bg-indigo-600 border border-indigo-700 text-white rounded-lg text-sm font-bold hover:bg-indigo-700 transition-all shadow-sm"
                        >
                            Use Sample Data
                        </button>
                    </div>
                </div>
            </div>
        )}

        {stage === 'ready' && (
            <div className="bg-white rounded-lg shadow border border-slate-300 overflow-auto max-h-[calc(100vh-140px)] relative">
                <div style={{ zoom: zoomLevel } as React.CSSProperties}>
                    <table className="border-collapse w-full text-xs">
                        <thead>
                            <tr>
                                <th className="bg-slate-100 border-b border-r border-slate-300 w-10 sticky top-0 left-0 z-40"></th>
                                {gridData[0] && gridData[0].map((_, cIdx) => (
                                    <th key={cIdx} className="bg-slate-100 border-b border-r border-slate-300 px-2 py-1.5 font-bold text-slate-500 sticky top-0 z-30 min-w-[80px]">
                                        {getColumnLabel(cIdx)}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {gridData.map((row, rIdx) => (
                                <tr key={rIdx}>
                                    <td className="bg-slate-50 border-r border-b border-slate-300 px-2 py-1 font-semibold text-slate-400 text-center sticky left-0 z-20 select-none">
                                        {rIdx + 1}
                                    </td>
                                    {row.map((cell, cIdx) => {
                                        const isActive = activeCell?.r === rIdx && activeCell?.c === cIdx;
                                        const isError = cell.value === '#ERR';
                                        
                                        // Use local edit value if active, otherwise formatted grid data
                                        const displayValue = isActive && editValue !== null ? editValue : getDisplayValue(cell.value, cIdx);
                                        
                                        // ---- COLOR CODING LOGIC ----
                                        let bgClass = '';
                                        let textClass = 'text-slate-700';

                                        // 1. Input Highlight (Yellow) - If not formula and has value
                                        if (!cell.isFormula && cell.value !== null && cell.value !== '') {
                                            bgClass = 'bg-yellow-50';
                                        }

                                        // 2. Limits Columns (Blue) - Col E (4) and F (5)
                                        if (cIdx === 4 || cIdx === 5) {
                                            if (cell.value !== null && cell.value !== undefined && cell.value !== '') {
                                                bgClass = 'bg-blue-50';
                                            }
                                        }

                                        // 3. Conditional Formatting (Green/Red) - Col G (6)
                                        // Support comparison operators e.g. ">5", "<=10" in limits
                                        if (cIdx === 6 && typeof cell.value === 'number') {
                                            const minLimit = row[4]?.value;
                                            const maxLimit = row[5]?.value;
                                            
                                            // Check if we have at least one limit (number or string-condition)
                                            const hasMin = minLimit !== null && minLimit !== undefined && minLimit !== '';
                                            const hasMax = maxLimit !== null && maxLimit !== undefined && maxLimit !== '';

                                            if (hasMin || hasMax) {
                                                const passMin = checkLimit(cell.value, minLimit, true);
                                                const passMax = checkLimit(cell.value, maxLimit, false);

                                                if (passMin && passMax) {
                                                    bgClass = 'bg-emerald-200';
                                                    textClass = 'text-emerald-900 font-bold';
                                                } else {
                                                    bgClass = 'bg-red-200';
                                                    textClass = 'text-red-900 font-bold';
                                                }
                                            }
                                        }
                                        
                                        if (isError) {
                                            bgClass = 'bg-red-50';
                                            textClass = 'text-red-600 font-bold';
                                        }
                                        
                                        // Active cell overrides background for visibility
                                        if (isActive) {
                                            bgClass = 'bg-indigo-50';
                                        }

                                        return (
                                            <td key={cIdx} className={`border-r border-b border-slate-200 p-0 relative min-w-[80px] ${isActive ? 'ring-2 ring-inset ring-indigo-500 z-10' : ''} ${bgClass}`}>
                                                <input 
                                                    type="text"
                                                    className={`w-full h-full px-2 py-1.5 bg-transparent border-none outline-none font-mono text-right ${textClass}`}
                                                    value={displayValue}
                                                    onFocus={() => handleFocus(rIdx, cIdx, cell.value)}
                                                    onChange={(e) => handleCellChange(e.target.value)}
                                                />
                                            </td>
                                        );
                                    })}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                {!hasContent && gridData.length > 0 && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none bg-white/30 backdrop-blur-[1px]">
                         <p className="text-slate-400 font-bold bg-white px-4 py-2 rounded shadow-sm border border-slate-200">
                             Sheet appears empty
                         </p>
                    </div>
                )}
            </div>
        )}
      </div>
    </div>
  );
};

export default Page9;


import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Loader2, BarChart2, X, Sheet } from 'lucide-react';
import { Workbook } from "@fortune-sheet/react";
import * as LuckyExcelPkg from 'luckyexcel';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface Page10Props {
    onBack: () => void;
}

const FILES = [
    { id: '1.xlsx', name: 'CTC Calculation' },
    { id: '2.xlsx', name: 'Core Temperature' }
];

const Page10: React.FC<Page10Props> = ({ onBack }) => {
    const [currentFile, setCurrentFile] = useState<string>(FILES[0].id);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [sheetData, setSheetData] = useState<any[]>([]);
    const [showChart, setShowChart] = useState<boolean>(false);
    const [chartData, setChartData] = useState<any[]>([]);
    const [error, setError] = useState<string | null>(null);
    
    // We need a ref to access the workbook instance to get data
    const workbookRef = useRef<any>(null);

    const loadFile = async (filename: string) => {
        setIsLoading(true);
        setError(null);
        setSheetData([]); // Clear previous
        
        try {
            const response = await fetch(`/excel/${encodeURIComponent(filename)}`);
            if (!response.ok) throw new Error(`Failed to fetch ${filename}`);
            
            const blob = await response.blob();
            const file = new File([blob], filename);

            // Robust access to the transform function handling CommonJS/ESM interop
            // @ts-ignore
            const transform = LuckyExcelPkg?.transformExcelToLucky || LuckyExcelPkg?.default?.transformExcelToLucky || (window as any).LuckyExcel?.transformExcelToLucky;

            if (typeof transform !== 'function') {
                 console.error("LuckyExcel library object:", LuckyExcelPkg);
                 throw new Error("LuckyExcel library not loaded correctly. Please check console.");
            }

            transform(file, (exportJson: any) => {
                if (exportJson.sheets && exportJson.sheets.length > 0) {
                    setSheetData(exportJson.sheets);
                    setIsLoading(false);
                } else {
                    setError("No sheets found in the Excel file.");
                    setIsLoading(false);
                }
            }, (err: any) => {
                console.error("LuckyExcel transform failed:", err);
                setError("Failed to parse Excel file. It might be corrupted or incompatible.");
                setIsLoading(false);
            });
        } catch (error: any) {
            console.error("Fetch error:", error);
            setError(error.message || "Failed to load file.");
            setIsLoading(false);
        }
    };

    useEffect(() => {
        loadFile(currentFile);
    }, [currentFile]);

    const handleVisualize = () => {
        // Simple heuristic extraction for visualization
        if (!sheetData || sheetData.length === 0) return;

        // Try to access live data if possible, else use initial data
        const sheet = sheetData[0];
        const celldata = sheet.celldata; 
        
        const data: any[] = [];
        const maxRow = 20; 
        const rows: Record<number, Record<number, any>> = {};

        if (celldata) {
             celldata.forEach((cell: any) => {
                 if (cell.r < maxRow && cell.c < 2) {
                     if (!rows[cell.r]) rows[cell.r] = {};
                     let val = cell.v?.v;
                     if (!isNaN(parseFloat(val))) {
                         rows[cell.r][cell.c] = parseFloat(val);
                     }
                 }
             });

             for(let i=0; i<maxRow; i++) {
                 if (rows[i] && rows[i][0] !== undefined && rows[i][1] !== undefined) {
                     data.push({
                         name: `R${i+1}`,
                         x: rows[i][0],
                         y: rows[i][1]
                     });
                 }
             }
        }
        
        // Fallback mock data if extraction yields nothing (e.g. empty sheet)
        if (data.length < 2) {
             const mock = [
                 { name: 'A', x: 10, y: 20 },
                 { name: 'B', x: 20, y: 45 },
                 { name: 'C', x: 30, y: 30 },
                 { name: 'D', x: 40, y: 60 },
                 { name: 'E', x: 50, y: 55 },
             ];
             setChartData(mock);
        } else {
            setChartData(data);
        }

        setShowChart(true);
    };

    return (
        <div className="flex flex-col h-screen bg-slate-50 relative">
             {/* Header */}
            <div className="bg-white border-b border-slate-200 px-6 py-3 flex justify-between items-center shadow-sm z-20 h-16 shrink-0">
                <div className="flex items-center space-x-4">
                    <button onClick={onBack} className="flex items-center text-slate-500 hover:text-slate-800 transition-colors bg-slate-50 hover:bg-slate-100 px-3 py-2 rounded-lg border border-slate-200 shadow-sm">
                        <ArrowLeft className="w-4 h-4 mr-2" /> Back
                    </button>
                    
                    <div className="flex items-center space-x-2 bg-slate-100 p-1 rounded-lg">
                         {FILES.map(f => (
                             <button
                                key={f.id}
                                onClick={() => setCurrentFile(f.id)}
                                className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${currentFile === f.id ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                             >
                                 {f.name}
                             </button>
                         ))}
                    </div>
                </div>
                
                <div>
                     <button 
                        onClick={handleVisualize}
                        className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg shadow-sm hover:bg-indigo-700 transition-colors font-bold text-xs"
                    >
                        <BarChart2 className="w-4 h-4 mr-2" />
                        Visualize Data (Beta)
                    </button>
                </div>
            </div>

            <div className="flex-1 relative w-full overflow-hidden bg-slate-100">
                {isLoading ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-50 z-10">
                        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin mb-2" />
                        <span className="text-sm font-medium text-slate-500">Loading Excel Engine...</span>
                    </div>
                ) : error ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-50 z-10 p-8 text-center">
                        <div className="bg-red-50 p-6 rounded-xl border border-red-100 max-w-md">
                            <h3 className="text-red-800 font-bold mb-2">Error Loading Sheet</h3>
                            <p className="text-red-600 text-sm mb-4">{error}</p>
                            <button 
                                onClick={() => loadFile(currentFile)}
                                className="text-xs bg-white border border-red-200 text-red-700 px-3 py-1.5 rounded hover:bg-red-50"
                            >
                                Retry
                            </button>
                        </div>
                    </div>
                ) : (
                    sheetData.length > 0 && (
                        <div className="w-full h-full relative" style={{ isolation: 'isolate' }}>
                            <Workbook 
                                ref={workbookRef} 
                                data={sheetData} 
                                onChange={(data) => {
                                    // Optional: Capture changes
                                }} 
                            />
                        </div>
                    )
                )}
            </div>

            {/* Simple Overlay Chart */}
            {showChart && (
                <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-8 animate-fadeIn">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl h-[500px] flex flex-col overflow-hidden">
                        <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                            <h3 className="font-bold text-slate-800 flex items-center">
                                <BarChart2 className="w-5 h-5 mr-2 text-indigo-600" />
                                Data Visualization
                            </h3>
                            <button onClick={() => setShowChart(false)} className="p-2 hover:bg-slate-200 rounded-full text-slate-500 transition-colors">
                                <X className="w-5 h-5" />
                            </button>
                        </div>
                        <div className="flex-1 p-6 min-h-0">
                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart
                                  data={chartData}
                                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                                >
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis dataKey="name" />
                                  <YAxis />
                                  <Tooltip />
                                  <Legend />
                                  <Line type="monotone" dataKey="x" stroke="#8884d8" activeDot={{ r: 8 }} name="Col A" />
                                  <Line type="monotone" dataKey="y" stroke="#82ca9d" name="Col B" />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                        <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 text-xs text-slate-400 text-center">
                            "Displaying estimate from first 2 columns. For complex data, please use standard tools."
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Page10;

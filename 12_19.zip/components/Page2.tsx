

import React, { useState } from 'react';
import { ArrowLeft, Terminal, X, Copy, Check, Box } from 'lucide-react';
import { ExtractedData } from '../types';
import { calculateWindingDetails } from '../utils/calculations';

interface Page2Props {
  data: ExtractedData | null;
  onBack: () => void;
  windingNames: string[];
  windingCount: number;
}

const Page2: React.FC<Page2Props> = ({ data, onBack, windingNames, windingCount }) => {
  const [showDebug, setShowDebug] = useState(false);
  const [copySuccess, setCopySuccess] = useState<string | null>(null);

  if (!data) return <div className="p-8 text-center text-slate-400">No data available. Go back and upload a PDF.</div>;

  const handleCopyColumn = (colKey: 'col1' | 'col2') => {
    if (!data.coreTable) return;
    const values = data.coreTable.filter(row => !row.isTotal).map(row => colKey === 'col1' ? row.col1 : row.col2);
    const text = values.join('\n');
    
    navigator.clipboard.writeText(text).then(() => {
        setCopySuccess(colKey);
        setTimeout(() => setCopySuccess(null), 2000);
    });
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      <div className="flex items-center justify-between mb-4">
        <button onClick={onBack} className="flex items-center text-slate-600 hover:text-slate-900 transition-colors bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm hover:shadow-md">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Extraction
        </button>
        <div className="flex items-center space-x-3">
             <button onClick={() => setShowDebug(!showDebug)} className={`flex items-center px-3 py-2 rounded-lg text-xs font-mono transition-colors border ${showDebug ? 'bg-slate-800 text-white border-slate-800' : 'bg-white text-slate-500 border-slate-200 hover:border-slate-400'}`}>
                <Terminal className="w-3 h-3 mr-2" />
                {showDebug ? 'Hide Debug' : 'Show Debug Log'}
             </button>
             <h2 className="text-xl font-bold text-slate-800 hidden md:block">Calculations</h2>
        </div>
      </div>

      {showDebug && data.debugLog && (
          <div className="bg-slate-900 rounded-xl shadow-lg border border-slate-800 overflow-hidden text-left relative mb-6">
              <div className="flex justify-between items-center px-4 py-2 bg-slate-950 border-b border-slate-800">
                  <span className="text-xs font-mono text-slate-400">Extraction Log & Zone Detection</span>
                  <button onClick={() => setShowDebug(false)} className="text-slate-500 hover:text-white"><X className="w-4 h-4" /></button>
              </div>
              <div className="p-4 overflow-x-auto max-h-64 overflow-y-auto">
                  <pre className="text-[10px] font-mono text-emerald-400 whitespace-pre-wrap leading-relaxed">{data.debugLog.join('\n')}</pre>
              </div>
          </div>
      )}

      {data.coreTable && data.coreTable.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-700 mb-4">Core Build Details</h3>
            <div className="overflow-x-auto rounded-lg border border-slate-100">
                <table className="w-full text-sm text-left">
                    <thead className="bg-slate-800 text-white font-bold">
                        <tr>
                            <th className="px-4 py-2">
                                <div className="flex items-center space-x-2">
                                    <span>Lam Width</span>
                                    <button onClick={() => handleCopyColumn('col1')} className="text-slate-400 hover:text-white transition-colors p-1 rounded hover:bg-slate-700" title="Copy Column">
                                        {copySuccess === 'col1' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                                    </button>
                                </div>
                            </th>
                            <th className="px-4 py-2">
                                <div className="flex items-center space-x-2">
                                    <span>Stack Ht</span>
                                    <button onClick={() => handleCopyColumn('col2')} className="text-slate-400 hover:text-white transition-colors p-1 rounded hover:bg-slate-700" title="Copy Column">
                                        {copySuccess === 'col2' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                                    </button>
                                </div>
                            </th>
                            <th className="px-4 py-2">Stack Area</th>
                            <th className="px-4 py-2 text-right">Weight</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                        {data.coreTable.map((row, idx) => (
                            <tr key={idx} className={row.isTotal ? "bg-slate-100 font-bold border-t-2 border-slate-300" : "hover:bg-slate-50"}>
                                {row.isTotal ? (
                                    <>
                                        <td className="px-4 py-2 font-mono">Total</td>
                                        <td className="px-4 py-2 font-mono">{row.col2}</td>
                                        <td className="px-4 py-2 font-mono">{row.col3}</td>
                                        <td className="px-4 py-2 font-mono text-right">{row.col4}</td>
                                    </>
                                ) : (
                                    <>
                                        <td className="px-4 py-2 font-mono text-slate-700">{row.col1}</td>
                                        <td className="px-4 py-2 font-mono text-slate-700">{row.col2}</td>
                                        <td className="px-4 py-2 font-mono text-slate-700">{row.col3}</td>
                                        <td className="px-4 py-2 font-mono text-right text-slate-700">{row.col4}</td>
                                    </>
                                )}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
      )}
    </div>
  );
};

export default Page2;
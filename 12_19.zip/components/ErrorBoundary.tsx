import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCcw } from 'lucide-react';

interface ErrorBoundaryProps {
  children?: ReactNode;
  fallbackTitle?: string;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

/**
 * ErrorBoundary component to catch rendering errors in child components.
 * Explicitly using React.Component to ensure props and setState are correctly inherited.
 */
export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center h-full min-h-[400px] p-8 bg-slate-50 border border-slate-200 rounded-xl text-center">
            <div className="bg-rose-100 p-4 rounded-full mb-4">
                <AlertTriangle className="w-8 h-8 text-rose-600" />
            </div>
            <h2 className="text-lg font-bold text-slate-800 mb-2">{this.props.fallbackTitle || 'Something went wrong'}</h2>
            <p className="text-sm text-slate-500 mb-6 max-w-md">
                The experimental Excel feature encountered an error. This might be due to compatibility issues with the latest React version.
            </p>
            <div className="bg-white p-3 rounded border border-slate-200 text-left w-full max-w-lg mb-6 overflow-auto max-h-32">
                <code className="text-xs font-mono text-rose-600 break-all">
                    {this.state.error?.message}
                </code>
            </div>
            <button 
                onClick={() => this.setState({ hasError: false, error: null })}
                className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-bold text-sm shadow-sm"
            >
                <RefreshCcw className="w-4 h-4 mr-2" />
                Try Again
            </button>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
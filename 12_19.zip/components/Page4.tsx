import React, { useEffect, useState } from 'react';
import { ArrowLeft, RotateCcw, Plus, Minus, AlertTriangle, Droplet, Ban, Layers, Sliders, Terminal, X, ChevronDown, ChevronUp, Check, Copy, Table } from 'lucide-react';
import { ExtractedData, WindingStats, DiscDistributionState } from '../types';
import { calculateTurnsDrop } from '../utils/calculations';

interface Page4Props {
    data: ExtractedData | null;
    onBack: () => void;
    windingNames: string[];
    windingCount: number;
    pageState: DiscDistributionState;
    setPageState: React.Dispatch<React.SetStateAction<DiscDistributionState>>;
}

const Page4: React.FC<Page4Props> = ({ data, onBack, windingNames, windingCount, pageState, setPageState }) => {
    const [showDebug, setShowDebug] = useState(false);
    const [copySuccess, setCopySuccess] = useState<string | null>(null);

    // Collapsible State
    const [isAtExpanded, setIsAtExpanded] = useState(false);

    // Destructure State from Props
    const {
        numGroups,
        numSections,
        tapDiscs,
        splitTapMode,
        numGroupsManuallySet,
        discOverrides,
        topDropOverride,
        disabledDropIndices,
        kvaTable,
        hvVolts,
        lvVolts,
        tapPercent,
        lvTurns,
        vtWindingIndex,
        targetTurnsDifference,
        turnsParity,
        outermostDiscs,
        atConductorWidth,
        extraKSPerSegment,
        lockedKSSegments,
        extraKSPerSegmentPerWinding,
        totalAddKSColGrp,
        extraKSPerWinding,
        designElecHt
    } = pageState;

    // Auto-populate data on load
    useEffect(() => {
        if (!data) return;

        // Identify Windings
        // HV = Outermost (e.g. W3 in 3-wdg, W2 in 2-wdg)
        const hvIndex = windingCount - 1;
        // LV = Inner to Outermost (e.g. W2 in 3-wdg, W1 in 2-wdg)
        const lvIndex = Math.max(0, windingCount - 2);

        const hvKey = `wdg${hvIndex + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
        const lvKey = `wdg${lvIndex + 1}` as 'wdg1' | 'wdg2' | 'wdg3';

        const hvWdg = data[hvKey];
        const lvWdg = data[lvKey];

        // 1. Get MVA/kVA from PDF - only use extracted values, keep 6-column layout with empty cells
        // Initialize with empty array (will be padded to 6 columns in render)
        let newKvaTable: number[] = [];

        // Use allKvaValues if available (contains all values from PDF like [12000, 18000, 20000])
        if (data.allKvaValues && data.allKvaValues.length > 0) {
            // Use all kVA values directly (they're already in kVA, not MVA)
            newKvaTable = [...data.allKvaValues];
            console.log('[Page4] Using allKvaValues:', data.allKvaValues);
        } else if (data.mva) {
            console.log('[Page4] allKvaValues not found, falling back to mva/maxMva');
            // Fallback: use mva and maxMva if allKvaValues not available
            const baseKva = parseFloat(String(data.mva)) * 1000; // Convert MVA to kVA
            if (!isNaN(baseKva) && baseKva > 0) {
                newKvaTable.push(baseKva);

                if (data.maxMva) {
                    const maxKva = parseFloat(String(data.maxMva)) * 1000; // Convert MVA to kVA
                    if (!isNaN(maxKva) && maxKva > 0 && maxKva !== baseKva) {
                        newKvaTable.push(maxKva);
                    }
                }
            }
        }

        // If no values extracted, keep existing table (fallback)
        if (newKvaTable.length === 0) {
            newKvaTable = pageState.kvaTable.length > 0 ? [...pageState.kvaTable] : [];
        }

        // 2. HV Volts (Phase) - Use Coil Voltage instead of Line-Line Voltage
        let newHvVolts = pageState.hvVolts;
        if (hvWdg) {
            // Prefer coilVoltage, fallback to lineVoltage if coilVoltage not available
            const coilV = hvWdg.coilVoltage ? parseFloat(String(hvWdg.coilVoltage)) : null;
            const lineV = hvWdg.lineVoltage ? parseFloat(String(hvWdg.lineVoltage)) : null;
            if (coilV && !isNaN(coilV)) {
                newHvVolts = coilV;
            } else if (lineV && !isNaN(lineV)) {
                newHvVolts = lineV;
            }
        }

        // 3. LV Volts (Phase) - Use Coil Voltage instead of Line-Line Voltage
        let newLvVolts = pageState.lvVolts;
        if (lvWdg) {
            // Prefer coilVoltage, fallback to lineVoltage if coilVoltage not available
            const coilV = lvWdg.coilVoltage ? parseFloat(String(lvWdg.coilVoltage)) : null;
            const lineV = lvWdg.lineVoltage ? parseFloat(String(lvWdg.lineVoltage)) : null;
            if (coilV && !isNaN(coilV)) {
                newLvVolts = coilV;
            } else if (lineV && !isNaN(lineV)) {
                newLvVolts = lineV;
            }
        }

        // 4. LV Turns
        let newLvTurns = pageState.lvTurns;
        if (lvWdg && lvWdg.ratedTurns) {
            const t = parseFloat(String(lvWdg.ratedTurns));
            if (!isNaN(t)) newLvTurns = t;
        }

        // 5. V/T Winding Index - Set default based on winding count
        // For 3 windings: default to 2nd winding (index 1), for 2 windings: default to 1st winding (index 0)
        let newVtWindingIndex = pageState.vtWindingIndex;
        // Set default based on winding count
        if (data && windingCount >= 2) {
            // Check if current index is invalid
            if (newVtWindingIndex < 0 || newVtWindingIndex >= windingCount) {
                // Invalid index, set to default
                newVtWindingIndex = windingCount === 3 ? 1 : 0;
            } else if (windingCount === 3 && newVtWindingIndex === 0) {
                // For 3 windings, default to 2nd winding (index 1) if still at 0
                // This will only happen on initial load, as user can change it later
                newVtWindingIndex = 1;
            }
            // For 2 windings, index 0 is already correct, so no change needed
        }

        // Update State
        setPageState(prev => ({
            ...prev,
            kvaTable: newKvaTable,
            hvVolts: newHvVolts,
            lvVolts: newLvVolts,
            lvTurns: newLvTurns,
            tapPercent: 2.5, // Enforce default
            vtWindingIndex: newVtWindingIndex
        }));

    }, [data, windingCount]);

    // Initialize totalAddKSColGrp, extraKSPerWinding, and designElecHt from design data on load
    // This effect runs whenever data changes (e.g., PDF reload or design changes)
    useEffect(() => {
        if (!data) return;

        // Try to fetch per-winding "Add #OfKS/Col/Grp" from design data
        const addKSPerWinding = data.addKSPerWinding;

        // Update per-winding extra KS if found in PDF data
        if (addKSPerWinding && Object.keys(addKSPerWinding).length > 0) {
            console.log('📊 [DEBUG] PDF addKSPerWinding:', addKSPerWinding);
            console.log('📊 [DEBUG] windingCount:', windingCount);

            setPageState(prev => {
                const newExtraKSPerWinding = { ...prev.extraKSPerWinding };
                let hasChanges = false;

                // Update values from PDF data
                // PDF uses winding NUMBERS (1, 2, 3), but code uses INDICES (0, 1, 2)
                Object.entries(addKSPerWinding).forEach(([windingKey, value]) => {
                    const windingNumber = parseInt(windingKey); // e.g., 1, 2, 3
                    const idx = windingNumber - 1; // Convert to index: 0, 1, 2

                    console.log(`📊 [DEBUG] Processing winding ${windingNumber} → index ${idx}:`, value);

                    // Skip invalid indices
                    if (idx < 0 || idx >= windingCount) {
                        console.log(`⚠️ [DEBUG] Skipping invalid index ${idx} (windingCount=${windingCount})`);
                        return;
                    }

                    const numValue = typeof value === 'number' ? value : parseFloat(String(value));
                    // Add 2 to Extra KS for Outmost Winding (HV)
                    const isOutmost = idx === windingCount - 1;
                    const adjustedValue = isOutmost ? numValue + 2 : numValue;

                    console.log(`📊 [DEBUG] Index ${idx}: numValue=${numValue}, isOutmost=${isOutmost}, adjustedValue=${adjustedValue}`);

                    if (!isNaN(numValue) && (!newExtraKSPerWinding[idx] || Math.abs(newExtraKSPerWinding[idx] - adjustedValue) > 0.01)) {
                        newExtraKSPerWinding[idx] = adjustedValue;
                        hasChanges = true;
                    }
                });

                if (hasChanges) {
                    console.log('✅ [DEBUG] Updating extraKSPerWinding:', newExtraKSPerWinding);
                    // Also update totalAddKSColGrp for backward compatibility (use outmost winding value)
                    const outmostIdx = windingCount - 1;
                    const outmostValue = newExtraKSPerWinding[outmostIdx] || prev.totalAddKSColGrp;
                    console.log(`✅ [DEBUG] totalAddKSColGrp set to: ${outmostValue} (outmostIdx=${outmostIdx})`);
                    return {
                        ...prev,
                        extraKSPerWinding: newExtraKSPerWinding,
                        totalAddKSColGrp: outmostValue
                    };
                }
                return prev;
            });
        } else {
            // Fallback to legacy addKSColGrp for backward compatibility
            const addKSColGrp = data.addKSColGrp;
            if (addKSColGrp !== undefined && addKSColGrp !== null) {
                const numericValue = typeof addKSColGrp === 'number' ? addKSColGrp : parseFloat(String(addKSColGrp));
                if (!isNaN(numericValue)) {
                    // Add 2 to Extra KS for Outmost Winding (fallback legacy behavior)
                    const adjustedValue = numericValue + 2;
                    setPageState(prev => {
                        // Only update if the value actually changed to avoid unnecessary re-renders
                        if (Math.abs(prev.totalAddKSColGrp - adjustedValue) > 0.01) {
                            // Also set for outmost winding if not already set
                            const outmostIdx = windingCount - 1;
                            const newExtraKSPerWinding = { ...prev.extraKSPerWinding };
                            if (!newExtraKSPerWinding[outmostIdx]) {
                                newExtraKSPerWinding[outmostIdx] = adjustedValue;
                            }
                            return {
                                ...prev,
                                totalAddKSColGrp: adjustedValue,
                                extraKSPerWinding: newExtraKSPerWinding
                            };
                        }
                        return prev;
                    });
                }
            }
        }

        // Fetch designElecHt from PDF data (for outmost winding only for now)
        if (data.designElecHt && data.designElecHt.length > 0) {
            setPageState(prev => ({ ...prev, designElecHt: data.designElecHt || prev.designElecHt }));
        }
    }, [data, windingCount]);

    // Auto-populate atConductorWidth from PDF bareWidth
    useEffect(() => {
        if (!data) return;

        setPageState(prev => {
            const newAtConductorWidth = { ...prev.atConductorWidth };
            let hasChanges = false;

            // Populate from PDF bareWidth for each winding
            for (let i = 0; i < windingCount; i++) {
                const wdgKey = `wdg${i + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
                const wdg = data[wdgKey];

                if (wdg && wdg.bareWidth && !newAtConductorWidth[i]) {
                    const bareWidth = parseFloat(String(wdg.bareWidth));
                    const strands = parseFloat(String(wdg.strands));

                    if (!isNaN(bareWidth)) {
                        let calculatedWidth = bareWidth;

                        // CTC Logic (same as AT table): If strands > 1, calculate cable width
                        if (!isNaN(strands) && strands > 1) {
                            calculatedWidth = ((bareWidth + 0.005) * 2) + 0.003;
                            console.log(`📐 [AT Width] CTC detected for Winding ${i + 1}: strands=${strands}, bareWidth=${bareWidth} → calculated=${calculatedWidth.toFixed(4)}`);
                        }

                        newAtConductorWidth[i] = calculatedWidth;
                        hasChanges = true;
                        console.log(`📐 [AT Width] Mapping: Winding ${i + 1} (${wdgKey}) → index ${i} → width ${calculatedWidth.toFixed(4)}`);
                    }
                }
            }

            if (hasChanges) {
                console.log('📐 [AT Width] Initialized from PDF bareWidth:', newAtConductorWidth);
                return { ...prev, atConductorWidth: newAtConductorWidth };
            }
            return prev;
        });
    }, [data, windingCount]);

    // Auto-distribute extra KS when segments change or outmost winding extra KS changes
    // Also triggers when extraKSPerSegment is cleared (e.g., by Reset button)
    useEffect(() => {
        const { sections } = calculateDistribution();
        if (sections.length === 0) return;

        // Get outmost winding extra KS value (use per-winding value if available, fallback to totalAddKSColGrp)
        const outmostIdx = windingCount - 1;
        const outmostExtraKS = extraKSPerWinding[outmostIdx] !== undefined ? extraKSPerWinding[outmostIdx] : totalAddKSColGrp;

        if (outmostExtraKS === 0) return;

        // Calculate current total of manually set extra KS
        const manuallySetTotal = (Object.values(extraKSPerSegment) as number[]).reduce((sum: number, val: number) => sum + (val || 0), 0);

        // If no manual adjustments (empty object after Reset), distribute equally (Integer Only, Remainder to Top)
        if (manuallySetTotal === 0 && Object.keys(extraKSPerSegment).length === 0) {
            // Filter out locked segments - only distribute to unlocked ones
            const unlockedSections = sections.filter(sec => !lockedKSSegments.includes(sec.id));

            if (unlockedSections.length === 0) return; // All locked, nothing to distribute

            const baseVal = Math.floor(outmostExtraKS / unlockedSections.length);
            let remainder = Math.round(outmostExtraKS - (baseVal * unlockedSections.length));

            const newDistribution: Record<number, number> = { ...extraKSPerSegment }; // Keep locked values
            unlockedSections.forEach((sec, idx) => {
                // Give remainder to first segments (Top/Upper)
                newDistribution[sec.id] = baseVal + (idx < remainder ? 1 : 0);
            });
            setPageState(prev => {
                return { ...prev, extraKSPerSegment: newDistribution };
            });
        }
    }, [numSections, extraKSPerWinding, totalAddKSColGrp, windingCount, Object.keys(extraKSPerSegment).length]);

    // Auto-adjust sections when split tap mode changes
    useEffect(() => {
        if (splitTapMode && numGroups === 1) {
            // Default to 6 sections for split tap
            if (numSections !== 6 && numSections !== 8) {
                setPageState(prev => ({ ...prev, numSections: 6 }));
            }
        }
    }, [splitTapMode, numGroups, numSections]);

    // Helper setters
    const setNumGroups = (val: 1 | 2) => setPageState(prev => ({ ...prev, numGroups: val }));
    const setNumSections = (val: number) => setPageState(prev => ({ ...prev, numSections: val }));
    const setTapDiscs = (val: 4 | 8) => setPageState(prev => ({ ...prev, tapDiscs: val }));
    const setNumGroupsManuallySet = (val: boolean) => setPageState(prev => ({ ...prev, numGroupsManuallySet: val }));
    const setDiscOverrides = (val: Record<number, number> | ((prev: Record<number, number>) => Record<number, number>)) => {
        setPageState(prev => ({
            ...prev,
            discOverrides: typeof val === 'function' ? val(prev.discOverrides) : val
        }));
    };
    const setTopDropOverride = (val: number | null) => setPageState(prev => ({ ...prev, topDropOverride: val }));
    const setDisabledDropIndices = (val: number[] | ((prev: number[]) => number[])) => {
        setPageState(prev => ({
            ...prev,
            disabledDropIndices: typeof val === 'function' ? val(prev.disabledDropIndices) : val
        }));
    };

    // KVA Table Setters
    const updateKvaTable = (index: number, val: number) => {
        const newTable = [...kvaTable];
        newTable[index] = val;
        setPageState(prev => ({ ...prev, kvaTable: newTable }));
    };

    const updateField = (field: keyof DiscDistributionState, val: number | Record<number, number> | null) => {
        setPageState(prev => ({ ...prev, [field]: val }));
    };

    // Manual optimization function for inner winding KS distribution (triggered by button)
    // Uses GREEDY algorithm to minimize HT error per segment
    const optimizeInnerWindingKS = (wIdx: number) => {
        const { sections } = calculateDistribution();
        if (sections.length === 0) return;

        const windingExtraKS = extraKSPerWinding[wIdx] || 0;
        if (windingExtraKS === 0) return;

        // --- PREPARE DATA FOR OPTIMIZATION ---
        const wdgKey = `wdg${wIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
        const wdg = data?.[wdgKey];
        if (!wdg) return;

        // 1. Calculate Common Params (CPC, TPD, outerAmps) needed for Inner Discs
        const outerAmpsRaw = parseFloat(String(outerAt.raw.ratedAmps || '0'));
        const outerAmps = numGroups === 2 ? outerAmpsRaw / 2 : outerAmpsRaw;
        const cpc = getCorrectedPhaseCurrent(wIdx);
        const tpd = typeof wdg.lyrsVal === 'string' ? parseFloat(wdg.lyrsVal) : (wdg.lyrsVal || 0);
        const targetDiscs = wdg.discVal || (tpd > 0 && wdg.ratedTurns ? Math.round(wdg.ratedTurns / tpd) : 0);
        const targetTurns = wdg.maxTurns || wdg.ratedTurns || 0;
        const effectiveTpd = (targetDiscs > 0 && targetTurns > 0) ? (targetTurns / targetDiscs) : tpd;

        // Calculate segment data
        const segmentData = sections.map(sec => {
            let effectiveOuterTurns = sec.calculatedTurns;
            if (sec.type === 'tap') effectiveOuterTurns /= 2;

            const innerTurns = (cpc > 0 && effectiveTpd > 0) ? (outerAmps * effectiveOuterTurns) / cpc : 0;
            const innerDiscs = effectiveTpd > 0 ? innerTurns / effectiveTpd : 0;

            // Outer Target HT (The goal)
            const isEnd = sec.pos === 'top' || sec.pos === 'bottom';
            const outerHT = calculateSegmentHT(sec.count, sec.id, sec.type === 'tap', isEnd).totalHT;

            // Inner Base HT (0 Extra KS)
            const innerHTResult = calculateInnerSegmentHT(wIdx, innerDiscs, undefined, sec.type === 'tap', 1000 /*dummy*/, isEnd);

            return {
                id: sec.id,
                isTap: sec.type === 'tap',
                outerHT,
                baseInnerHT: innerHTResult.baseHT,
                currentKS: 0
            };
        });

        // Get KS Thickness/Unit Height
        let ksThick = 0;
        if (wdg.ksThk) {
            const clean = String(wdg.ksThk).split('/')[0].trim();
            ksThick = parseFloat(clean) || 0;
        }
        const ksUnitHeight = ksThick * 0.95;

        // --- GREEDY DISTRIBUTION ---
        // Priority: First minimize tap zone error, then other segments
        let currentDistributed = 0;
        const targetTotal = Math.round(windingExtraKS);

        // If unit height is valid, distribute greedily
        if (ksUnitHeight > 0.001) {
            while (currentDistributed < targetTotal) {
                let bestIdx = -1;
                let maxImprovement = -Infinity;

                for (let i = 0; i < segmentData.length; i++) {
                    const seg = segmentData[i];
                    const currentHeight = seg.baseInnerHT + (seg.currentKS * ksUnitHeight);
                    const currentDiff = Math.abs(seg.outerHT - currentHeight);

                    const nextHeight = seg.baseInnerHT + ((seg.currentKS + 1) * ksUnitHeight);
                    const nextDiff = Math.abs(seg.outerHT - nextHeight);

                    // Higher improvement is better (reduction in error)
                    // Give tap zones a slight priority boost
                    let improvement = currentDiff - nextDiff;
                    if (seg.isTap) improvement *= 1.1; // 10% priority boost for tap zones

                    if (improvement > maxImprovement) {
                        maxImprovement = improvement;
                        bestIdx = i;
                    }
                }

                if (bestIdx !== -1) {
                    segmentData[bestIdx].currentKS++;
                    currentDistributed++;
                } else {
                    // Fallback (should not happen): Dump in first
                    segmentData[0].currentKS++;
                    currentDistributed++;
                }
            }
        } else {
            // If no thick data, fall back to equal
            const equalVal = Math.floor(targetTotal / sections.length);
            let rem = targetTotal % sections.length;
            segmentData.forEach((s, i) => {
                s.currentKS = equalVal + (i < rem ? 1 : 0);
            });
        }

        // Apply to State
        const newDistribution: Record<number, number> = {};
        segmentData.forEach(s => {
            newDistribution[s.id] = s.currentKS;
        });

        setPageState(prev => ({
            ...prev,
            extraKSPerSegmentPerWinding: {
                ...prev.extraKSPerSegmentPerWinding,
                [wIdx]: newDistribution
            }
        }));
    };

    // Handle extra KS adjustment for inner winding segments
    // NO MAX RESTRICTION - user can add any amount
    // NO AUTO-REBALANCING - changing one segment does NOT auto-adjust others
    const handleInnerWindingExtraKSChange = (wIdx: number, segmentId: number, delta: number) => {
        const currentValue = (extraKSPerSegmentPerWinding[wIdx]?.[segmentId]) || 0;
        const newValue = Math.max(0, currentValue + delta); // Only prevent negative

        // Simply set the value directly - no restrictions, no auto-rebalancing
        setPageState(prev => ({
            ...prev,
            extraKSPerSegmentPerWinding: {
                ...prev.extraKSPerSegmentPerWinding,
                [wIdx]: {
                    ...(prev.extraKSPerSegmentPerWinding[wIdx] || {}),
                    [segmentId]: newValue
                }
            }
        }));
    };

    // Handle extra KS adjustment for outer winding segments (with auto-reduction from others)
    const handleExtraKSChange = (segmentId: number, delta: number) => {
        const { sections } = calculateDistribution();
        const currentValue = extraKSPerSegment[segmentId] || 0;
        const newValue = Math.max(0, currentValue + delta);

        // Get outmost winding extra KS value
        const outmostIdx = windingCount - 1;
        const outmostExtraKS = extraKSPerWinding[outmostIdx] !== undefined ? extraKSPerWinding[outmostIdx] : totalAddKSColGrp;

        // Safety check: Don't exceed total
        if (newValue > outmostExtraKS) return;

        // Calculate KS to distribute to OTHERS (Total - NewValue - Locked KS)
        // Get total KS used by locked segments (excluding this one if it's locked)
        const lockedKSTotal = sections
            .filter(sec => lockedKSSegments.includes(sec.id) && sec.id !== segmentId)
            .reduce((sum, sec) => sum + (extraKSPerSegment[sec.id] || 0), 0);

        const ksForOthers = Math.max(0, outmostExtraKS - newValue - lockedKSTotal);

        // Filter out this segment AND locked segments
        const otherSegments = sections.filter(sec =>
            sec.id !== segmentId && !lockedKSSegments.includes(sec.id)
        );

        const newDistribution: Record<number, number> = { ...extraKSPerSegment };
        newDistribution[segmentId] = newValue;

        if (otherSegments.length > 0) {
            // Distribute remaining to others (Integer Only, Remainder to Top)
            const perSegment = Math.floor(ksForOthers / otherSegments.length);
            let remainder = Math.round(ksForOthers - (perSegment * otherSegments.length));

            otherSegments.forEach((sec, idx) => {
                // Give remainder to first segments (Top/Upper) - otherSegments preserves Order
                newDistribution[sec.id] = perSegment + (idx < remainder ? 1 : 0);
            });
        }

        // Lock this segment (mark as manually adjusted)
        const newLockedSegments = lockedKSSegments.includes(segmentId)
            ? lockedKSSegments
            : [...lockedKSSegments, segmentId];

        setPageState(prev => ({
            ...prev,
            extraKSPerSegment: newDistribution,
            lockedKSSegments: newLockedSegments
        }));
    };

    // Identify Outermost Winding
    const outerWindingIndex = windingCount;
    const outerWindingKey = `wdg${outerWindingIndex}` as 'wdg1' | 'wdg2' | 'wdg3';
    const outerWindingName = windingNames[outerWindingIndex - 1];

    // Helper to define structure based on configuration
    const getSectionStructure = (groups: number, sections: number, splitTap: boolean = false) => {
        let structure: { type: 'normal' | 'tap', isEnd?: boolean, pos?: 'top' | 'bottom' }[] = [];

        // SPLIT TAP MODE: Force specific sections with 2 tap zones (1 group only)
        if (splitTap && groups === 1) {
            if (sections === 6) {
                // 6 Sections: N, T, N, N, T, N
                structure = [
                    { type: 'normal', isEnd: true, pos: 'top' },
                    { type: 'tap' },
                    { type: 'normal' },
                    { type: 'normal' },
                    { type: 'tap' },
                    { type: 'normal', isEnd: true, pos: 'bottom' }
                ];
            } else if (sections === 8) {
                // 8 Sections: N, T, N, N, N, N, T, N
                structure = [
                    { type: 'normal', isEnd: true, pos: 'top' },
                    { type: 'tap' },
                    { type: 'normal' },
                    { type: 'normal' },
                    { type: 'normal' },
                    { type: 'normal' },
                    { type: 'tap' },
                    { type: 'normal', isEnd: true, pos: 'bottom' }
                ];
            }
            return structure;
        }

        if (groups === 1) {
            if (sections === 3) structure = [{ type: 'normal', isEnd: true, pos: 'top' }, { type: 'tap' }, { type: 'normal', isEnd: true, pos: 'bottom' }];
            else if (sections === 5) structure = [{ type: 'normal', isEnd: true, pos: 'top' }, { type: 'normal' }, { type: 'tap' }, { type: 'normal' }, { type: 'normal', isEnd: true, pos: 'bottom' }];
            else if (sections === 7) structure = [{ type: 'normal', isEnd: true, pos: 'top' }, { type: 'normal' }, { type: 'normal' }, { type: 'tap' }, { type: 'normal' }, { type: 'normal' }, { type: 'normal', isEnd: true, pos: 'bottom' }];
        } else {
            if (sections === 6) structure = [{ type: 'normal', isEnd: true, pos: 'top' }, { type: 'tap' }, { type: 'normal' }, { type: 'normal' }, { type: 'tap' }, { type: 'normal', isEnd: true, pos: 'bottom' }];
            else if (sections === 8) structure = [{ type: 'normal', isEnd: true, pos: 'top' }, { type: 'normal' }, { type: 'tap' }, { type: 'normal' }, { type: 'normal' }, { type: 'tap' }, { type: 'normal' }, { type: 'normal', isEnd: true, pos: 'bottom' }];
            else if (sections === 10) structure = [{ type: 'normal', isEnd: true, pos: 'top' }, { type: 'normal' }, { type: 'normal' }, { type: 'tap' }, { type: 'normal' }, { type: 'normal' }, { type: 'tap' }, { type: 'normal' }, { type: 'normal' }, { type: 'normal', isEnd: true, pos: 'bottom' }];
        }
        return structure;
    };

    // Effect to auto-detect groups from extracted data, only if not manually set
    useEffect(() => {
        if (!data || numGroupsManuallySet) return;

        const detectedGroups = parseInt(String(data[outerWindingKey]?.parallelGroups || '1'));
        if (detectedGroups !== numGroups) { // Only update if different
            setNumGroups(detectedGroups === 2 ? 2 : 1);
        }
    }, [data, outerWindingKey, numGroupsManuallySet, numGroups]);

    // Effect to ensure numSections is compatible with numGroups
    useEffect(() => {
        // Ensure numSections is within valid range for current numGroups
        if (numGroups === 1) {
            if (numSections !== 3 && numSections !== 5 && numSections !== 7) {
                setNumSections(3); // Default to 3 if incompatible
            }
        } else { // numGroups === 2
            if (numSections !== 6 && numSections !== 8 && numSections !== 10) {
                setNumSections(6); // Default to 6 if incompatible
            }
        }
    }, [numGroups]);

    // Effect to Set Default Disabled Drops when structure changes
    useEffect(() => {
        const structure = getSectionStructure(numGroups, numSections);
        const defaultDisabledIndices: number[] = [];
        structure.forEach((s, idx) => {
            if (s.type === 'normal' && !s.isEnd) {
                defaultDisabledIndices.push(idx);
            }
        });

        if (disabledDropIndices.length === 0 && structure.length > 3) {
            setDisabledDropIndices(defaultDisabledIndices);
        }

    }, [numGroups, numSections]);

    if (!data) return <div className="p-8 text-center text-slate-400">No data available. Go back and upload a PDF.</div>;

    // Calculate max turns from tap calculation table
    const getCalculatedMaxTurns = () => {
        if (!data) return null;

        const baseTap = 3;
        const taps = [1, 2, 3, 4, 5];

        // Calculate V/T
        let voltsPerTurn = 0;
        if (lvVolts > 0 && lvTurns > 0) {
            voltsPerTurn = lvVolts / lvTurns;
        }

        if (voltsPerTurn === 0) return null;

        // Calculate base turns for each tap
        const baseCalculations = taps.map((tap) => {
            const hv = Math.round(hvVolts * (1 + (baseTap - tap) * tapPercent / 100));
            const baseTurns = Math.round(hv / voltsPerTurn);
            return { tap, hv, baseTurns };
        });

        // Helper function to enforce parity (MUST MATCH TAP TABLE LOGIC)
        const applyParityEnforcement = (value: number, parity: null | 'even' | 'odd'): number => {
            if (parity === null) return value;
            const isEven = value % 2 === 0;
            if (parity === 'even') {
                return isEven ? value : value + 1; // Make it even
            } else { // parity === 'odd'
                return isEven ? value + 1 : value; // Make it odd
            }
        };

        // If target difference is set, use adjusted turns
        let tap1Turns = 0;
        if (targetTurnsDifference !== null && targetTurnsDifference > 0) {
            const baseTap3Turns = baseCalculations[2].baseTurns;
            tap1Turns = baseTap3Turns + (targetTurnsDifference * 2); // Tap 1 has max turns
        } else {
            // Use calculated turns from HV/V/T - Tap 1 has max turns
            tap1Turns = baseCalculations[0].baseTurns;
        }

        // Apply parity enforcement if enabled (CRITICAL: Must match tap table!)
        if (turnsParity !== null) {
            tap1Turns = applyParityEnforcement(tap1Turns, turnsParity);
        }

        return tap1Turns;
    };

    const calculatedMaxTurns = getCalculatedMaxTurns();

    // Helper to get all tap turns (with parity enforcement)
    const getAllTapTurns = () => {
        if (!data) return null;

        const baseTap = 3;
        const taps = [1, 2, 3, 4, 5];

        // Calculate V/T
        let voltsPerTurn = 0;
        if (lvVolts > 0 && lvTurns > 0) {
            voltsPerTurn = lvVolts / lvTurns;
        }

        if (voltsPerTurn === 0) return null;

        // Calculate base turns for each tap
        const baseCalculations = taps.map((tap) => {
            const hv = Math.round(hvVolts * (1 + (baseTap - tap) * tapPercent / 100));
            const baseTurns = Math.round(hv / voltsPerTurn);
            return { tap, hv, baseTurns };
        });

        // Helper function to enforce parity
        const applyParityEnforcement = (value: number, parity: null | 'even' | 'odd'): number => {
            if (parity === null) return value;
            const isEven = value % 2 === 0;
            if (parity === 'even') {
                return isEven ? value : value + 1;
            } else {
                return isEven ? value + 1 : value;
            }
        };

        // Calculate adjusted turns for all taps
        let adjustedTurns: number[] = [];
        if (targetTurnsDifference !== null && targetTurnsDifference > 0) {
            const baseTap3Turns = baseCalculations[2].baseTurns;
            adjustedTurns = [
                baseTap3Turns + (targetTurnsDifference * 2), // Tap 1: max
                baseTap3Turns + targetTurnsDifference,        // Tap 2
                baseTap3Turns,                                // Tap 3: rated/normal
                baseTap3Turns - targetTurnsDifference,        // Tap 4
                baseTap3Turns - (targetTurnsDifference * 2)   // Tap 5: min
            ];
        } else {
            adjustedTurns = baseCalculations.map(b => b.baseTurns);
        }

        // Apply parity enforcement if enabled
        if (turnsParity !== null) {
            adjustedTurns = adjustedTurns.map(turns => applyParityEnforcement(turns, turnsParity));
        }

        return {
            tap1: adjustedTurns[0], // Max
            tap3: adjustedTurns[2], // Rated/Normal
            tap5: adjustedTurns[4]  // Min
        };
    };

    const getAtData = (key: 'wdg1' | 'wdg2' | 'wdg3') => {
        const w = data[key] as WindingStats;

        // For outermost winding, use calculated values from tap table
        if (key === outerWindingKey) {
            const tapTurns = getAllTapTurns();

            if (tapTurns !== null) {
                // Use tap-calculated values
                const max = tapTurns.tap1;           // Tap 1 = Max Turns
                const rated = tapTurns.tap3;         // Tap 3 = Rated/Normal Turns
                const min = tapTurns.tap5;           // Tap 5 = Min Turns
                // Use manual override if set, otherwise fetch from winding data
                const totalDisc = outermostDiscs !== null ? outermostDiscs : (w.discVal || 80);
                const tpd = max / totalDisc;         // TPD = Max Turns / Discs
                const groups = w.parallelGroups || '-';

                // Create modified raw object
                const raw = { ...w, maxTurns: max, ratedTurns: rated, minTurns: min, lyrsVal: tpd, discVal: totalDisc };
                return { max, rated, min, tpd, totalDisc, groups, raw };
            }
        }

        // Fallback to original values for non-outer windings or if tap calc fails
        let max = (w.maxTurns !== null && w.maxTurns !== undefined) ? Number(w.maxTurns) : (Number(w.ratedTurns) || 0);
        const rated = Number(w.ratedTurns) || 0;
        const tpd = typeof w.lyrsVal === 'string' ? parseFloat(w.lyrsVal) : (w.lyrsVal || 0);
        const totalDisc = w.discVal || 0;
        const groups = w.parallelGroups || '-';
        return { max: Number(max), rated: Number(rated), tpd: Number(tpd), totalDisc: Number(totalDisc), groups, raw: w };
    };

    const outerAt = getAtData(outerWindingKey);

    const handleResetOverrides = () => {
        // Clear persistence state to defaults
        const structure = getSectionStructure(numGroups, numSections, splitTapMode);
        const newDisabledIndices: number[] = [];
        structure.forEach((s, idx) => {
            if (s.type === 'normal' && !s.isEnd) {
                newDisabledIndices.push(idx);
            }
        });

        // Reset to auto-distribution state
        // - extraKSPerSegment: {} triggers auto-distribute for outer winding (via useEffect)
        // - extraKSPerSegmentPerWinding: {} sets inner winding KS to 0
        setPageState(prev => ({
            ...prev,
            discOverrides: {},
            topDropOverride: null,
            extraKSPerSegment: {}, // Clear outer winding KS to trigger auto-distribute
            lockedKSSegments: [], // Unlock all segments
            extraKSPerSegmentPerWinding: {}, // Clear inner winding KS to 0
            disabledDropIndices: newDisabledIndices,
            numGroupsManuallySet: false,
            numGroups: (data && data[outerWindingKey]?.parallelGroups && parseInt(String(data[outerWindingKey].parallelGroups)) === 2) ? 2 : 1
        }));
    };



    const toggleSectionDrop = (idx: number) => {
        setDisabledDropIndices(prev => {
            if (prev.includes(idx)) return prev.filter(i => i !== idx);
            return [...prev, idx];
        });
    };

    // --- CALCULATION LOGIC ---
    const calculateDistribution = () => {
        let totalDiscsRaw = typeof outerAt.totalDisc === 'number' ? Number(outerAt.totalDisc) : parseFloat(String(outerAt.totalDisc || '0'));
        let totalDiscs = Math.floor(totalDiscsRaw); // Force integer

        // If 2 groups, double the visual discs
        if (numGroups === 2) {
            totalDiscs = totalDiscs * 2;
        }

        const tpdRaw = typeof outerAt.tpd === 'number' ? Number(outerAt.tpd) : parseFloat(String(outerAt.tpd || '0'));
        const tpdFloor = Math.floor(tpdRaw);
        const tpdCeil = Math.ceil(tpdRaw);

        // 1. Total Drop for distribution - NEW FORMULA
        // Formula: Drop = (CEILING(TPD) × Total Discs) - Max Turns from Tap Table
        // Recalculate here to get fresh values with current turnsParity state
        const calculatedMax = getCalculatedMaxTurns();
        let totalDropForDistribution = 0;

        if (calculatedMax !== null && tpdRaw > 0) {
            // NEW FORMULA: Use CEILING of TPD (round UP)
            // Example: TPD = 24.6875 → CEILING = 25
            // Drop = (25 × 80) - 1975 = 2000 - 1975 = 25
            const totalTurnsCapacity = Math.ceil(tpdRaw) * totalDiscs; // Use CEILING(TPD) × Total Discs
            totalDropForDistribution = Math.max(0, totalTurnsCapacity - calculatedMax);
        } else {
            // Fallback to original calculation if tap calculation not available
            const rawDrop = calculateTurnsDrop(outerAt.raw);
            const dropNum: number = (typeof rawDrop === 'number') ? rawDrop : 0;
            totalDropForDistribution = Math.round(Math.max(0, dropNum));
        }

        // If 2 groups, double the total drop
        if (numGroups === 2) {
            totalDropForDistribution = totalDropForDistribution * 2;
        }

        // 2. Value for Conditional Tap Zone Drop Logic
        const maxVal = calculatedMax !== null ? calculatedMax : (Number(outerAt.max) || 0);
        const ratedVal = Number(outerAt.rated) || 0;
        const halfMaxMinusRatedForTapCondition = Math.round(Math.max(0, (maxVal - ratedVal) / 2));

        // Determine if tap zone should have drop
        const hasTapDrop = (tpdFloor * 2) === halfMaxMinusRatedForTapCondition;
        const hasTapNoDropWarning = (tpdCeil * 2) === halfMaxMinusRatedForTapCondition && !hasTapDrop;

        // Target Max Turns (adjusted for group count) - USE TAP CALCULATED MAX TURNS
        const maxTurnsTarget = maxVal * (numGroups === 2 ? 2 : 1);

        if (!totalDiscs) return { sections: [], totals: { discs: 0, turns: 0 }, totalDrop: totalDropForDistribution, hasTapNoDropWarning, totalDiscsTarget: totalDiscs, maxTurnsTarget };

        interface Section {
            id: number;
            count: number;
            type: 'normal' | 'tap';
            isEnd?: boolean; // Physical ends of the whole stack
            pos?: 'top' | 'bottom';
            calculatedTurns: number;
            drop: number;
        }

        let sections: Section[] = [];
        const structureTemplates = getSectionStructure(numGroups, numSections, splitTapMode);

        // Initialize sections skeleton
        structureTemplates.forEach((tmpl, i) => {
            sections.push({
                id: i,
                count: 0,
                type: tmpl.type as 'normal' | 'tap',
                isEnd: tmpl.isEnd, pos: tmpl.pos,
                calculatedTurns: 0, drop: 0
            });
        });

        // ----------------------------------------------------------------------
        // 1. DISC DISTRIBUTION (Integer Only, With Individual Overrides & Auto-Symmetry)
        // ----------------------------------------------------------------------

        let currentDiscsToDistribute = totalDiscs;
        const assignedDiscIndices = new Set<number>();

        // A. Assign Taps
        sections.forEach(sec => {
            if (sec.type === 'tap') {
                sec.count = tapDiscs;
                currentDiscsToDistribute -= sec.count;
                assignedDiscIndices.add(sec.id);
            }
        });

        // B. Top/Bottom Symmetry for Discs
        const topSectionIdx = sections.findIndex(s => s.pos === 'top');
        const bottomSectionIdx = sections.findIndex(s => s.pos === 'bottom');

        if (topSectionIdx !== -1 && discOverrides[topSectionIdx] !== undefined) {
            const val = Number(discOverrides[topSectionIdx]);
            sections[topSectionIdx].count = val;
            currentDiscsToDistribute -= val;
            assignedDiscIndices.add(topSectionIdx);

            // Auto-apply to Bottom if Bottom is NOT manually overridden
            if (bottomSectionIdx !== -1 && discOverrides[bottomSectionIdx] === undefined) {
                sections[bottomSectionIdx].count = val;
                currentDiscsToDistribute -= val;
                assignedDiscIndices.add(bottomSectionIdx);
            }
        }

        // C. Apply Remaining Overrides
        Object.entries(discOverrides).forEach(([k, v]) => {
            const idx = parseInt(k);
            const val = Number(v);
            if (!assignedDiscIndices.has(idx)) {
                if (sections[idx] && sections[idx].type === 'normal') {
                    sections[idx].count = val;
                    currentDiscsToDistribute -= val;
                    assignedDiscIndices.add(idx);
                }
            }
        });

        // D. Distribute Remainder to Unassigned Normal Sections
        const discCandidates = sections.filter((s, idx) => s.type === 'normal' && !assignedDiscIndices.has(idx));

        if (discCandidates.length > 0) {
            const safeDist = Math.max(0, currentDiscsToDistribute);
            const center = sections.length / 2;
            // Sort candidates: Ends First (if unassigned), then Outer-In (Symmetric)
            discCandidates.sort((a, b) => {
                const isEndA = a.pos === 'top' || a.pos === 'bottom';
                const isEndB = b.pos === 'top' || b.pos === 'bottom';
                if (isEndA && !isEndB) return -1;
                if (!isEndA && isEndB) return 1;

                const idxA = sections.indexOf(a);
                const idxB = sections.indexOf(b);
                const distA = Math.abs(idxA - center);
                const distB = Math.abs(idxB - center);

                if (Math.abs(distA - distB) > 0.1) return distB - distA;
                return idxA - idxB;
            });

            const perCand = Math.floor(safeDist / discCandidates.length);
            let rem = safeDist % discCandidates.length;

            discCandidates.forEach(sec => {
                sec.count = perCand;
                if (rem > 0) {
                    sec.count++;
                    rem--;
                }
            });
        }

        // ----------------------------------------------------------------------
        // 2. DROP DISTRIBUTION
        // ----------------------------------------------------------------------

        let currentDropToDistribute = totalDropForDistribution;

        // A. Tap Drops (Smart 3-Way Auto-Detection)
        // Scenario 1: Calculated Drop - Based on target difference deficit
        // Scenario 2: Full Drop - Based on TPD condition
        // Scenario 3: Zero Drop - Default when no conditions met
        sections.forEach(sec => {
            if (sec.type === 'tap') {
                let tapDrop = 0;

                // SCENARIO 1: Calculate drop based on target difference (if set)
                if (targetTurnsDifference !== null && targetTurnsDifference > 0) {
                    // Determine number of tap intervals based on groups
                    // For 1 group: 4 taps (between 5 tap positions)
                    // For 2 groups: 8 taps (between 5 tap positions, but doubled)
                    const numTapIntervals = 4;

                    // Calculate turns needed vs available in tap zone
                    const turnsNeeded = targetTurnsDifference * numTapIntervals;
                    const turnsAvailable = sec.count * tpdFloor;
                    const calculatedDrop = turnsNeeded - turnsAvailable;

                    // Use calculated drop if positive (meaning deficit exists)
                    if (calculatedDrop > 0) {
                        tapDrop = Math.min(calculatedDrop, totalDropForDistribution); // Cap at total available
                    }
                }

                // SCENARIO 2: If no calculated drop, check TPD condition for full drop
                if (tapDrop === 0 && hasTapDrop) {
                    tapDrop = sec.count; // Full drop (all tap discs)
                }

                // SCENARIO 3: Default is zero (already tapDrop = 0)

                // Apply the calculated tap drop
                sec.drop = tapDrop;
                currentDropToDistribute = Math.max(0, currentDropToDistribute - sec.drop);
            }
        });

        // B. Top Override (Manual) or Auto Distribution
        if (topDropOverride !== null) {
            // --- MANUAL MODE ---
            // 1. Assign Top (Exact override)
            if (topSectionIdx !== -1) {
                sections[topSectionIdx].drop = topDropOverride;
                currentDropToDistribute = Math.max(0, currentDropToDistribute - topDropOverride);
            }

            // 2. Assign Bottom (Symmetry Attempt)
            // Prioritize matching the Bottom to Top if enabled and available
            if (bottomSectionIdx !== -1 && !disabledDropIndices.includes(bottomSectionIdx)) {
                const dropForBottom = Math.min(topDropOverride, currentDropToDistribute);
                sections[bottomSectionIdx].drop = dropForBottom;
                currentDropToDistribute -= dropForBottom;
            }

            // 3. Distribute Remainder to Inner Enabled Sections
            const innerCandidates = sections.filter((s, idx) => {
                if (s.type !== 'normal') return false;
                if (idx === topSectionIdx || idx === bottomSectionIdx) return false;
                if (disabledDropIndices.includes(idx)) return false;
                return true;
            });

            if (currentDropToDistribute > 0 && innerCandidates.length > 0) {
                // Sort "Outer-In" to maintain visual symmetry for remainders (e.g. 6,7,7,6)
                const center = sections.length / 2;
                innerCandidates.sort((a, b) => {
                    const idxA = sections.indexOf(a);
                    const idxB = sections.indexOf(b);
                    const distA = Math.abs(idxA - center);
                    const distB = Math.abs(idxB - center);

                    // Descending distance -> Outer ones first
                    if (Math.abs(distA - distB) > 0.1) return distB - distA;
                    // If equal distance (symmetric pair), pick Top-side first (index order)
                    return idxA - idxB;
                });

                const perCand = Math.floor(currentDropToDistribute / innerCandidates.length);
                let rem = currentDropToDistribute % innerCandidates.length;

                innerCandidates.forEach(sec => {
                    sec.drop = perCand;
                    if (rem > 0) {
                        sec.drop += 1;
                        rem--;
                    }
                });
            }

        } else {
            // --- AUTO MODE (Symmetric) ---
            const candidates = sections.filter((s, idx) => {
                if (s.type !== 'normal') return false;
                if (disabledDropIndices.includes(idx)) return false;
                return true;
            });

            if (currentDropToDistribute > 0 && candidates.length > 0) {
                const center = sections.length / 2;
                candidates.sort((a, b) => {
                    // Ends First
                    const isEndA = a.pos === 'top' || a.pos === 'bottom';
                    const isEndB = b.pos === 'top' || b.pos === 'bottom';
                    if (isEndA && !isEndB) return -1;
                    if (!isEndA && isEndB) return 1;

                    // Then Outer-In for symmetry
                    const idxA = sections.indexOf(a);
                    const idxB = sections.indexOf(b);
                    const distA = Math.abs(idxA - center);
                    const distB = Math.abs(idxB - center);

                    if (Math.abs(distA - distB) > 0.1) return distB - distA;
                    return idxA - idxB;
                });

                const perCand = Math.floor(currentDropToDistribute / candidates.length);
                let rem = currentDropToDistribute % candidates.length;

                candidates.forEach(sec => {
                    sec.drop = perCand;
                    if (rem > 0) {
                        sec.drop += 1;
                        rem--;
                    }
                });
            }
        }

        // Final integer rounding safety & Turn Calculation
        sections.forEach(sec => {
            sec.drop = Math.max(0, Math.round(sec.drop));
            const theoretical = Math.ceil(tpdRaw) * sec.count;
            sec.calculatedTurns = theoretical - sec.drop;
        });

        const totalCalcDiscs = sections.reduce((sum, s) => sum + s.count, 0);
        const totalCalcTurns = sections.reduce((sum, s) => sum + s.calculatedTurns, 0);

        return { sections, totals: { discs: totalCalcDiscs, turns: totalCalcTurns }, totalDrop: totalDropForDistribution, hasTapNoDropWarning, totalDiscsTarget: totalDiscs, maxTurnsTarget };
    };

    const { sections: discSections, totals, totalDrop, hasTapNoDropWarning, totalDiscsTarget, maxTurnsTarget } = calculateDistribution();

    const handleTopDropChange = (delta: number) => {
        // Get current calculated value if no override exists
        const topSection = discSections.find(s => s.pos === 'top');
        const currentVal = topSection ? topSection.drop : 0;
        const baseVal = topDropOverride !== null ? topDropOverride : currentVal;

        const newVal = Math.max(0, baseVal + delta);
        // Clamp to total possible drop
        setTopDropOverride(newVal);
    };

    const handleDiscOverride = (idx: number, delta: number) => {
        const sec = discSections.find(s => s.id === idx);
        if (!sec) return;
        const current = sec.count;
        const newVal = Math.max(1, current + delta);
        setDiscOverrides(prev => ({ ...prev, [idx]: newVal }));
    };

    const setTopDiscPreset = (val: number | null) => {
        if (val === null) {
            // Reset Top and Bottom overrides to Auto
            setDiscOverrides(prev => {
                const newOverrides = { ...prev };
                const topIdx = discSections.findIndex(s => s.pos === 'top');
                const botIdx = discSections.findIndex(s => s.pos === 'bottom');
                if (topIdx !== -1) delete newOverrides[topIdx];
                if (botIdx !== -1) delete newOverrides[botIdx];
                return newOverrides;
            });
        } else {
            // Set Top and Bottom for symmetry convenience
            const topIdx = discSections.findIndex(s => s.pos === 'top');
            const botIdx = discSections.findIndex(s => s.pos === 'bottom');
            setDiscOverrides(prev => {
                const newOverrides = { ...prev };
                if (topIdx !== -1) newOverrides[topIdx] = val;
                if (botIdx !== -1) newOverrides[botIdx] = val;
                return newOverrides;
            });
        }
    };

    const renderSectionDiscControl = (pos?: 'top' | 'bottom') => {
        if (pos !== 'top') return null;
        // Check if Top is overridden (part of discOverrides)
        const topIdx = discSections.findIndex(s => s.pos === 'top');
        const isOverridden = topIdx !== -1 && discOverrides[topIdx] !== undefined;
        const val = isOverridden ? discOverrides[topIdx] : null;

        return (
            <div className="flex flex-col space-y-1 ml-2 absolute left-full top-0 h-full justify-center pl-2 z-10">
                {[10, 14].map(btnVal => (
                    <button key={btnVal} onClick={() => setTopDiscPreset(btnVal)} className={`text-[9px] w-6 py-0.5 rounded border ${val === btnVal ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-500 border-slate-200 hover:border-indigo-300'}`}>
                        {btnVal}
                    </button>
                ))}
                <button onClick={() => setTopDiscPreset(null)} className={`text-[9px] w-6 py-0.5 rounded border ${val === null ? 'bg-slate-200 text-slate-600 border-slate-300' : 'bg-white text-slate-400 border-slate-200 hover:border-slate-300'}`} title="Auto">A</button>
            </div>
        );
    };

    // Helper: Calculate Corrected Phase Current logic for visualization
    const getCorrectedPhaseCurrent = (wIdx: number) => {
        if (wIdx === windingCount - 1) return 0; // Not applicable for outermost
        const currentWdgKey = `wdg${wIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
        const currentWdg = data?.[currentWdgKey];

        const outerAmps = parseFloat(String(outerAt.raw.ratedAmps || '0'));
        const outerRatedTurns = parseFloat(String(outerAt.raw.ratedTurns || '0'));
        const currentTotalTurns = parseFloat(String(currentWdg?.maxTurns || currentWdg?.ratedTurns || '0'));

        if (!outerAmps || !outerRatedTurns || !currentTotalTurns) return 0;
        return (outerAmps * outerRatedTurns) / currentTotalTurns;
    };

    // ==============================================
    // HT CALCULATION FUNCTIONS
    // ==============================================

    // HT Calculation for Outermost Winding Segments
    const calculateSegmentHT = (segmentDiscs: number, segmentId: number, isTap: boolean = false, isEndSegment: boolean = false) => {
        if (!data) return { baseHT: 0, extraKSHT: 0, totalHT: 0 };

        const outerWdg = data[outerWindingKey];
        if (!outerWdg) return { baseHT: 0, extraKSHT: 0, totalHT: 0 };

        // Get values
        // Use AT table width if available, fallback to PDF bareWidth
        const width = atConductorWidth[windingCount - 1] !== undefined
            ? atConductorWidth[windingCount - 1]
            : parseFloat(String(outerWdg.bareWidth || '0'));
        const paperInsul = parseFloat(String(outerWdg.paperInsul || '0'));

        // Debug logging
        if (segmentId === 0 || segmentId === 1) { // Only log for first couple segments to avoid spam
            console.log(`🔧 [HT Calc] Segment ${segmentId}: width=${width.toFixed(4)} (AT: ${atConductorWidth[windingCount - 1]}, PDF: ${outerWdg.bareWidth}), windingCount=${windingCount}`);
        }

        // Parse ksThk to get thick value (format: "0.0984/2" or similar)
        let ksThick = 0;
        if (outerWdg.ksThk) {
            const clean = String(outerWdg.ksThk).split('/')[0].trim();
            ksThick = parseFloat(clean) || 0;
        }

        // Part 1: (width + total paper insulation * 0.9) * disc
        const part1 = (width + paperInsul * 0.9) * segmentDiscs;

        // Part 2: (ks/circle thick * 0.95 * 2) * disc
        // Top and Bottom segments use (disc - 0.5)
        // Tap zones use (disc - 1)
        let effectiveDiscsForPart2 = segmentDiscs;
        if (isEndSegment) {
            effectiveDiscsForPart2 = Math.max(0, segmentDiscs - 0.5);
        } else if (isTap) {
            effectiveDiscsForPart2 = Math.max(0, segmentDiscs - 1);
        }
        const part2 = (ksThick * 0.95 * 2) * effectiveDiscsForPart2;

        // Add both parts
        const baseHT = part1 + part2;

        // Get extra KS for this specific segment
        const segmentExtraKS = extraKSPerSegment[segmentId] || 0;

        // Extra KS HT = extra ks * (ks/circle thick * 0.95)
        const extraKSHT = segmentExtraKS * (ksThick * 0.95);

        // Total = base + extra ks HT
        const totalHT = baseHT + extraKSHT;

        return { baseHT, extraKSHT, totalHT };
    };

    // HT Calculation for Inner Winding Segments
    const calculateInnerSegmentHT = (windingIndex: number, segmentDiscs: number, segmentId?: number, isTap?: boolean, totalWindingDiscs?: number, isEndSegment: boolean = false) => {
        if (!data) return { baseHT: 0, extraKSHT: 0, totalHT: 0 };

        const wdgKey = `wdg${windingIndex + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
        const wdg = data[wdgKey];
        if (!wdg) return { baseHT: 0, extraKSHT: 0, totalHT: 0 };

        // Get values
        // Use AT table width if available, fallback to PDF bareWidth
        const width = atConductorWidth[windingIndex] !== undefined
            ? atConductorWidth[windingIndex]
            : parseFloat(String(wdg.bareWidth || '0'));
        const paperInsul = parseFloat(String(wdg.paperInsul || '0'));

        // Parse ksThk to get thick value
        let ksThick = 0;
        if (wdg.ksThk) {
            const clean = String(wdg.ksThk).split('/')[0].trim();
            ksThick = parseFloat(clean) || 0;
        }

        // Part 1: (width + total paper insulation * 0.9) * disc
        const part1 = (width + paperInsul * 0.9) * segmentDiscs;

        // Part 2: (ks/circle thick * 0.95 * 2) * disc
        // Top and Bottom segments use (disc - 0.5)
        // NOTE: Inner windings do NOT use (disc - 1) for tap zones
        const effectiveDiscsForPart2 = isEndSegment ? Math.max(0, segmentDiscs - 0.5) : segmentDiscs;
        const part2 = (ksThick * 0.95 * 2) * effectiveDiscsForPart2;

        // Base HT = part1 + part2
        const baseHT = part1 + part2;

        // Get extra KS for this segment
        const windingSegments = extraKSPerSegmentPerWinding[windingIndex] || {};
        const segmentExtraKS = segmentId !== undefined ? (windingSegments[segmentId] || 0) : 0;

        // Extra KS HT = extra ks * (ks/circle thick * 0.95)
        const extraKSHT = segmentExtraKS * (ksThick * 0.95);

        // Total HT = base + extra KS HT
        const totalHT = baseHT + extraKSHT;

        return { baseHT, extraKSHT, totalHT };
    };

    // Calculate total HT across all segments for outermost winding
    const calculateTotalHT = () => {
        if (discSections.length === 0) return 0;
        return discSections.reduce((sum, sec, idx) => {
            const isEnd = idx === 0 || idx === discSections.length - 1;
            const ht = calculateSegmentHT(sec.count, sec.id, sec.type === 'tap', isEnd);
            return sum + ht.totalHT;
        }, 0);
    };

    const totalHT = calculateTotalHT();

    // ==============================================
    // END HT CALCULATION FUNCTIONS
    // ==============================================

    const renderInnerWindingColumns = () => {
        if (!data) return null;

        // Iterate from Winding 0 to OuterWindingIndex - 1
        const innerIndices = Array.from({ length: windingCount - 1 }, (_, i) => i);

        const outerAmpsRaw = parseFloat(String(outerAt.raw.ratedAmps || '0'));
        // User Update: When there are 2 groups for outer most winding, calculation of innerwindings turns and discs
        // should consider half of the outer most winding current.
        const outerAmps = numGroups === 2 ? outerAmpsRaw / 2 : outerAmpsRaw;

        return innerIndices.map(wIdx => {
            const cpc = getCorrectedPhaseCurrent(wIdx);
            const wdgKey = `wdg${wIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
            const wdgStats = data[wdgKey];
            const tpd = typeof wdgStats.lyrsVal === 'string' ? parseFloat(wdgStats.lyrsVal) : (wdgStats.lyrsVal || 0);
            // Target Discs usually from discVal (Trns/Lyr) or calculated from Rated/TPD if discVal missing
            const targetDiscs = wdgStats.discVal || (tpd > 0 && wdgStats.ratedTurns ? Math.round(wdgStats.ratedTurns / tpd) : 0);
            const targetTurns = wdgStats.maxTurns || wdgStats.ratedTurns || 0;
            const name = windingNames[wIdx];

            // Define color class based on index (matching table)
            const headerColorClass = wIdx === 0 ? 'text-blue-700 bg-blue-50 border-blue-200' : 'text-orange-700 bg-orange-50 border-orange-200';

            let totalCalculatedTurns = 0;
            let totalCalculatedDiscs = 0;

            // **KEY FIX**: Use effectiveTpd = targetTurns / targetDiscs for precision
            const effectiveTpd = (targetDiscs > 0 && targetTurns > 0) ? (targetTurns / targetDiscs) : tpd;

            // Get KS info for this winding
            const targetKS = extraKSPerWinding[wIdx] || 0;
            const utilizedKS = Object.values(extraKSPerSegmentPerWinding[wIdx] || {})
                .reduce((sum: number, val) => sum + (typeof val === 'number' ? val : 0), 0);

            return (
                <div key={wIdx} className="w-72 flex flex-col space-y-1 relative mb-4">
                    {/* HEADER WITH AUTO-ARRANGE BUTTON */}
                    <div className="flex items-center justify-between mb-2">
                        <div className={`text-center font-bold text-xs uppercase py-1 px-2 rounded border flex-1 ${headerColorClass}`}>{name}</div>
                        <button
                            onClick={() => optimizeInnerWindingKS(wIdx)}
                            className="ml-2 px-2 py-1 text-[10px] font-bold bg-indigo-600 text-white rounded hover:bg-indigo-700 transition-colors shadow-sm"
                            title="Auto-Arrange KS Equally"
                        >
                            Auto-Arrange KS
                        </button>
                    </div>

                    {discSections.map((sec, idx) => {
                        let innerTurns = 0;
                        let innerDiscs = 0;
                        let innerHT = { baseHT: 0, extraKSHT: 0, totalHT: 0 };

                        if (cpc > 0 && effectiveTpd > 0) {
                            let effectiveOuterTurns = sec.calculatedTurns;
                            if (sec.type === 'tap') {
                                effectiveOuterTurns = effectiveOuterTurns / 2;
                            }
                            innerTurns = (outerAmps * effectiveOuterTurns) / cpc;
                            innerDiscs = innerTurns / effectiveTpd;
                        }

                        totalCalculatedTurns += innerTurns;
                        totalCalculatedDiscs += innerDiscs;

                        // Calculate HT for inner winding segment
                        const isEnd = idx === 0 || idx === discSections.length - 1;
                        innerHT = calculateInnerSegmentHT(wIdx, innerDiscs, sec.id, sec.type === 'tap', targetDiscs, isEnd);

                        const segmentKS = (extraKSPerSegmentPerWinding[wIdx]?.[sec.id]) || 0;
                        const isTap = sec.type === 'tap';
                        const baseClasses = "relative flex flex-col justify-center px-3 border rounded-md shadow-sm transition-all";
                        const colorClasses = isTap
                            ? 'bg-amber-100 border-amber-300 text-amber-900'
                            : 'bg-blue-100 border-blue-300 text-blue-900';

                        return (
                            <div key={sec.id} className="flex items-center space-x-2">
                                <div
                                    className={`${baseClasses} ${colorClasses} flex-1`}
                                    style={{ height: `${Math.max(34, Math.min(50, sec.count * 2.5))}px` }}
                                >
                                    <div className="flex justify-between items-center text-sm font-mono font-bold leading-none mb-1">
                                        <span>{innerDiscs.toFixed(3)} Discs</span>
                                        <div className="flex items-center space-x-1">
                                            <span className="text-[9px] opacity-70">KS:{segmentKS}</span>
                                            <button
                                                onClick={() => handleInnerWindingExtraKSChange(wIdx, sec.id, -1)}
                                                className="w-4 h-4 flex items-center justify-center bg-white rounded border border-amber-400 hover:bg-amber-50 text-amber-700 text-xs font-bold"
                                            >
                                                −
                                            </button>
                                            <button
                                                onClick={() => handleInnerWindingExtraKSChange(wIdx, sec.id, 1)}
                                                className="w-4 h-4 flex items-center justify-center bg-white rounded border border-amber-400 hover:bg-amber-50 text-amber-700 text-xs font-bold"
                                            >
                                                +
                                            </button>
                                        </div>
                                    </div>
                                    <div className="flex justify-between items-center text-[10px] font-mono leading-none opacity-80">
                                        <span>({innerTurns.toFixed(3)} T)</span>
                                    </div>
                                </div>

                                {/* HT BOX FOR INNER WINDING */}
                                <div className="flex flex-row items-center justify-between bg-white border border-indigo-200 rounded-md shadow-sm px-2 py-1 min-w-[100px]" style={{ height: `${Math.max(34, Math.min(50, sec.count * 2.5))}px` }}>
                                    {/* Column 1: HT Value */}
                                    <div className="flex flex-col items-center justify-center flex-1">
                                        <span className="text-[10px] font-mono font-bold text-indigo-600">{innerHT.totalHT.toFixed(2)}</span>
                                    </div>

                                    {/* Column 2: Tap Breakdown (if tap section) */}
                                    {isTap && (
                                        <div className="flex flex-col items-center justify-center pl-2 border-l border-indigo-100">
                                            <div className="text-[8px] text-slate-600 font-mono font-bold">{innerHT.baseHT.toFixed(2)}</div>
                                            <div className="text-[8px] text-amber-700 font-mono font-bold">{innerHT.extraKSHT.toFixed(2)}</div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        );
                    })}

                    {/* SUMMARY BOX - COMPACT */}
                    <div className="w-full flex flex-col space-y-1 text-xs border-t border-slate-200 pt-2 mt-2 bg-white p-2 rounded-lg shadow-sm">
                        <div className="flex justify-between items-center">
                            <div className="flex flex-col items-center flex-1">
                                <span className="text-slate-400 font-medium text-[10px] uppercase">CALCULATED DISCS</span>
                                <div className={`font-mono font-bold ${Math.abs(totalCalculatedDiscs - targetDiscs) > 1 ? 'text-rose-600' : 'text-emerald-600'}`}>
                                    {totalCalculatedDiscs.toFixed(3)} <span className="text-slate-400 font-normal">/ {targetDiscs}</span>
                                </div>
                            </div>
                            <div className="flex flex-col items-center flex-1">
                                <span className="text-slate-400 font-medium text-[10px] uppercase">CALCULATED TURNS</span>
                                <div className={`font-mono font-bold ${Math.abs(totalCalculatedTurns - targetTurns) > 1 ? 'text-rose-600' : 'text-emerald-600'}`}>
                                    {totalCalculatedTurns.toFixed(3)} <span className="text-slate-400 font-normal">/ {targetTurns}</span>
                                </div>
                            </div>
                        </div>
                        {/* KS SUMMARY */}
                        <div className="flex justify-center items-center pt-2 border-t border-slate-100">
                            <div className="flex flex-col items-center">
                                <span className="text-slate-400 font-medium text-[10px] uppercase">KS (UTILIZED / REQUIRED)</span>
                                <div className={`font-mono font-bold ${utilizedKS !== targetKS ? 'text-amber-600' : 'text-emerald-600'}`}>
                                    {utilizedKS} <span className="text-slate-400 font-normal">/ {targetKS}</span>
                                </div>
                            </div>
                        </div>
                        {/* TOTAL HT SUMMARY FOR INNER WINDING */}
                        <div className="flex justify-center items-center pt-2 border-t border-slate-100">
                            <div className="flex flex-col items-center">
                                <div className="font-mono font-bold text-indigo-700 text-[10px]">{(() => {
                                    return discSections.reduce((sum, sec, idx) => {
                                        const isEnd = idx === 0 || idx === discSections.length - 1;
                                        let innerDiscs = 0;
                                        if (cpc > 0 && effectiveTpd > 0) {
                                            let effectiveOuterTurns = sec.calculatedTurns;
                                            if (sec.type === 'tap') {
                                                effectiveOuterTurns = effectiveOuterTurns / 2;
                                            }
                                            const innerTurns = (outerAmps * effectiveOuterTurns) / cpc;
                                            innerDiscs = innerTurns / effectiveTpd;
                                        }
                                        const ht = calculateInnerSegmentHT(wIdx, innerDiscs, sec.id, sec.type === 'tap', targetDiscs, isEnd);
                                        return sum + ht.totalHT;
                                    }, 0).toFixed(3);
                                })()}</div>
                                {designElecHt && designElecHt[wIdx] && (
                                    <div className="text-xs text-slate-500 font-mono mt-0.5">/ {designElecHt[wIdx].toFixed(3)}</div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            );
        });
    };

    // Helper functions for width adjustment
    const handleWidthChange = (windingIdx: number, delta: number) => {
        setPageState(prev => {
            const newAtConductorWidth = { ...prev.atConductorWidth };
            const currentValue = newAtConductorWidth[windingIdx] || 0;
            const newValue = Math.max(0.001, Number((currentValue + delta).toFixed(4))); // Min 0.001, max precision 4 decimals
            newAtConductorWidth[windingIdx] = newValue;
            return { ...prev, atConductorWidth: newAtConductorWidth };
        });
    };

    // Manual width input handler
    const handleWidthInput = (windingIdx: number, value: string) => {
        const numValue = parseFloat(value);
        if (!isNaN(numValue) && numValue >= 0.001) {
            setPageState(prev => {
                const newAtConductorWidth = { ...prev.atConductorWidth };
                newAtConductorWidth[windingIdx] = Number(numValue.toFixed(4));
                return { ...prev, atConductorWidth: newAtConductorWidth };
            });
        }
    };

    const resetWidthToDefault = (windingIdx: number) => {
        if (!data) return;

        const wdgKey = `wdg${windingIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
        const wdg = data[wdgKey];

        if (wdg && wdg.bareWidth) {
            const bareWidth = parseFloat(String(wdg.bareWidth));
            const strands = parseFloat(String(wdg.strands));

            if (!isNaN(bareWidth)) {
                let calculatedWidth = bareWidth;

                // CTC Logic: If strands > 1, calculate cable width
                if (!isNaN(strands) && strands > 1) {
                    calculatedWidth = ((bareWidth + 0.005) * 2) + 0.003;
                }

                setPageState(prev => {
                    const newAtConductorWidth = { ...prev.atConductorWidth };
                    newAtConductorWidth[windingIdx] = calculatedWidth;
                    return { ...prev, atConductorWidth: newAtConductorWidth };
                });
            }
        }
    };

    const getDefaultWidth = (windingIdx: number): number | null => {
        if (!data) return null;

        const wdgKey = `wdg${windingIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
        const wdg = data[wdgKey];

        if (wdg && wdg.bareWidth) {
            const bareWidth = parseFloat(String(wdg.bareWidth));
            const strands = parseFloat(String(wdg.strands));

            if (!isNaN(bareWidth)) {
                let calculatedWidth = bareWidth;

                // CTC Logic: If strands > 1, calculate cable width
                if (!isNaN(strands) && strands > 1) {
                    calculatedWidth = ((bareWidth + 0.005) * 2) + 0.003;
                }

                return calculatedWidth;
            }
        }
        return null;
    };

    const renderAtTable = () => {
        // Helper to get raw winding stats safely
        const getWdg = (idx: number) => {
            if (idx === 0) return data?.wdg1;
            if (idx === 1) return data?.wdg2;
            if (idx === 2) return data?.wdg3;
            return null;
        };

        const calculateCorrectedCurrent = (currentWdgIndex: number, currentWdg: WindingStats | null) => {
            // Only for inner windings
            if (currentWdgIndex === windingCount - 1) return '-';

            const outerAmps = parseFloat(String(outerAt.raw.ratedAmps || '0'));
            const outerRatedTurns = parseFloat(String(outerAt.raw.ratedTurns || '0'));
            const currentTotalTurns = parseFloat(String(currentWdg?.maxTurns || currentWdg?.ratedTurns || '0'));

            if (!outerAmps || !outerRatedTurns || !currentTotalTurns) return '-';

            const val = (outerAmps * outerRatedTurns) / currentTotalTurns;
            return val.toFixed(2);
        };

        const rows: { label: string; key?: keyof WindingStats; render?: (w: WindingStats, idx: number) => string | number | null; isCalculated?: boolean; isEditable?: boolean }[] = [
            {
                label: 'Width',
                isEditable: true, // Mark as editable to render special UI
                render: (w: WindingStats) => {
                    const width = parseFloat(String(w.bareWidth));
                    const strands = parseFloat(String(w.strands));

                    // CTC Logic: If strands exist and > 1, assume CTC and calculate cable width
                    if (!isNaN(width) && !isNaN(strands) && strands > 1) {
                        // Formula: ((width + 0.005) * 2) + 0.003
                        const calculated = ((width + 0.005) * 2) + 0.003;
                        return calculated.toFixed(4);
                    }
                    return w.bareWidth || '-';
                }
            },
            { label: 'Thick', key: 'bareThk' },
            { label: 'Total Paper Insul', key: 'paperInsul' },
            { label: 'Pulls Wide', key: 'pullsW' },
            { label: 'Pulls High', key: 'pullsH' },
            { label: 'Strands', key: 'strands' },
            {
                label: 'KS thk/# Btwn Disc',
                render: (w: WindingStats) => w.ksThk ? w.ksThk : (w.ksWidth ? `${w.ksWidth}/2` : '-')
            },
            {
                label: 'Total Turns',
                render: (w: WindingStats) => w.maxTurns ?? w.ratedTurns ?? '-'
            },
            { label: 'Disc', key: 'discVal' }, // Trns/Lyr aka Disc count
            { label: 'Parallel Groups', key: 'parallelGroups' },
            {
                label: 'Turns/Disc',
                render: (w: WindingStats) => typeof w.lyrsVal === 'number' ? w.lyrsVal.toFixed(2) : w.lyrsVal
            },
            { label: 'Phase Current', key: 'ratedAmps' },
            {
                label: 'Corrected Phase Current',
                isCalculated: true,
                render: (w: WindingStats, idx: number) => calculateCorrectedCurrent(idx, w)
            }
        ];

        return (
            <div className="overflow-x-auto rounded-lg border border-slate-100">
                <table className="w-full text-sm text-left">
                    <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
                        <tr>
                            <th className="px-4 py-1.5">Parameter</th>
                            <th className="px-4 py-1.5 text-blue-700">{windingNames[0]}</th>
                            <th className="px-4 py-1.5 text-orange-700">{windingNames[1]}</th>
                            {windingCount === 3 && <th className="px-4 py-1.5 text-purple-700">{windingNames[2]}</th>}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {rows.map((row, rIdx) => (
                            <tr key={rIdx} className="hover:bg-slate-50">
                                <td className="px-4 py-1 font-medium text-slate-600">{row.label}</td>
                                {[0, 1, 2].slice(0, windingCount).map(wIdx => {
                                    const w = getWdg(wIdx);
                                    let val: any = '-';
                                    if (w) {
                                        if (row.render) {
                                            val = row.render(w, wIdx);
                                        } else if (row.key) {
                                            val = (w as any)[row.key];
                                        }
                                    }

                                    // Special rendering for editable Width row
                                    if (row.isEditable && row.label === 'Width') {
                                        const currentWidth = atConductorWidth[wIdx] || 0;
                                        const defaultWidth = getDefaultWidth(wIdx);
                                        const isModified = defaultWidth !== null && Math.abs(currentWidth - defaultWidth) > 0.0001;

                                        return (
                                            <td key={wIdx} className="px-2 py-1">
                                                <div className="flex flex-col space-y-1">
                                                    <div className="flex items-center space-x-1">
                                                        {/* Decrement Button */}
                                                        <button
                                                            onClick={() => handleWidthChange(wIdx, -0.001)}
                                                            className="w-6 h-6 flex items-center justify-center bg-rose-50 hover:bg-rose-100 rounded border border-rose-200 hover:border-rose-300 text-rose-600 text-sm font-bold transition-all"
                                                            title="Decrement by 0.001"
                                                        >
                                                            −
                                                        </button>

                                                        {/* Manual Input Field */}
                                                        <input
                                                            type="number"
                                                            step="0.001"
                                                            min="0.001"
                                                            value={currentWidth > 0 ? currentWidth.toFixed(4) : ''}
                                                            onChange={(e) => handleWidthInput(wIdx, e.target.value)}
                                                            className={`flex-1 text-center font-mono text-sm font-bold px-2 py-1 rounded border focus:outline-none focus:ring-2 focus:ring-offset-1 ${isModified
                                                                ? 'bg-blue-50 text-blue-700 border-blue-200 focus:ring-blue-400'
                                                                : 'bg-slate-50 text-slate-800 border-slate-200 focus:ring-indigo-400'
                                                                }`}
                                                            placeholder="Width"
                                                        />

                                                        {/* Increment Button */}
                                                        <button
                                                            onClick={() => handleWidthChange(wIdx, 0.001)}
                                                            className="w-6 h-6 flex items-center justify-center bg-emerald-50 hover:bg-emerald-100 rounded border border-emerald-200 hover:border-emerald-300 text-emerald-600 text-sm font-bold transition-all"
                                                            title="Increment by 0.001"
                                                        >
                                                            +
                                                        </button>
                                                    </div>

                                                    {/* Reset Button and Original Value */}
                                                    <div className="flex items-center justify-between">
                                                        <button
                                                            onClick={() => resetWidthToDefault(wIdx)}
                                                            className="text-[10px] text-slate-400 hover:text-indigo-600 transition-colors font-medium"
                                                            title={`Reset to PDF default: ${defaultWidth?.toFixed(4) || 'N/A'}`}
                                                        >
                                                            ↻ Reset
                                                        </button>
                                                        {isModified && defaultWidth !== null && (
                                                            <span className="text-[9px] text-slate-400 font-mono" title="Original PDF value">
                                                                PDF: {defaultWidth.toFixed(4)}
                                                            </span>
                                                        )}
                                                    </div>
                                                </div>
                                            </td>
                                        );
                                    }

                                    return (
                                        <td key={wIdx} className="px-4 py-1 font-mono text-slate-800 font-bold">
                                            {val || '-'}
                                        </td>
                                    );
                                })}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        );
    };

    const renderKvaTable = () => {
        // Always show 6 columns, pad with empty values (0) if needed
        const displayKvaTable = [...kvaTable];
        while (displayKvaTable.length < 6) {
            displayKvaTable.push(0);
        }

        return (
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 mb-6">
                <h3 className="text-sm font-bold text-slate-700 mb-4 flex items-center">
                    <Table className="w-4 h-4 mr-2" />
                    Ratings & Voltages
                </h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-xs border-collapse border border-slate-300">
                        <tbody>
                            {/* KVA ROW */}
                            <tr>
                                <td className="border border-slate-300 p-2 font-bold text-center bg-slate-100 text-slate-800 w-24">kVA</td>
                                {displayKvaTable.slice(0, 6).map((val, idx) => (
                                    <td key={idx} className="border border-slate-300 p-0 w-24">
                                        <input
                                            type="number"
                                            className="w-full h-full text-center py-2 focus:outline-none focus:bg-blue-50 font-mono"
                                            value={val > 0 ? val : ''}
                                            onChange={(e) => updateKvaTable(idx, parseFloat(e.target.value) || 0)}
                                        />
                                    </td>
                                ))}
                            </tr>

                            {/* HV ROW */}
                            <tr>
                                <td className="border border-slate-300 p-2 font-bold text-center bg-slate-100 text-slate-800">HV (phase Volts)</td>
                                <td className="border border-slate-300 p-0">
                                    <input
                                        type="number"
                                        className="w-full h-full text-center py-2 focus:outline-none focus:bg-blue-50 font-mono"
                                        value={hvVolts}
                                        onChange={(e) => updateField('hvVolts', parseFloat(e.target.value) || 0)}
                                    />
                                </td>
                                {/* Empty Cells to space out */}
                                <td className="border border-slate-300 bg-slate-50"></td>
                                <td className="border border-slate-300 bg-slate-50"></td>
                                <td className="border border-slate-300 bg-slate-50"></td>

                                {/* Tap Percent */}
                                <td className="border border-slate-300 p-2 text-right font-bold bg-cyan-50">Tap % =</td>
                                <td className="border border-slate-300 p-0 bg-cyan-100">
                                    <input
                                        type="number" step="0.1"
                                        className="w-full h-full text-center py-2 bg-transparent focus:outline-none font-bold text-slate-800"
                                        value={tapPercent}
                                        onChange={(e) => updateField('tapPercent', parseFloat(e.target.value) || 0)}
                                    />
                                </td>
                            </tr>

                            {/* LV ROW */}
                            <tr>
                                <td className="border border-slate-300 p-2 font-bold text-center bg-slate-100 text-slate-800">LV (phase Volts)</td>
                                <td className="border border-slate-300 p-0">
                                    <input
                                        type="number" step="0.01"
                                        className="w-full h-full text-center py-2 focus:outline-none focus:bg-blue-50 font-mono"
                                        value={lvVolts}
                                        onChange={(e) => updateField('lvVolts', parseFloat(e.target.value) || 0)}
                                    />
                                </td>
                                {/* Empty Cells to space out */}
                                <td className="border border-slate-300 bg-slate-50"></td>
                                <td className="border border-slate-300 bg-slate-50"></td>
                                <td className="border border-slate-300 bg-slate-50"></td>

                                {/* LV Turns */}
                                <td className="border border-slate-300 p-2 text-right font-bold bg-cyan-50">LV Turns =</td>
                                <td className="border border-slate-300 p-0 bg-cyan-100">
                                    <input
                                        type="number"
                                        className="w-full h-full text-center py-2 bg-transparent focus:outline-none font-bold text-slate-800"
                                        value={lvTurns}
                                        onChange={(e) => updateField('lvTurns', parseFloat(e.target.value) || 0)}
                                    />
                                </td>
                            </tr>

                            {/* V/T ROW */}
                            <tr>
                                <td className="border border-slate-300 p-2 font-bold text-center bg-slate-100 text-slate-800">V/T =</td>
                                <td className="border border-slate-300 p-2 text-center font-mono bg-slate-50" colSpan={5}>
                                    {(() => {
                                        let voltsPerTurn = 0;
                                        if (lvVolts > 0 && lvTurns > 0) {
                                            voltsPerTurn = lvVolts / lvTurns;
                                        }
                                        return voltsPerTurn > 0 ? voltsPerTurn.toFixed(4) : '0';
                                    })()}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        );
    };

    const renderTapCalculationTable = () => {
        // Calculate values for each tap (1-5)
        // Base tap is 3 (middle tap)
        const baseTap = 3;
        const taps = [1, 2, 3, 4, 5];

        // Get min and max kVA from kvaTable (filter out zeros)
        const validKvaValues = kvaTable.filter(kva => kva > 0);
        const minKva = validKvaValues.length > 0 ? Math.min(...validKvaValues) : 0;
        const maxKva = validKvaValues.length > 0 ? Math.max(...validKvaValues) : 0;

        // Calculate V/T (Volts per Turn) - using LV phase voltage and LV turns
        // V/T = LV phase voltage / LV turns (no sqrt(3) since we're using coil/phase voltage)
        let voltsPerTurn = 0;
        if (lvVolts > 0 && lvTurns > 0) {
            voltsPerTurn = lvVolts / lvTurns;
        }

        // Calculate suggested differences based on turns per disc from main page
        // Get turns per disc (Trns/Disc) from outer/HV winding (lyrsVal from main page)
        let suggestedDifferences: number[] = [22, 24, 25, 26]; // Default fallback
        if (data) {
            // Use outer winding (HV) - this is what's shown on main page
            const hvIndex = windingCount - 1;
            const hvKey = `wdg${hvIndex + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
            const hvWdg = data[hvKey];
            if (hvWdg && hvWdg.lyrsVal) {
                const turnsPerDisc = typeof hvWdg.lyrsVal === 'number'
                    ? hvWdg.lyrsVal
                    : parseFloat(String(hvWdg.lyrsVal));
                if (!isNaN(turnsPerDisc) && turnsPerDisc > 0) {
                    // Round turns per disc, multiply by 2, then create range of 5 values
                    const baseDiff = Math.round(turnsPerDisc) * 2;
                    // Create range: baseDiff+2, baseDiff+1, baseDiff, baseDiff-1, baseDiff-2
                    suggestedDifferences = [
                        baseDiff + 2,
                        baseDiff + 1,
                        baseDiff,
                        baseDiff - 1,
                        baseDiff - 2
                    ].filter(d => d > 0).sort((a, b) => a - b); // Sort ascending and filter positive
                }
            }
        }

        // First, calculate HV and base turns for each tap
        const baseCalculations = taps.map((tap) => {
            const hv = Math.round(hvVolts * (1 + (baseTap - tap) * tapPercent / 100));
            const baseTurns = voltsPerTurn > 0 ? Math.round(hv / voltsPerTurn) : 0;
            return { tap, hv, baseTurns };
        });

        // Helper function to enforce parity (even/odd) on a number
        const applyParityEnforcement = (value: number, parity: null | 'even' | 'odd'): number => {
            if (parity === null) return value;
            const isEven = value % 2 === 0;
            if (parity === 'even') {
                return isEven ? value : value + 1; // Make it even
            } else { // parity === 'odd'
                return isEven ? value + 1 : value; // Make it odd
            }
        };

        // If target difference is set, adjust turns to achieve that difference
        let adjustedTurns: number[] = [];
        if (targetTurnsDifference !== null && targetTurnsDifference > 0) {
            // Start from tap 3 (base tap) with its calculated turns
            const baseTap3Turns = baseCalculations[2].baseTurns;
            adjustedTurns = [
                baseTap3Turns + (targetTurnsDifference * 2), // Tap 1: +2 differences
                baseTap3Turns + targetTurnsDifference,        // Tap 2: +1 difference
                baseTap3Turns,                                // Tap 3: base
                baseTap3Turns - targetTurnsDifference,        // Tap 4: -1 difference
                baseTap3Turns - (targetTurnsDifference * 2)   // Tap 5: -2 differences
            ];
        } else {
            // Use calculated turns from HV/V/T
            adjustedTurns = baseCalculations.map(b => b.baseTurns);
        }

        // Apply parity enforcement if enabled
        if (turnsParity !== null) {
            adjustedTurns = adjustedTurns.map(turns => applyParityEnforcement(turns, turnsParity));
        }

        const tapData = taps.map((tap, idx) => {
            const hv = baseCalculations[idx].hv;
            const totalTurns = adjustedTurns[idx];

            // Calculate Difference (difference from previous tap's total turns)
            const difference: number | null = idx > 0 ? adjustedTurns[idx - 1] - totalTurns : null;

            // Calculate Voltage Ratio: HV / LV
            const voltageRatio = lvVolts > 0 ? (hv / lvVolts).toFixed(4) : '0';

            // Calculate Turns Ratio: Total Turns / LV Turns
            const turnsRatio = lvTurns > 0 ? (totalTurns / lvTurns).toFixed(4) : '0';

            // Calculate % Error: (Turns Ratio / Voltage Ratio) - 1
            const percentErrorNum = parseFloat(voltageRatio) > 0
                ? (((parseFloat(turnsRatio) / parseFloat(voltageRatio)) - 1) * 100)
                : 0;
            const percentError = percentErrorNum.toFixed(4);

            // Check if error is outside -0.3% to +0.3% range
            const isErrorOutOfRange = percentErrorNum < -0.3 || percentErrorNum > 0.3;

            // Calculate HV Rated Line Current: MIN(kVA) * 1000 / (HV * sqrt(3))
            const hvRatedLineCurrent = hv > 0 && minKva > 0
                ? ((minKva * 1000) / (hv * Math.sqrt(3))).toFixed(2)
                : '0';

            // Calculate HV MAX Line Current: HV Rated * (MAX(kVA) / MIN(kVA))
            const hvMaxLineCurrent = parseFloat(hvRatedLineCurrent) > 0 && minKva > 0 && maxKva > 0
                ? (parseFloat(hvRatedLineCurrent) * (maxKva / minKva)).toFixed(2)
                : '0';

            return {
                tap,
                hv,
                totalTurns,
                difference,
                voltageRatio,
                turnsRatio,
                percentError,
                percentErrorNum,
                isErrorOutOfRange,
                hvRatedLineCurrent,
                hvMaxLineCurrent
            };
        });

        return (
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 mb-6">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-sm font-bold text-slate-700 flex items-center">
                        <Table className="w-4 h-4 mr-2" />
                        Tap Calculations
                    </h3>
                    <div className="flex items-center space-x-2">
                        <span className="text-xs text-slate-600 font-medium">Target Difference:</span>

                        {/* Manual Input with +/- buttons */}
                        <div className="flex items-center space-x-1 bg-slate-100 p-1 rounded-lg">
                            <button
                                onClick={() => {
                                    const currentVal = targetTurnsDifference || 0;
                                    updateField('targetTurnsDifference', Math.max(1, currentVal - 1));
                                }}
                                className="w-6 h-6 flex items-center justify-center bg-white rounded border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all"
                                title="Decrement by 1"
                            >
                                −
                            </button>
                            <input
                                type="number"
                                value={targetTurnsDifference === null ? '' : targetTurnsDifference}
                                onChange={(e) => {
                                    const val = e.target.value === '' ? null : parseInt(e.target.value);
                                    updateField('targetTurnsDifference', val);
                                }}
                                placeholder="Manual"
                                className="w-16 px-2 py-1 text-xs font-bold text-center rounded-md border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                            />
                            <button
                                onClick={() => {
                                    const currentVal = targetTurnsDifference || 0;
                                    updateField('targetTurnsDifference', currentVal + 1);
                                }}
                                className="w-6 h-6 flex items-center justify-center bg-white rounded border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all"
                                title="Increment by 1"
                            >
                                +
                            </button>
                        </div>

                        {/* Preset buttons */}
                        <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg">
                            {suggestedDifferences.map((diff) => (
                                <button
                                    key={diff}
                                    onClick={() => updateField('targetTurnsDifference', diff)}
                                    className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${targetTurnsDifference === diff
                                        ? 'bg-indigo-600 text-white shadow-sm'
                                        : 'text-slate-600 hover:bg-white hover:text-slate-800'
                                        }`}
                                >
                                    {diff}
                                </button>
                            ))}
                            <button
                                onClick={() => updateField('targetTurnsDifference', null)}
                                className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${targetTurnsDifference === null
                                    ? 'bg-slate-600 text-white shadow-sm'
                                    : 'text-slate-400 hover:bg-white hover:text-slate-600'
                                    }`}
                                title="Auto (calculate from HV/V/T)"
                            >
                                Auto
                            </button>
                        </div>
                    </div>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-xs border-collapse border border-slate-300">
                        <thead>
                            <tr className="bg-slate-100">
                                <th className="border border-slate-300 p-2 font-bold text-center">Tap</th>
                                <th className="border border-slate-300 p-2 font-bold text-center">HV</th>
                                <th className="border border-slate-300 p-2 font-bold text-center relative">
                                    <div className="flex flex-col items-center space-y-1">
                                        <button
                                            onClick={() => {
                                                const nextState = turnsParity === null ? 'even' : (turnsParity === 'even' ? 'odd' : null);
                                                setPageState(prev => ({ ...prev, turnsParity: nextState }));
                                            }}
                                            className={`w-full px-2 py-1 text-[10px] font-bold rounded transition-all ${turnsParity === 'even'
                                                ? 'bg-blue-600 text-white'
                                                : turnsParity === 'odd'
                                                    ? 'bg-purple-600 text-white'
                                                    : 'bg-slate-300 text-slate-600 hover:bg-slate-400'
                                                }`}
                                            title={`Current: ${turnsParity === null ? 'Disabled' : turnsParity === 'even' ? 'All Even' : 'All Odd'} - Click to toggle`}
                                        >
                                            {turnsParity === null ? 'OFF' : turnsParity === 'even' ? 'EVEN' : 'ODD'}
                                        </button>
                                        <span>Total Turns</span>
                                    </div>
                                </th>
                                <th className="border border-slate-300 p-2 font-bold text-center">Difference</th>
                                <th className="border border-slate-300 p-2 font-bold text-center">Voltage Ratio</th>
                                <th className="border border-slate-300 p-2 font-bold text-center">Turns Ratio</th>
                                <th className="border border-slate-300 p-2 font-bold text-center">% Error</th>
                                <th className="border border-slate-300 p-2 font-bold text-center">HV Rated Line Current</th>
                                <th className="border border-slate-300 p-2 font-bold text-center">HV MAX Line Current</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(() => {
                                // Check if all differences match (excluding null/first tap)
                                const validDifferences = tapData.map(t => t.difference).filter(d => d !== null) as number[];
                                const allDifferencesMatch = validDifferences.length > 0 &&
                                    validDifferences.every(d => d === validDifferences[0]);

                                return tapData.map((tap) => (
                                    <tr key={tap.tap} className="hover:bg-slate-50">
                                        <td className="border border-slate-300 p-2 text-center font-bold">{tap.tap}</td>
                                        <td className="border border-slate-300 p-2 text-center font-mono">{tap.hv}</td>
                                        <td className="border border-slate-300 p-2 text-center font-mono">{tap.totalTurns}</td>
                                        <td className={`border border-slate-300 p-2 text-center font-mono font-bold ${tap.difference !== null && allDifferencesMatch
                                            ? 'text-emerald-600'
                                            : ''
                                            }`}>
                                            {tap.difference !== null ? tap.difference : ''}
                                        </td>
                                        <td className="border border-slate-300 p-2 text-center font-mono">{tap.voltageRatio}</td>
                                        <td className="border border-slate-300 p-2 text-center font-mono">{tap.turnsRatio}</td>
                                        <td className={`border border-slate-300 p-2 text-center font-mono font-bold ${tap.isErrorOutOfRange ? 'bg-red-100 text-red-700' : ''
                                            }`}>
                                            {tap.percentError}%
                                        </td>
                                        <td className="border border-slate-300 p-2 text-center font-mono">{tap.hvRatedLineCurrent}</td>
                                        <td className="border border-slate-300 p-2 text-center font-mono">{tap.hvMaxLineCurrent}</td>
                                    </tr>
                                ));
                            })()}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    };

    return (
        <div className="space-y-6 animate-fadeIn pb-12">
            <div className="flex items-center justify-between mb-4">
                <button onClick={onBack} className="flex items-center text-slate-600 hover:text-slate-900 transition-colors bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm hover:shadow-md">
                    <ArrowLeft className="w-4 h-4 mr-2" /> Back to Main
                </button>
                <div className="flex items-center space-x-3">
                    <button onClick={() => setShowDebug(!showDebug)} className={`flex items-center px-3 py-2 rounded-lg text-xs font-mono transition-colors border ${showDebug ? 'bg-slate-800 text-white border-slate-800' : 'bg-white text-slate-500 border-slate-200 hover:border-slate-400'}`}>
                        <Terminal className="w-3 h-3 mr-2" />
                        {showDebug ? 'Hide Debug' : 'Show Debug Log'}
                    </button>
                    <h2 className="text-xl font-bold text-slate-800 hidden md:block">AT</h2>
                </div>
            </div>

            {showDebug && data?.debugLog && (
                <div className="bg-slate-900 rounded-xl shadow-lg border border-slate-800 overflow-hidden text-left relative mb-6">
                    <div className="flex justify-between items-center px-4 py-2 bg-slate-950 border-b border-slate-800">
                        <span className="text-xs font-mono text-slate-400">Extraction Log</span>
                        <button onClick={() => setShowDebug(false)} className="text-slate-500 hover:text-white"><X className="w-4 h-4" /></button>
                    </div>

                    {/* KS THK DEBUG SECTION */}
                    <div className="bg-slate-800 border-b border-slate-700 px-4 py-2">
                        <h4 className="text-xs font-bold text-amber-500 uppercase tracking-wider mb-1">KS Thk / # Btwn Disc Debug</h4>
                        <div className="grid grid-cols-3 gap-4 text-[10px] font-mono">
                            <div>
                                <span className="text-slate-400">Winding 1: </span>
                                <span className="text-white bg-slate-700 px-1 rounded">{data.wdg1.ksThk || 'null'}</span>
                            </div>
                            <div>
                                <span className="text-slate-400">Winding 2: </span>
                                <span className="text-white bg-slate-700 px-1 rounded">{data.wdg2.ksThk || 'null'}</span>
                            </div>
                            <div>
                                <span className="text-slate-400">Winding 3: </span>
                                <span className="text-white bg-slate-700 px-1 rounded">{data.wdg3.ksThk || 'null'}</span>
                            </div>
                        </div>
                    </div>

                    <div className="p-4 overflow-x-auto max-h-64 overflow-y-auto">
                        <div className="mb-2 pb-2 border-b border-slate-800">
                            <span className="text-[10px] font-bold text-slate-500">Filtered KS THK Logs:</span>
                            {data.debugLog.filter(l => l.includes("[KS THK]")).map((log, i) => (
                                <div key={i} className="text-[10px] font-mono text-amber-300">{log}</div>
                            ))}
                        </div>
                        <pre className="text-[10px] font-mono text-emerald-400 whitespace-pre-wrap leading-relaxed">{data.debugLog.join('\n')}</pre>
                    </div>
                </div>
            )}

            {/* RATINGS & VOLTAGES TABLE */}
            {renderKvaTable()}

            {/* TAP CALCULATION TABLE */}
            {renderTapCalculationTable()}

            {/* COLLAPSIBLE AT SECTION */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden transition-all duration-300">
                <div
                    className="px-4 py-3 bg-slate-50 border-b border-slate-100 flex justify-between items-center cursor-pointer hover:bg-slate-100 transition-colors"
                    onClick={() => setIsAtExpanded(!isAtExpanded)}
                >
                    <div className="flex items-center">
                        <Sliders className="w-5 h-5 mr-2 text-indigo-500" />
                        <h3 className="text-lg font-semibold text-slate-700">AT</h3>
                        <span className="ml-2 text-[10px] text-slate-400 font-normal">
                            {isAtExpanded ? '(Click to collapse)' : '(Click to expand)'}
                        </span>
                    </div>
                    {isAtExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                </div>

                {isAtExpanded && (
                    <div className="p-6 animate-fadeIn">
                        {renderAtTable()}
                    </div>
                )}
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-lg font-semibold text-slate-700 flex items-center">
                        <Layers className="w-5 h-5 mr-2 text-indigo-500" />
                        Disc Distribution
                    </h3>
                    <div className="flex items-center space-x-2">
                        <button onClick={handleResetOverrides} className="flex items-center px-2 py-1 bg-white border border-slate-200 text-slate-500 hover:text-rose-600 hover:border-rose-200 rounded text-xs font-medium transition-colors">
                            <RotateCcw className="w-3 h-3 mr-1.5" /> Reset
                        </button>
                        <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg ml-2">
                            <button onClick={() => { setNumGroups(1); setNumGroupsManuallySet(true); }} className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${numGroups === 1 ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>1 Group</button>
                            <button onClick={() => { setNumGroups(2); setNumGroupsManuallySet(true); }} className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${numGroups === 2 ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>2 Groups</button>
                        </div>
                        {numGroups === 1 && (
                            <button
                                onClick={() => setPageState(prev => ({ ...prev, splitTapMode: !splitTapMode }))}
                                className={`flex items-center px-3 py-1 text-xs font-bold rounded-md transition-all ml-2 ${splitTapMode
                                    ? 'bg-amber-500 text-white shadow-sm'
                                    : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                                    }`}
                                title={splitTapMode ? "Split Tap Mode: 2 tap zones (top & bottom)" : "Click to enable Split Tap Mode"}
                            >
                                {splitTapMode && <Check className="w-3 h-3 mr-1" />}
                                Split Tap
                            </button>
                        )}
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="space-y-6">
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Total Discs</label>
                                <div className="flex items-center space-x-1">
                                    <button
                                        onClick={() => updateField('outermostDiscs', (outermostDiscs !== null ? outermostDiscs : totalDiscsTarget) - 1)}
                                        className="w-6 h-6 flex items-center justify-center bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded text-slate-700 font-bold"
                                    >
                                        −
                                    </button>
                                    <input
                                        type="number"
                                        className="w-16 text-xl font-mono font-bold text-slate-800 text-center border border-slate-300 rounded px-1 py-0.5"
                                        value={outermostDiscs !== null ? outermostDiscs : totalDiscsTarget}
                                        onChange={(e) => updateField('outermostDiscs', parseFloat(e.target.value) || 0)}
                                    />
                                    <button
                                        onClick={() => updateField('outermostDiscs', (outermostDiscs !== null ? outermostDiscs : totalDiscsTarget) + 1)}
                                        className="w-6 h-6 flex items-center justify-center bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded text-slate-700 font-bold"
                                    >
                                        +
                                    </button>
                                    {outermostDiscs !== null && (
                                        <button
                                            onClick={() => updateField('outermostDiscs', null)}
                                            className="text-[9px] px-1.5 py-0.5 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded text-amber-700"
                                            title="Reset to PDF value"
                                        >
                                            Auto
                                        </button>
                                    )}
                                </div>
                            </div>
                            <div>
                                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Total Drop</label>
                                <div className="text-2xl font-mono font-bold text-slate-800">{totalDrop}</div>
                            </div>
                        </div>

                        {/* NEW: Tap-Calculated Values Display */}
                        <div className="border-t border-slate-200 pt-4">
                            <label className="block text-[10px] font-bold text-purple-600 uppercase mb-3">From Tap Calculations</label>
                            <div className="grid grid-cols-2 gap-4">
                                {/* Column 1: All Turns */}
                                <div className="space-y-2">
                                    <div>
                                        <label className="block text-[9px] font-semibold text-slate-500 mb-1">Max Turns</label>
                                        <div className="text-sm font-mono font-bold text-purple-700 bg-purple-50 px-2 py-1 rounded border border-purple-200">
                                            {outerAt.max || 0}
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-[9px] font-semibold text-slate-500 mb-1">Rated Turns</label>
                                        <div className="text-sm font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-1 rounded border border-indigo-200">
                                            {outerAt.rated || 0}
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-[9px] font-semibold text-slate-500 mb-1">Min Turns</label>
                                        <div className="text-sm font-mono font-bold text-blue-700 bg-blue-50 px-2 py-1 rounded border border-blue-200">
                                            {outerAt.min || 0}
                                        </div>
                                    </div>
                                </div>

                                {/* Column 2: TPD */}
                                <div>
                                    <label className="block text-[9px] font-semibold text-slate-500 mb-1">Turns/Disc</label>
                                    <div className="text-base font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded border border-emerald-200">
                                        {(outerAt.tpd || 0).toFixed(4)}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-2">Tap Discs</label>
                            <div className="flex space-x-2">
                                <button onClick={() => setTapDiscs(4)} className={`flex-1 py-2 text-sm font-bold border rounded-lg transition-colors ${tapDiscs === 4 ? 'border-amber-500 bg-amber-50 text-amber-700' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}>4</button>
                                <button onClick={() => setTapDiscs(8)} className={`flex-1 py-2 text-sm font-bold border rounded-lg transition-colors ${tapDiscs === 8 ? 'border-amber-500 bg-amber-50 text-amber-700' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}>8</button>
                            </div>
                        </div>
                        <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-2">Segments</label>
                            <div className="flex flex-wrap gap-2">
                                {(splitTapMode ? [6, 8] : (numGroups === 1 ? [3, 5, 7] : [6, 8, 10])).map(n => (
                                    <button key={n} onClick={() => setNumSections(n)} className={`flex-1 py-2 text-xs border rounded-lg transition-colors ${numSections === n ? 'border-indigo-500 bg-indigo-50 text-indigo-700 font-bold' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}>{n} Sect</button>
                                ))}
                            </div>
                        </div>
                    </div>

                    <div className="col-span-2 bg-slate-50 rounded-xl border border-slate-200 p-6 flex flex-row items-start justify-center space-x-4 overflow-x-auto min-h-[300px]">

                        {/* 1. Inner Winding Columns (Calculated & Styled) */}
                        {renderInnerWindingColumns()}

                        {/* 2. Outer Winding Column (Interactive) */}
                        {discSections.length > 0 ? (
                            <div className="flex items-start space-x-2 mb-4">
                                {/* SEGMENTS COLUMN */}
                                <div className="flex flex-col space-y-1 flex-1">
                                    <div className="text-center font-bold text-xs uppercase mb-2 py-1 rounded border text-purple-700 bg-purple-50 border-purple-200">{outerWindingName} (Main)</div>
                                    {discSections.map((sec, idx) => (
                                        <div key={sec.id} className={`relative flex items-center justify-between px-3 border transition-all hover:scale-[1.01] rounded-md shadow-sm group ${sec.type === 'tap' ? 'bg-amber-100 border-amber-300 text-amber-900' : 'bg-blue-100 border-blue-300 text-blue-900'} ${disabledDropIndices.includes(idx) && sec.type === 'normal' ? 'opacity-70 bg-slate-100 border-slate-300 text-slate-500' : ''}`} style={{ height: `${Math.max(34, Math.min(50, sec.count * 2.5))}px` }}>
                                            <div className="flex items-center justify-between w-full">
                                                <div className="flex items-center space-x-2">
                                                    <span className="text-sm font-mono font-bold leading-tight">{sec.count} Discs</span>
                                                    {sec.type === 'normal' && (
                                                        <div className="flex flex-col space-y-0.5 ml-1">
                                                            <button onClick={() => handleDiscOverride(idx, 1)} className="w-3 h-3 flex items-center justify-center bg-slate-100 hover:bg-white border border-slate-200 rounded text-[8px] text-slate-600">+</button>
                                                            <button onClick={() => handleDiscOverride(idx, -1)} className="w-3 h-3 flex items-center justify-center bg-slate-100 hover:bg-white border border-slate-200 rounded text-[8px] text-slate-600">-</button>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="flex items-center space-x-3">
                                                    <div className="flex items-center space-x-1 bg-white/60 px-2 py-0.5 rounded border border-slate-200">
                                                        <span className="text-[9px] opacity-70 mr-1">KS:</span>
                                                        <button
                                                            onClick={() => handleExtraKSChange(sec.id, -1)}
                                                            className="w-4 h-4 flex items-center justify-center bg-white hover:bg-rose-50 border border-slate-300 rounded text-[10px] text-slate-600 hover:text-rose-600 font-bold leading-none"
                                                            title="Decrease Extra KS"
                                                        >
                                                            -
                                                        </button>
                                                        <span className="text-[10px] w-4 text-center font-mono font-bold leading-none">{Math.round(extraKSPerSegment[sec.id] || 0)}</span>
                                                        <button
                                                            onClick={() => handleExtraKSChange(sec.id, 1)}
                                                            className="w-4 h-4 flex items-center justify-center bg-white hover:bg-emerald-50 border border-slate-300 rounded text-[10px] text-slate-600 hover:text-emerald-600 font-bold leading-none"
                                                            title="Increase Extra KS"
                                                        >
                                                            +
                                                        </button>
                                                    </div>
                                                    {sec.type === 'tap' && hasTapNoDropWarning && (
                                                        <span title="Tap zone matches ceil(TPD)*2, but not floor(TPD)*2 for drop">
                                                            <AlertTriangle className="w-4 h-4 text-rose-500" />
                                                        </span>
                                                    )}
                                                    {sec.drop > 0 && <span className="text-[10px] font-mono font-bold text-rose-600 bg-white/60 px-1.5 py-0.5 rounded">Drop: {sec.drop}</span>}
                                                    <span className="text-[10px] opacity-50 font-mono w-16 text-right">({sec.calculatedTurns.toFixed(3)} T)</span>
                                                </div>
                                            </div>
                                            {idx === 0 && (sec.type === 'normal') && (
                                                <div className="absolute right-full mr-2 top-0 h-full flex flex-col justify-center space-y-1">
                                                    <button onClick={() => handleTopDropChange(1)} className="p-0.5 rounded bg-white border border-slate-200 hover:bg-slate-50 text-slate-500 shadow-sm"><Plus className="w-2.5 h-2.5" /></button>
                                                    <button onClick={() => handleTopDropChange(-1)} className="p-0.5 rounded bg-white border border-slate-200 hover:bg-slate-50 text-slate-500 shadow-sm"><Minus className="w-2.5 h-2.5" /></button>
                                                </div>
                                            )}
                                            {sec.type === 'normal' && !sec.isEnd && (
                                                <button onClick={() => toggleSectionDrop(idx)} className={`absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-full bg-white shadow-sm border ${disabledDropIndices.includes(idx) ? 'text-slate-300 border-slate-200' : 'text-indigo-400 border-indigo-100 hover:text-indigo-600 hover:border-indigo-300'}`} title={disabledDropIndices.includes(idx) ? "Enable Drop" : "Disable Drop"}>
                                                    {disabledDropIndices.includes(idx) ? <Ban className="w-3 h-3" /> : <Droplet className="w-3 h-3" />}
                                                </button>
                                            )}
                                        </div>
                                    ))}
                                    {/* SUMMARY STATS */}
                                    <div className="w-full max-w-sm flex flex-col space-y-2 text-xs border-t border-slate-200 pt-3 mt-2 bg-white p-3 rounded-lg shadow-sm">
                                        <div className="flex justify-between items-center">
                                            <div className="flex flex-col items-center flex-1">
                                                <span className="text-slate-400 font-medium text-[10px] uppercase">Calculated Discs</span>
                                                <div className={`font-mono font-bold ${totals.discs !== totalDiscsTarget ? 'text-rose-600' : 'text-emerald-600'}`}>{totals.discs} <span className="text-slate-400 font-normal">/ {totalDiscsTarget}</span></div>
                                            </div>
                                            <div className="flex flex-col items-center flex-1">
                                                <span className="text-slate-400 font-medium text-[10px] uppercase">Calculated Turns</span>
                                                <div className={`font-mono font-bold ${Math.abs(totals.turns - maxTurnsTarget) > 0.1 ? 'text-rose-600' : 'text-emerald-600'}`}>{totals.turns.toFixed(3)} <span className="text-slate-400 font-normal">/ {maxTurnsTarget}</span></div>
                                            </div>
                                        </div>
                                        <div className="flex justify-center items-center pt-2 border-t border-slate-100">
                                            <div className="flex flex-col items-center">
                                                <span className="text-slate-400 font-medium text-[10px] uppercase">KS (UTILIZED / REQUIRED)</span>
                                                <div className={`font-mono font-bold ${(() => {
                                                    const outmostIdx = windingCount - 1;
                                                    const targetKS = extraKSPerWinding[outmostIdx] !== undefined ? extraKSPerWinding[outmostIdx] : totalAddKSColGrp;
                                                    const utilizedKS = Object.values(extraKSPerSegment).reduce((sum: number, val) => sum + (typeof val === 'number' ? val : 0), 0);
                                                    return utilizedKS !== targetKS ? 'text-amber-600' : 'text-emerald-600';
                                                })()}`}>
                                                    {Object.values(extraKSPerSegment).reduce((sum: number, val) => sum + (typeof val === 'number' ? val : 0), 0)} <span className="text-slate-400 font-normal">/ {(() => {
                                                        const outmostIdx = windingCount - 1;
                                                        return extraKSPerWinding[outmostIdx] !== undefined ? extraKSPerWinding[outmostIdx] : totalAddKSColGrp;
                                                    })()}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* HT COLUMN (ALIGNED) */}
                                <div className="flex flex-col space-y-1">
                                    <div className="h-[28px]"></div> {/* Spacer for header */}
                                    {discSections.map((sec, idx) => {
                                        const isEnd = idx === 0 || idx === discSections.length - 1;
                                        const segmentHT = calculateSegmentHT(sec.count, sec.id, sec.type === 'tap', isEnd);

                                        // Calculate inner winding HT for difference
                                        // Use the same calculation method as renderInnerWindingColumns
                                        let innerHT = { totalHT: 0 };
                                        if (windingCount > 1) {
                                            const wIdx = windingCount - 2; // First inner winding (adjacent to outer)
                                            const cpc = getCorrectedPhaseCurrent(wIdx);
                                            const innerWdgKey = `wdg${wIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
                                            const innerWdg = data?.[innerWdgKey];

                                            if (innerWdg && cpc > 0) {
                                                const tpd = typeof innerWdg.lyrsVal === 'string' ? parseFloat(innerWdg.lyrsVal) : (innerWdg.lyrsVal || 0);
                                                const targetDiscs = innerWdg.discVal || (tpd > 0 && innerWdg.ratedTurns ? Math.round(innerWdg.ratedTurns / tpd) : 0);
                                                const targetTurns = innerWdg.maxTurns || innerWdg.ratedTurns || 0;
                                                const effectiveTpd = (targetDiscs > 0 && targetTurns > 0) ? (targetTurns / targetDiscs) : tpd;

                                                const outerAmpsRaw = parseFloat(String(outerAt.raw.ratedAmps || '0'));
                                                const outerAmps = numGroups === 2 ? outerAmpsRaw / 2 : outerAmpsRaw;

                                                if (effectiveTpd > 0) {
                                                    let effectiveOuterTurns = sec.calculatedTurns;
                                                    if (sec.type === 'tap') {
                                                        effectiveOuterTurns = effectiveOuterTurns / 2;
                                                    }
                                                    const innerTurns = (outerAmps * effectiveOuterTurns) / cpc;
                                                    const innerDiscs = innerTurns / effectiveTpd;
                                                    innerHT = calculateInnerSegmentHT(wIdx, innerDiscs, sec.id, sec.type === 'tap', targetDiscs, isEnd);
                                                }
                                            }
                                        }

                                        const difference = innerHT.totalHT - segmentHT.totalHT; // Winding1 - Winding2
                                        const isTap = sec.type === 'tap';
                                        const boxWidth = isTap ? 'min-w-[85px]' : 'min-w-[70px]';

                                        return (
                                            <div key={sec.id} className={`flex flex-row items-center justify-between bg-white border border-indigo-200 rounded-md shadow-sm px-2 py-1 ${boxWidth}`} style={{ height: `${Math.max(34, Math.min(50, sec.count * 2.5))}px` }}>
                                                {/* Column 1: HT Value */}
                                                <div className="flex flex-col items-center justify-center flex-1">
                                                    <span className="text-[10px] font-mono font-bold text-indigo-600">{segmentHT.totalHT.toFixed(2)}</span>
                                                    {isTap && (
                                                        <div className="flex flex-col items-center space-y-0 mt-1">
                                                            <div className="text-[8px] text-slate-600 font-mono font-bold">{segmentHT.baseHT.toFixed(2)}</div>
                                                            <div className="text-[8px] text-amber-700 font-mono font-bold">{segmentHT.extraKSHT.toFixed(2)}</div>
                                                        </div>
                                                    )}
                                                </div>

                                                {/* Column 2: Difference (Red) */}
                                                {windingCount > 1 && (
                                                    <div className="flex items-center justify-center pl-2 border-l border-indigo-100">
                                                        <div className="text-[10px] font-mono font-bold text-rose-600">
                                                            {difference > 0 ? '+' : ''}{difference.toFixed(2)}
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        );
                                    })}

                                    {/* TOTAL HT BOX FOR WINDING 2 (OUTERMOST) */}
                                    <div className="flex flex-col items-center bg-indigo-50 border-2 border-indigo-400 rounded-md shadow-md px-2 py-2 mt-2 min-w-[120px]">
                                        <div className="font-mono font-bold text-indigo-700 text-[10px]">{totalHT.toFixed(3)}</div>
                                        {designElecHt && designElecHt[windingCount - 1] && (
                                            <div className="text-xs text-slate-500 font-mono mt-0.5">/ {designElecHt[windingCount - 1].toFixed(3)}</div>
                                        )}
                                    </div>
                                </div>

                                {/* DISC PRESET CONTROLS (FAR RIGHT) */}
                                <div className="flex flex-col space-y-1 ml-2">
                                    <div className="h-[28px]"></div> {/* Spacer for header */}
                                    {[10, 14].map(btnVal => (
                                        <button key={btnVal} onClick={() => setTopDiscPreset(btnVal)} className={`text-xs w-8 py-1.5 rounded border font-bold ${(() => {
                                            const topIdx = discSections.findIndex(s => s.pos === 'top');
                                            const val = topIdx !== -1 && discOverrides[topIdx] !== undefined ? discOverrides[topIdx] : null;
                                            return val === btnVal ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-500 border-slate-200 hover:border-indigo-300';
                                        })()}`}>
                                            {btnVal}
                                        </button>
                                    ))}
                                    <button onClick={() => setTopDiscPreset(null)} className={`text-xs w-8 py-1.5 rounded border font-bold ${(() => {
                                        const topIdx = discSections.findIndex(s => s.pos === 'top');
                                        const val = topIdx !== -1 && discOverrides[topIdx] !== undefined ? discOverrides[topIdx] : null;
                                        return val === null ? 'bg-slate-200 text-slate-600 border-slate-300' : 'bg-white text-slate-400 border-slate-200 hover:border-slate-300';
                                    })()}`} title="Auto">
                                        A
                                    </button>
                                </div>
                            </div>
                        ) : <div className="text-slate-400 text-sm">Invalid configuration or Total Discs missing</div>}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Page4;
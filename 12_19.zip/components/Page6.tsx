
import React, { useState, useEffect } from 'react';
import { ArrowLeft, Copy, Check, ArrowUp, ArrowDown, Plus, Minus, Trash2, Scissors, List, Circle, Settings, Grid, PieChart, RotateCcw, Box, TrendingUp, Layers } from 'lucide-react';
import { ExtractedData, Page6State, StackItem, WindingAccessoryData } from '../types';

interface Page6Props {
  data: ExtractedData | null;
  onBack: () => void;
  windingNames: string[];
  windingCount: number;
  pageState: Page6State;
  setPageState: React.Dispatch<React.SetStateAction<Page6State>>;
}

type Vendor = 'ENPAY' | 'WEIDMAN';

const DEFAULT_ACCESSORY_DATA: WindingAccessoryData = {
    vtcPart: "12LS",
    ksQty: "6710",
    extraKS: 12,
    asItemIndex: -1,
    asT: 0.118,
    asH: 4,
    asR: 0.375,
    asS: 4,
    asBAdjust: 0,
    asVtcPart: "12RZ",
    acItemIndex: -1,
    acT: 0.118,
    acH: 6,
    acR: 0.375,
    acS: 4,
    acBAdjust: 0,
    acVtcPart: "12RC"
};

// Helper to clean names based on user rules
const cleanName = (rawName: string) => {
    let name = rawName.trim();
    const lower = name.toLowerCase();
    
    // Priority 1: Extract Known Materials if present in the string
    if (lower.includes('wdman tube')) return "Wdman Tube";
    if (lower.includes('wdman duct')) return "Wdman Duct";
    if (lower.includes('wdg stk') || lower.includes('wd stk') || lower.includes('winding stick')) return "Wd Wdg Stk";
    
    // Priority 2: Handling messy extractions
    if (lower.includes('core duct') && lower.includes('wdman')) {
         return lower.includes('tube') ? "Wdman Tube" : "Wdman Duct";
    }

    if (lower.startsWith('total') && lower.includes('->')) {
         if (lower.includes('wdma')) return "Wdman Tube";
         const parts = name.split('->');
         if (parts[1]) {
             let right = parts[1].trim();
             right = right.replace(/^[\d\.\s]+/, '');
             return right || "Wdman Tube";
         }
    }

    if (name.startsWith('+')) {
        const stripped = name.replace(/^\+\s*[\d\.]+\s*/, '');
        if (stripped.toLowerCase().includes('wdman duct')) return "Wdman Duct";
        if (stripped.toLowerCase().includes('wdman tube')) return "Wdman Tube";
        return stripped;
    }

    if (lower.includes('core-end-duct')) return "Wd Wdg Stk";
    if (lower.includes('tube-end-duct')) return "Wdman Duct"; 
    
    if (lower.match(/tube/)) return "Wdman Tube";
    if (lower.match(/duct/)) return "Wdman Duct";

    name = name.replace(/^[\d\.\s]+/, '');
    name = name.replace(/total\s*->\s*/i, '');
    
    if (name.includes('=')) {
        const parts = name.split('=');
        if (parts[1]) {
            let right = parts[1].trim();
            right = right.replace(/^[\d\.\s]+(thk)?\s*/i, '');
            if (right) name = right;
        }
    }

    return name;
};

// Helper to determine if item goes into Tube List
const determineIsTube = (name: string) => {
    const lower = name.toLowerCase();
    
    if (lower.includes('duct')) return false;
    if (lower.includes('stk')) return false;
    if (lower.includes('wdg')) return false;
    if (lower.includes('winding')) return false;
    if (lower.startsWith('total') || lower.includes('total ->')) return false;
    
    if (lower.includes('tube') || lower.includes('cylinder') || lower.includes('major')) return true;
    
    return false;
};

const Page6: React.FC<Page6Props> = ({ data, onBack, windingNames, windingCount, pageState, setPageState }) => {
  const [copySuccess, setCopySuccess] = useState(false);
  const [tubeCopySuccess, setTubeCopySuccess] = useState(false);
  const [stickCopySuccess, setStickCopySuccess] = useState(false);
  const [idSealCopySuccess, setIdSealCopySuccess] = useState(false);
  const [odSealCopySuccess, setOdSealCopySuccess] = useState(false);
  const [ctcCopySuccess, setCtcCopySuccess] = useState(false);
  const [headSheetCopySuccess, setHeadSheetCopySuccess] = useState(false);

  // Destructure state
  const {
      isInitialized,
      items,
      baseOD,
      selectedVendor,
      washerWindingIndex,
      calculationMethod,
      tubeTolerance,
      windingAccessories,
      idSealState, idSealRounding, odSealState, odSealRounding,
      headSheet
  } = pageState;

  // Setters
  const setItems = (newItems: StackItem[]) => setPageState(prev => ({ ...prev, items: newItems }));
  const setBaseOD = (val: number) => setPageState(prev => ({ ...prev, baseOD: val }));
  const setInitialized = () => setPageState(prev => ({ ...prev, isInitialized: true }));
  const setSelectedVendor = (v: Vendor) => setPageState(prev => ({ ...prev, selectedVendor: v }));
  const setWasherWindingIndex = (v: number) => setPageState(prev => ({ ...prev, washerWindingIndex: v }));
  const setCalculationMethod = (v: 'mround' | 'ceiling') => setPageState(prev => ({ ...prev, calculationMethod: v }));
  const setTubeTolerance = (v: number) => setPageState(prev => ({ ...prev, tubeTolerance: v }));

  // Helper to update accessory data for current winding
  const updateAccessoryData = (field: keyof WindingAccessoryData, val: any) => {
      setPageState(prev => {
          const currentData = prev.windingAccessories[washerWindingIndex] || { ...DEFAULT_ACCESSORY_DATA };
          return {
              ...prev,
              windingAccessories: {
                  ...prev.windingAccessories,
                  [washerWindingIndex]: { ...currentData, [field]: val }
              }
          };
      });
  };

  // Get current winding accessory data
  const currentAccessoryData = windingAccessories[washerWindingIndex] || DEFAULT_ACCESSORY_DATA;

  // Setters mapped to current winding
  const setVtcPart = (v: string) => updateAccessoryData('vtcPart', v);
  const setKsQty = (v: string) => updateAccessoryData('ksQty', v);
  const setExtraKS = (v: number) => updateAccessoryData('extraKS', v);

  // Angle Sector Setters
  const setAsItemIndex = (v: number) => updateAccessoryData('asItemIndex', v);
  const setAsT = (v: number) => updateAccessoryData('asT', v);
  const setAsH = (v: number) => updateAccessoryData('asH', v);
  const setAsR = (v: number) => updateAccessoryData('asR', v);
  const setAsS = (v: number) => updateAccessoryData('asS', v);
  const setAsBAdjust = (cb: (prev: number) => number) => updateAccessoryData('asBAdjust', cb(currentAccessoryData.asBAdjust));
  const setAsVtcPart = (v: string) => updateAccessoryData('asVtcPart', v);

  // Angle Cap Setters
  const setAcItemIndex = (v: number) => updateAccessoryData('acItemIndex', v);
  const setAcT = (v: number) => updateAccessoryData('acT', v);
  const setAcH = (v: number) => updateAccessoryData('acH', v);
  const setAcR = (v: number) => updateAccessoryData('acR', v);
  const setAcS = (v: number) => updateAccessoryData('acS', v);
  const setAcBAdjust = (cb: (prev: number) => number) => updateAccessoryData('acBAdjust', cb(currentAccessoryData.acBAdjust));
  const setAcVtcPart = (v: string) => updateAccessoryData('acVtcPart', v);

  const setIdSealState = (cb: (prev: any) => any) => setPageState(prev => ({ ...prev, idSealState: cb(prev.idSealState) }));
  const setOdSealState = (cb: (prev: any) => any) => setPageState(prev => ({ ...prev, odSealState: cb(prev.odSealState) }));

  // Seal Rounding Setters
  const setIdSealRounding = (field: 'id' | 'od', mode: 'C' | 'F' | 'M') => setPageState(prev => ({ ...prev, idSealRounding: { ...prev.idSealRounding, [field]: mode } }));
  const setOdSealRounding = (field: 'id' | 'od', mode: 'C' | 'F' | 'M') => setPageState(prev => ({ ...prev, odSealRounding: { ...prev.odSealRounding, [field]: mode } }));
  
  // Head Sheet Setters
  const setHeadSheet = (field: keyof typeof headSheet, val: any) => {
      setPageState(prev => ({
          ...prev,
          headSheet: { ...prev.headSheet, [field]: val }
      }));
  };

  // Effect to set default calculation method when winding changes
  useEffect(() => {
    if (washerWindingIndex === windingCount - 1) {
        setCalculationMethod('ceiling');
    } else {
        setCalculationMethod('mround');
    }
  }, [washerWindingIndex, windingCount]);

  // Effect to Calculate KS Qty dynamically for the current winding
  useEffect(() => {
      if (!data) return;
      const key = `wdg${washerWindingIndex + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
      const w = data[key];
      
      // Formula: ((disc - 1) * 2 + extra_ks) * ks/circle * 3 * 1.03
      const discs = w?.discVal || 0; // Trns/Lyr is often discs
      const ksCircle = parseFloat(String(w?.ksCircle || '0'));
      const extraKS = currentAccessoryData.extraKS;
      
      if (discs > 0 && ksCircle > 0) {
          const calculated = ((discs - 1) * 2 + extraKS) * ksCircle * 3 * 1.03;
          // Only update if different to avoid loop
          const newQty = Math.ceil(calculated).toString();
          if (newQty !== currentAccessoryData.ksQty) {
              setKsQty(newQty);
          }
      }
  }, [washerWindingIndex, currentAccessoryData.extraKS, data]); 

  // MROUND Helper
  const mround = (val: number, multiple: number) => {
    if (!multiple) return val;
    return Math.round(val / multiple) * multiple;
  };

  // Ceiling Helper
  const ceiling = (val: number, multiple: number) => {
    if (!multiple) return val;
    return Math.ceil(val / multiple) * multiple;
  };
  
  // Floor Helper
  const floor = (val: number, multiple: number) => {
    if (!multiple) return val;
    return Math.floor(val / multiple) * multiple;
  };

  // Apply Rounding Helper
  const applyRounding = (val: number, mode: 'C' | 'F' | 'M') => {
      switch (mode) {
          case 'C': return ceiling(val, 0.0625);
          case 'F': return floor(val, 0.0625);
          case 'M': return mround(val, 0.0625);
          default: return val;
      }
  };

  // Initialize Stack from ExtractedData ONLY if not already initialized
  useEffect(() => {
    if (!data || isInitialized) return;

    const coreFe = parseFloat(data.core.feCircle || '0');
    setBaseOD(coreFe);

    const generateId = () => Math.random().toString(36).substr(2, 9);
    
    const createItem = (rawName: string, thkStr: string, qty: string = '-', len: string = '-', type: StackItem['type'] = 'insulation') => {
        const cleanedName = cleanName(rawName);
        return {
            id: generateId(),
            name: cleanedName,
            thk: parseFloat(thkStr) || 0,
            length: len,
            qty: qty,
            type: type,
            isTube: determineIsTube(cleanedName),
            roundingMode: null as any
        };
    };

    const buckets: Record<string, StackItem[]> = {
        core: [], major1: [], major2: [], cover: [], other: []
    };

    if (data.tubeTables) {
        data.tubeTables.forEach(table => {
            const lowerTitle = table.title.toLowerCase();
            
            // Count Wdman Tubes to determine if numbering is needed
            const wdmanTubeCount = table.rows.filter(r => cleanName(r.material) === "Wdman Tube").length;
            let wdmanTubeCounter = 0;

            const tableItems = table.rows.map(row => {
                const item = createItem(row.material, row.thk, row.qty);
                // Link names to main page tube details conventions
                if (item.name === "Wdman Tube") {
                    wdmanTubeCounter++;
                    const suffix = wdmanTubeCount > 1 ? `-${wdmanTubeCounter}` : '';

                    if (lowerTitle.includes('cover')) {
                        item.name = `Cover Tube${suffix}`;
                    } else if (lowerTitle.includes('major 1') || lowerTitle.includes('major i')) {
                        item.name = `Major 1 Tube${suffix}`;
                    } else if (lowerTitle.includes('major 2') || lowerTitle.includes('major ii')) {
                        item.name = `Major 2 Tube${suffix}`;
                    } else if (lowerTitle.includes('core')) {
                        item.name = `Core Tube${suffix}`;
                    } else if (lowerTitle.includes('major')) {
                        item.name = `Major Tube${suffix}`;
                    }
                }
                return item;
            });

            if ((lowerTitle.includes('core') || lowerTitle.includes('weight') || lowerTitle.includes('tube')) && !lowerTitle.includes('cover') && !lowerTitle.includes('major')) {
                buckets.core.push(...tableItems);
            } else if (lowerTitle.includes('cover')) {
                buckets.cover.push(...tableItems);
            } else if (lowerTitle.includes('major')) {
                if (lowerTitle.match(/major\s*2/) || lowerTitle.match(/major\s*ii/) || lowerTitle.includes('major-2')) {
                    buckets.major2.push(...tableItems);
                } else if (lowerTitle.match(/major\s*1/) || lowerTitle.match(/major\s*i/) || lowerTitle.includes('major-1')) {
                    buckets.major1.push(...tableItems);
                } else {
                    if (buckets.major1.length === 0) buckets.major1.push(...tableItems);
                    else buckets.major2.push(...tableItems);
                }
            } else {
                if (buckets.core.length === 0) buckets.core.push(...tableItems);
                else buckets.other.push(...tableItems);
            }
        });
    }

    const newItems: StackItem[] = [];
    const newIdSealState: Record<string, any> = {};
    const newOdSealState: Record<string, any> = {};

    const addWinding = (wIdx: number) => {
      const key = `wdg${wIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
      const w = data[key];
      const typeStr = w.type ? ` (${w.type})` : '';
      const name = `${windingNames[wIdx]}${typeStr} Radial`;
      const thk = parseFloat(String(w.radial || '0'));
      const length = String(w.wireSpaceMech || '-');
      const id = generateId();
      
      // Initialize ID Seal State for this winding
      newIdSealState[id] = { qtyOpt: 3, t: 0.079, c: 0.75, vtcPart: "12118855T" };
      
      // Initialize OD Seal State for this winding
      newOdSealState[id] = { t: 0.079, c: 0.75, vtcPart: "12118855T" };
      
      newItems.push({
        id, name, thk: isNaN(thk) ? 0 : thk, length, qty: '1', type: 'winding', isTube: false, roundingMode: null
      });
    };

    newItems.push(...buckets.core);
    addWinding(0);
    newItems.push(...buckets.major1);
    addWinding(1);
    newItems.push(...buckets.major2);
    if (windingCount > 2) addWinding(2);
    newItems.push(...buckets.other);
    newItems.push(...buckets.cover);

    setItems(newItems);
    setIdSealState(() => newIdSealState);
    setOdSealState(() => newOdSealState);
    setWasherWindingIndex(Math.max(0, windingCount - 1));
    setInitialized();

  }, [data, windingNames, windingCount, isInitialized]);

  const handleMove = (index: number, direction: -1 | 1) => {
      const newItems = [...items];
      if (direction === -1 && index > 0) {
          [newItems[index], newItems[index - 1]] = [newItems[index - 1], newItems[index]];
      } else if (direction === 1 && index < items.length - 1) {
          [newItems[index], newItems[index + 1]] = [newItems[index + 1], newItems[index]];
      }
      setItems(newItems);
  };

  const handleDelete = (index: number) => {
      setItems(items.filter((_, i) => i !== index));
  };

  const handleAddRow = () => {
      setItems([...items, {
          id: Math.random().toString(36).substr(2, 9),
          name: 'New Item', thk: 0, length: '-', qty: '-', type: 'insulation', isTube: false, roundingMode: null
      }]);
  };

  const handleUpdate = (index: number, field: keyof StackItem, value: any) => {
      const newItems = [...items];
      newItems[index] = { ...newItems[index], [field]: value };
      setItems(newItems);
  };

  const handleUpdateById = (id: string, field: keyof StackItem, value: any) => {
      const index = items.findIndex(i => i.id === id);
      if (index !== -1) {
          handleUpdate(index, field, value);
      }
  };

  const toggleRounding = (index: number, mode: 'M' | 'F' | 'C') => {
      const newItems = [...items];
      // Toggle off if clicked again
      if (newItems[index].roundingMode === mode) {
          newItems[index].roundingMode = null;
      } else {
          newItems[index].roundingMode = mode;
      }
      setItems(newItems);
  };

  const setAllRounding = (mode: 'M' | 'F' | 'C' | null) => {
      const newItems = items.map(i => ({ ...i, roundingMode: mode }));
      setItems(newItems);
  };

  const windingIndices = items.map((it, idx) => it.type === 'winding' ? idx : -1).filter(i => i !== -1);

  const getStickDetails = (item: StackItem, index: number) => {
      const nameLower = item.name.trim().toLowerCase();
      const isDuct = nameLower.includes('wdman duct');
      const isStk = nameLower.includes('wd wdg stk') || nameLower.includes('wdg stk');

      if (!isDuct && !isStk) {
          return { displayName: item.name, partNumber: '', associatedHeight: 0, lockQty: 0, plainQty: 0 };
      }

      let prevWdgIdx = -1;
      let nextWdgIdx = -1;
      for (let i = windingIndices.length - 1; i >= 0; i--) {
          if (windingIndices[i] < index) { prevWdgIdx = windingIndices[i]; break; }
      }
      for (let i = 0; i < windingIndices.length; i++) {
          if (windingIndices[i] > index) { nextWdgIdx = windingIndices[i]; break; }
      }

      let associatedWdgIdx = -1;
      let suffix = '';
      const distToNext = nextWdgIdx !== -1 ? nextWdgIdx - index : Infinity;
      const distToPrev = prevWdgIdx !== -1 ? index - prevWdgIdx : Infinity;

      if (distToNext <= distToPrev) {
          if (nextWdgIdx !== -1) associatedWdgIdx = windingIndices.indexOf(nextWdgIdx);
      } else {
          if (prevWdgIdx !== -1) associatedWdgIdx = windingIndices.indexOf(prevWdgIdx);
      }
      
      if (associatedWdgIdx === -1) {
           if (nextWdgIdx !== -1) associatedWdgIdx = windingIndices.indexOf(nextWdgIdx);
           else if (prevWdgIdx !== -1) associatedWdgIdx = windingIndices.indexOf(prevWdgIdx);
      }

      let ks = 0;
      let ksStr = '?';
      if (associatedWdgIdx !== -1) {
           const key = `wdg${associatedWdgIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
           ks = parseFloat(String(data?.[key]?.ksCircle || '0'));
           ksStr = ks.toString();
      }

      let hasLock = false;
      if (nextWdgIdx !== -1 && (nextWdgIdx - index) === 1) {
          const wOrderIndex = windingIndices.indexOf(nextWdgIdx);
          const key = `wdg${wOrderIndex + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
          ks = parseFloat(String(data?.[key]?.ksCircle || '0'));
          ksStr = ks.toString();
          suffix = `(${ksStr} Lock + ${ksStr} Plain)`;
          associatedWdgIdx = wOrderIndex;
          hasLock = true;
      } else {
          suffix = `(${ksStr} Plain + ${ksStr} Plain)`;
      }

      let displayName = item.name;
      if (isDuct) displayName = `Wdman Duct ${suffix}`;
      else if (isStk) displayName = `Wd Wdg Stk ${suffix}`;

      let partNumber = '-';
      let height = 0;
      if (associatedWdgIdx !== -1) {
          const key = `wdg${associatedWdgIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
          height = parseFloat(String(data?.[key]?.wireSpaceMech || '0'));
      }

      const thk = item.thk;
      const isLong = height > 83; 

      const PART_MAP: Record<string, Record<string, { short: string, long: string }>> = {
          ENPAY: {
              '0.236': { short: '1211860T', long: '1211860T1' },
              '0.315': { short: '1211863T', long: '1211863T1' },
              '0.394': { short: '1211865T', long: '1211865T1' }
          },
          WEIDMAN: {
              '0.236': { short: '121186011', long: '121186012' },
              '0.315': { short: '121186311', long: '121186312' },
              '0.394': { short: '121186511', long: '121186512' }
          }
      };

      const vendorMap = PART_MAP[selectedVendor];
      const matchedKey = Object.keys(vendorMap).find(k => Math.abs(parseFloat(k) - thk) < 0.02);
      if (matchedKey) {
          const e = vendorMap[matchedKey];
          partNumber = isLong ? e.long : e.short;
      }
      
      // Calculate quantities (per transformer = * 3 phases)
      const lockQty = hasLock ? ks * 3 : 0;
      const plainQty = hasLock ? ks * 3 : ks * 2 * 3;

      return { displayName, partNumber, associatedHeight: height, lockQty, plainQty };
  };

  let currentOD = ceiling(baseOD, 0.0625) + 0.5; 
  
  // Re-calculate Stack Data including Height H logic
  const wdgSpace = data?.brackets.wdgSpace || 0;
  const topDist = data?.brackets.top || 0;
  const ks1 = data?.wdg1.ksCircle || 0;
  const ks2 = data?.wdg2.ksCircle || 0;
  const ks3 = data?.wdg3.ksCircle || 0;

  const processedRows = items.map((item, index) => {
      const calculatedID = currentOD;
      let calculatedOD = calculatedID + (item.thk * 2);
      
      // Apply Rounding if set
      if (item.roundingMode === 'M') {
          calculatedOD = mround(calculatedOD, 0.0625);
      } else if (item.roundingMode === 'F') {
          calculatedOD = floor(calculatedOD, 0.0625);
      } else if (item.roundingMode === 'C') {
          calculatedOD = ceiling(calculatedOD, 0.0625);
      }

      const tubeListID = mround(calculatedID, 0.0625);
      const calculatedL = mround((item.thk + tubeListID) * Math.PI, 0.0625) + 4;
      
      // --- UPDATED HEIGHT CALCULATION LOGIC ---
      let calculatedH = wdgSpace;
      const lowerName = item.name.toLowerCase();
      if (lowerName.includes('core tube')) {
          // Core Tube: (wdgSpace + topDist) - tolerance
          calculatedH = (wdgSpace + topDist) - tubeTolerance;
      } else if (lowerName.includes('major 1')) {
          // Deduction for tubes between W1 and W2 if ks1 matches ks2
          if (ks1 > 0 && ks1 === ks2) {
              calculatedH = wdgSpace - 0.5;
          } else {
              calculatedH = wdgSpace;
          }
      } else if (lowerName.includes('major 2')) {
          // Deduction for tubes between W2 and W3 if ks2 matches ks3
          if (ks2 > 0 && ks2 === ks3) {
              calculatedH = wdgSpace - 0.5;
          } else {
              calculatedH = wdgSpace;
          }
      } else if (lowerName.includes('major')) {
          // Fallback for generic "Major" name: assume between W1 and W2
          if (ks1 > 0 && ks1 === ks2) {
              calculatedH = wdgSpace - 0.5;
          } else {
              calculatedH = wdgSpace;
          }
      } else if (lowerName.includes('cover')) {
          calculatedH = wdgSpace;
      }
      // -------------------------------

      const stickInfo = getStickDetails(item, index);
      const row = { ...item, calculatedID, calculatedOD, tubeListID, calculatedL, calculatedH, displayName: stickInfo.displayName, partNumber: stickInfo.partNumber, lockQty: stickInfo.lockQty, plainQty: stickInfo.plainQty };
      currentOD = calculatedOD;
      return row;
  });

  const finalOD = currentOD;
  const totalCeiledOD = Math.ceil(finalOD / 0.125) * 0.125;
  const tubeRows = processedRows.filter(r => r.isTube && r.thk > 0);
  const stickRows = processedRows.filter(r => r.name === 'Wdman Duct' || r.name === 'Wd Wdg Stk' || r.name.toLowerCase().includes('wdg stk') || r.type === 'winding');

  // Effect to set default Angle Sector Item Selection if not set
  useEffect(() => {
      if (items.length > 0 && currentAccessoryData.asItemIndex === -1) {
          // Find outermost winding index in the items list
          let lastWindingIndex = -1;
          for (let i = items.length - 1; i >= 0; i--) {
              if (items[i].type === 'winding') {
                  lastWindingIndex = i;
                  break;
              }
          }
          
          if (lastWindingIndex !== -1) {
              // Default to 2 items before the winding (Tube -> Stick -> Winding)
              const targetIndex = Math.max(0, lastWindingIndex - 2);
              setAsItemIndex(targetIndex);
          }
      }
  }, [items, currentAccessoryData.asItemIndex, washerWindingIndex]);

  // Effect to set default Angle Cap Item Selection
  useEffect(() => {
      if (items.length > 0 && currentAccessoryData.acItemIndex === -1) {
          // Find outermost winding index in the items list
          let lastWindingIndex = -1;
          for (let i = items.length - 1; i >= 0; i--) {
              if (items[i].type === 'winding') {
                  lastWindingIndex = i;
                  break;
              }
          }
          
          if (lastWindingIndex !== -1) {
              // Default to 2 items after the winding (Winding -> Duct -> Tube)
              const targetIndex = Math.min(items.length - 1, lastWindingIndex + 2);
              setAcItemIndex(targetIndex);
          }
      }
  }, [items, currentAccessoryData.acItemIndex, washerWindingIndex]);

  // Handle ID Seal State Updates
  const updateIdSealState = (id: string, field: string, val: any) => {
      setIdSealState(prev => ({
          ...prev,
          [id]: { ...prev[id], [field]: val }
      }));
  };

  // Handle OD Seal State Updates
  const updateOdSealState = (id: string, field: string, val: any) => {
      setOdSealState(prev => ({
          ...prev,
          [id]: { ...prev[id], [field]: val }
      }));
  };

  const handleCopyStackTable = () => {
      const lines = [`Base Core OD\t${baseOD.toFixed(4)}`, 'ITEM\tBld/Thk\tID (Calc)\tOD (Calc)\tLength'];
      processedRows.forEach(item => { lines.push(`${item.name}\t${item.thk.toFixed(4)}\t${item.calculatedID.toFixed(4)}\t${item.calculatedOD.toFixed(4)}\t${item.length}`); });
      lines.push(`TOTAL OD (CALCULATED)\t\t\t${finalOD.toFixed(4)}\t`);
      navigator.clipboard.writeText(lines.join('\n')).then(() => { setCopySuccess(true); setTimeout(() => setCopySuccess(false), 2000); });
  };

  const handleCopyTubeTable = () => {
      const lines = ['Part#\tQty\tItem Description\tT\tID\tH\tS\tL'];
      tubeRows.forEach(item => { lines.push(`12CY\t3\t${item.name}\t${item.thk.toFixed(4)}\t${item.tubeListID.toFixed(4)}\t${item.calculatedH.toFixed(4)}\t4\t${item.calculatedL.toFixed(4)}`); });
      navigator.clipboard.writeText(lines.join('\n')).then(() => { setTubeCopySuccess(true); setTimeout(() => setTubeCopySuccess(false), 2000); });
  };

  const handleCopyStickTable = () => {
      const lines = ['Part Number\tDescription\tThk\tLock Qty\tPlain Qty\tTotal Qty'];
      stickRows.filter(r => r.type !== 'winding').forEach(item => { 
          const total = (item.lockQty || 0) + (item.plainQty || 0);
          lines.push(`${item.partNumber}\t${item.displayName}\t${item.thk.toFixed(4)}\t${item.lockQty}\t${item.plainQty}\t${total}`); 
      });
      navigator.clipboard.writeText(lines.join('\n')).then(() => { setStickCopySuccess(true); setTimeout(() => setStickCopySuccess(false), 2000); });
  };
  
  const handleCopyIdSealTable = () => {
      const lines = ['VTC Part #\tQty\tItem\tDimension\t\t\t\t\t\t\t'];
      lines.push('\t\t\tT\tID (A)\tOD (B)\tN\tAngle (deg)\tSlot Depth (D)\tSlot Width (C)');
      
      processedRows.forEach((row, idx) => {
          if (row.type === 'winding' && idSealState[row.id]) {
              const s = idSealState[row.id];
              // Logic: 3->3, 5->6, 7->9
              const qtyCalc = s.qtyOpt === 3 ? 3 : s.qtyOpt === 5 ? 6 : 9;
              
              // Find matching KS
              const windingOrderIdx = windingIndices.indexOf(idx);
              const wdgKey = `wdg${windingOrderIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
              const ks = parseFloat(String(data?.[wdgKey]?.ksCircle || '0'));
              const n = ks > 0 ? ks * 2 : 0;
              const angle = n > 0 ? (360 / n).toFixed(2) : '0';
              
              // Slot Depth D: Previous Item Thickness
              const prevItem = idx > 0 ? processedRows[idx - 1] : null;
              const slotDepth = prevItem ? prevItem.thk.toFixed(3) : '0';
              
              // Dimensions - UPDATED: ID uses previous item's calculated ID
              const sourceID = prevItem ? prevItem.calculatedID : row.calculatedID;
              const dimA = applyRounding(sourceID, idSealRounding.id).toFixed(4);
              const dimB = applyRounding(row.calculatedOD, idSealRounding.od).toFixed(4);

              lines.push(`${s.vtcPart}\t${qtyCalc}\t${row.name} ID OGW\t${s.t}\t${dimA}\t${dimB}\t${n}\t${angle}\t${slotDepth}\t${s.c}`);
          }
      });
      navigator.clipboard.writeText(lines.join('\n')).then(() => { setIdSealCopySuccess(true); setTimeout(() => setIdSealCopySuccess(false), 2000); });
  };

  const handleCopyOdSealTable = () => {
      const lines = ['VTC Part #\tQty\tItem\tDimension\t\t\t\t\t\t\t'];
      lines.push('\t\t\tT\tID (A)\tOD (B)\tN\tAngle (deg)\tSlot Depth (D)\tSlot Width (C)');
      
      processedRows.forEach((row, idx) => {
          if (row.type === 'winding' && odSealState[row.id] && idSealState[row.id]) {
              const s = odSealState[row.id];
              const idState = idSealState[row.id];
              
              // Qty Logic: (qtyOpt + 1) / 2 * 3
              // ID 3 -> (3+1)/2 * 3 = 6
              // ID 5 -> (5+1)/2 * 3 = 9
              // ID 7 -> (7+1)/2 * 3 = 12
              const qtyCalc = ((idState.qtyOpt + 1) / 2) * 3;
              
              // Find matching KS
              const windingOrderIdx = windingIndices.indexOf(idx);
              const wdgKey = `wdg${windingOrderIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
              const ks = parseFloat(String(data?.[wdgKey]?.ksCircle || '0'));
              const n = ks > 0 ? ks * 2 : 0;
              const angle = n > 0 ? (360 / n).toFixed(2) : '0';
              
              // Slot Depth D: Next Item Thickness (after winding)
              const nextItem = idx < processedRows.length - 1 ? processedRows[idx + 1] : null;
              const slotDepth = nextItem ? nextItem.thk.toFixed(3) : '0';
              
              // Dimensions - UPDATED: ID uses previous item's calculated OD (Stk OD)
              // Dim A is the Inner Dimension of the Seal, which fits over the previous layer's OD
              const prevItem = idx > 0 ? processedRows[idx - 1] : null;
              const sourceID = prevItem ? prevItem.calculatedOD : row.calculatedOD;
              const dimA = applyRounding(sourceID, odSealRounding.id).toFixed(4);
              
              const dimB = nextItem ? applyRounding(nextItem.calculatedOD, odSealRounding.od).toFixed(4) : '0';

              lines.push(`${s.vtcPart}\t${qtyCalc}\t${row.name} OD OGW\t${s.t}\t${dimA}\t${dimB}\t${n}\t${angle}\t${slotDepth}\t${s.c}`);
          }
      });
      navigator.clipboard.writeText(lines.join('\n')).then(() => { setOdSealCopySuccess(true); setTimeout(() => setOdSealCopySuccess(false), 2000); });
  };

  const handleCopyCtcRisers = () => {
      const lines = ['CTC Width\tCTC Height\tC-C Spacers\tStick Thk\tDiscs\tKS Rows\tTotal Turns\tBay Drop'];
      windingIndices.forEach((rowIdx, wIdx) => {
          const wdgKey = `wdg${wIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
          const w = data?.[wdgKey];
          if (!w) return;

          const row = processedRows[rowIdx];
          
          // Find previous stick/duct thickness
          let stickThk = 0;
          if (rowIdx > 0) {
              const prev = processedRows[rowIdx - 1];
              if (prev.name.toLowerCase().includes('duct') || prev.name.toLowerCase().includes('stk')) {
                  stickThk = prev.thk;
              }
          }

          const paper = parseFloat(String(w.paperInsul || '0'));
          const width = parseFloat(String(w.bareWidth || '0'));
          const thk = parseFloat(String(w.bareThk || '0'));
          const strands = parseFloat(String(w.strands || '0'));
          const ksCircle = parseFloat(String(w.ksCircle || '0'));
          const ratedTurns = parseFloat(String(w.ratedTurns || '0'));
          const discs = parseFloat(String(w.discVal || '0')); // Trns/Lyr is total discs
          const tpd = parseFloat(String(w.lyrsVal || '0')); // Trns/Disc

          const ctcWidth = ((width + 0.005) * 2 + 0.003 + paper) - (paper * 0.1);
          // Updated: - 0.0625 at end
          const ctcHeight = ((thk + 0.005) * mround(strands/2, 1) + paper) - 0.0625;
          const ccSpacers = ksCircle > 0 ? mround((row.calculatedID * Math.PI) / ksCircle, 0.125) : 0;
          
          const turnsDrop = mround(tpd, 1) * discs - ratedTurns;
          // Updated: Multiplication instead of division
          const bayDrop = turnsDrop * ksCircle;

          lines.push(`${ctcWidth.toFixed(4)}\t${ctcHeight.toFixed(4)}\t${ccSpacers.toFixed(3)}\t${stickThk.toFixed(3)}\t${discs}\t${ksCircle}\t${ratedTurns}\t${bayDrop.toFixed(2)}`);
      });
      navigator.clipboard.writeText(lines.join('\n')).then(() => { setCtcCopySuccess(true); setTimeout(() => setCtcCopySuccess(false), 2000); });
  };

  // --- SER (formerly Washer) & KS Calculation ---
  const getSERDimensions = () => {
      if (!data) return { id: 0, od: 0 };
      const key = `wdg${washerWindingIndex + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
      const w = data[key];
      const id = parseFloat(String(w?.id || '0'));
      const od = parseFloat(String(w?.od || '0'));
      // ID- =CEILING(wdg ID +0.3125,0.0625)
      // OD-=CEILING(wdg OD,0.0625)
      const washerId = ceiling(id + 0.3125, 0.0625);
      const washerOd = ceiling(od, 0.0625);
      return { id: washerId, od: washerOd };
  };

  const getKSDimensions = () => {
      if (!data) return { a: 0.25, b: 0.54, c: 0.812, d: 'Standard', f: 0.25, w: 0, t: 0, l: 0, fl: 0 };
      const key = `wdg${washerWindingIndex + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
      const wStats = data[key];
      
      const w = parseFloat(String(wStats?.ksWidth || '0'));
      
      // T parsing
      let t = 0;
      if (wStats?.ksThk) {
          const clean = String(wStats.ksThk).split('/')[0].trim();
          t = parseFloat(clean) || 0;
      }

      // L Calculation
      const radial = parseFloat(String(wStats?.radial || '0'));
      const paper = parseFloat(String(wStats?.paperInsul || '0'));
      
      let lBase = radial;
      // Add paper insulation only for outermost winding calculation
      if (washerWindingIndex === windingCount - 1) {
          lBase += paper;
      }
      
      let l = 0;
      if (calculationMethod === 'ceiling') {
          l = Math.ceil(lBase / 0.0625) * 0.0625;
      } else {
          l = Math.round(lBase / 0.0625) * 0.0625;
      }
      
      const fl = l + 0.5;

      return {
          a: 0.25, b: 0.54, c: 0.812, d: 'Standard', f: 0.25,
          w, t, l, fl
      };
  };

  // --- Angle Sector Calculations ---
  const getAngleSectorValues = () => {
      // Defaults
      const res = { ir: 0, b: 0, qty: 0, l: 0 };
      
      if (!data || processedRows.length === 0 || currentAccessoryData.asItemIndex === -1) return res;

      // 1. Qty = KS/Circle of THIS Winding * 3
      const outerWdgKey = `wdg${washerWindingIndex + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
      const ksCircle = parseFloat(String(data[outerWdgKey]?.ksCircle || '0'));
      res.qty = ksCircle * 3;

      // 2. IR = MROUND(Item OD / 2, 0.0625)
      const selectedItem = processedRows[currentAccessoryData.asItemIndex];
      if (selectedItem) {
          // Use Calculated OD from Stack Table logic
          res.ir = mround(selectedItem.calculatedOD / 2, 0.0625);
      }

      // 3. B = FLOOR(Sum Thickness between Selection and Outermost Winding, 0.0625) - 0.0625
      // Find Outermost Winding Index in processedRows
      let windingRowIndex = -1;
      for (let i = processedRows.length - 1; i >= 0; i--) {
          if (processedRows[i].type === 'winding' && processedRows[i].name.startsWith(windingNames[washerWindingIndex])) {
              windingRowIndex = i;
              break;
          }
      }
      // If specific name matching fails, fallback to iterating backwards to find ANY winding later than selection
      if (windingRowIndex === -1) {
           for (let i = processedRows.length - 1; i >= 0; i--) {
              if (processedRows[i].type === 'winding') {
                  windingRowIndex = i;
                  if (windingRowIndex > currentAccessoryData.asItemIndex) break; 
              }
          }
      }


      if (windingRowIndex !== -1 && currentAccessoryData.asItemIndex < windingRowIndex) {
          let sumThk = 0;
          // Sum from Next Item up to Winding (Inclusive)
          for (let i = currentAccessoryData.asItemIndex + 1; i <= windingRowIndex; i++) {
              sumThk += processedRows[i].thk;
          }
          res.b = floor(sumThk, 0.0625) - 0.0625;
      }
      
      // Apply Manual Adjustment
      res.b = res.b + currentAccessoryData.asBAdjust;

      // 4. L = MROUND(IR*2*PI()/((ks/circle )/2)+4,0.25)
      if (ksCircle > 0) {
          const rawL = (res.ir * 2 * Math.PI) / (ksCircle / 2) + 4;
          res.l = mround(rawL, 0.25);
      }

      return res;
  };

  // --- Angle Cap Calculations ---
  const getAngleCapValues = () => {
      // Defaults
      const res = { ir: 0, b: 0, qty: 0, l: 0 };
      
      if (!data || processedRows.length === 0 || currentAccessoryData.acItemIndex === -1) return res;

      // 1. Qty = KS/Circle of THIS Winding * 3
      const outerWdgKey = `wdg${washerWindingIndex + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
      const ksCircle = parseFloat(String(data[outerWdgKey]?.ksCircle || '0'));
      res.qty = ksCircle * 3;

      // 2. IR = MROUND(Item OD / 2, 0.0625)
      const selectedItem = processedRows[currentAccessoryData.acItemIndex];
      if (selectedItem) {
          // For Cap, usually fits OVER the item, so IR matches Item OD/2
          res.ir = mround(selectedItem.calculatedOD / 2, 0.0625);
      }

      // 3. B = MROUND(Sum Thickness between Outermost Winding and Selection, 0.0625)
      // Find Outermost Winding Index in processedRows
       let windingRowIndex = -1;
      for (let i = processedRows.length - 1; i >= 0; i--) {
          if (processedRows[i].type === 'winding' && processedRows[i].name.startsWith(windingNames[washerWindingIndex])) {
              windingRowIndex = i;
              break;
          }
      }
       // If specific name matching fails, fallback
      if (windingRowIndex === -1) {
           for (let i = 0; i < processedRows.length; i++) {
              if (processedRows[i].type === 'winding') {
                  windingRowIndex = i;
                  if (windingRowIndex < currentAccessoryData.acItemIndex) break; 
              }
          }
      }


      if (windingRowIndex !== -1 && currentAccessoryData.acItemIndex >= windingRowIndex) {
          let sumThk = 0;
          // Sum from Winding (Inclusive) to Selected Item (Inclusive)
          for (let i = windingRowIndex; i <= currentAccessoryData.acItemIndex; i++) {
              sumThk += processedRows[i].thk;
          }
          res.b = mround(sumThk, 0.0625);
      }
      
      // Apply Manual Adjustment
      res.b = res.b + currentAccessoryData.acBAdjust;

      // 4. L = MROUND(IR*2*PI()/((ks/circle )/2)+4,0.25)
      if (ksCircle > 0) {
          const rawL = (res.ir * 2 * Math.PI) / (ksCircle / 2) + 4;
          res.l = mround(rawL, 0.25);
      }

      return res;
  };

  const getHeadSheetValues = () => {
    if (!data) return { a: 0, b: 0, c: 0, e: 0, f: 0, g: 0 };
    
    const outmostWdgKey = `wdg${windingCount}` as 'wdg1' | 'wdg2' | 'wdg3';
    const outmostWdg = data[outmostWdgKey];
    
    // A = CEILING(Outmost ID, 0.0625)
    const outmostId = parseFloat(String(outmostWdg?.id || '0'));
    const a = ceiling(outmostId, 0.0625);
    
    // B = MROUND(Outmost OD + 4, 0.0625)
    const outmostOd = parseFloat(String(outmostWdg?.od || '0'));
    const b = mround(outmostOd + 4, 0.0625);
    
    // C = Leg Center - 0.75
    const legCenter = parseFloat(data.core.legCenter || '0');
    const c = legCenter > 0 ? legCenter - 0.75 : 0;
    
    // D is input
    const d = headSheet.d;
    
    // E = C + 2*D
    const e = c + 2 * d;
    
    // F = MROUND(C / 4, 0.0625)
    const f = mround(c / 4, 0.0625);
    
    // G = F + 6
    const g = f + 6;
    
    return { a, b, c, e, f, g };
  };

  const headSheetVals = getHeadSheetValues();

  const handleCopyHeadSheet = () => {
    const { a, b, c, e, f, g } = headSheetVals;
    const lines = [
        `VTC Part\t${headSheet.vtcPart}\tstd`,
        `Qty / transformer\t${headSheet.qty}\tstd`,
        `Item\tDimension`,
        `T\t${headSheet.t}\tstd`,
        `A\t${a}\t=CEILING.MATH(Outmost winding's ID ,0.0625)`,
        `B\t${b}\t=MROUND(outmost winding's OD + 4,0.0625)`,
        `C\t${c}\tLeg center-0.75`,
        `D\t${headSheet.d}\tstd`,
        `E\t${e}\t=C+2*D`,
        `F\t${f}\t=MROUND( C /4,0.0625)`,
        `G\t${g}\t=F+6`
    ];
    navigator.clipboard.writeText(lines.join('\n')).then(() => {
        setHeadSheetCopySuccess(true);
        setTimeout(() => setHeadSheetCopySuccess(false), 2000);
    });
  };

  const serDims = getSERDimensions();
  const ksDims = getKSDimensions();
  const asVals = getAngleSectorValues();
  const acVals = getAngleCapValues();

  const renderCTCRisersTable = () => {
    if (!data) return null;

    return (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mt-6">
            <div className="flex justify-between items-center mb-4">
                <div className="flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2 text-indigo-500" />
                    <h3 className="text-lg font-bold text-slate-800">CTC Risers</h3>
                </div>
                <button onClick={handleCopyCtcRisers} className="flex items-center px-3 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors font-medium text-xs">{ctcCopySuccess ? <Check className="w-4 h-4 mr-1 text-emerald-600"/> : <Copy className="w-4 h-4 mr-1"/>} Copy List</button>
            </div>
            
            <div className="overflow-x-auto rounded-lg border border-slate-100">
                <table className="w-full text-xs text-left">
                    <thead className="bg-slate-800 text-white font-bold">
                        <tr>
                            <th className="px-4 py-2">Winding</th>
                            <th className="px-4 py-2 text-right">CTC Width</th>
                            <th className="px-4 py-2 text-right">CTC Height</th>
                            <th className="px-4 py-2 text-right">C-C Spacers</th>
                            <th className="px-4 py-2 text-right">Stick Thk</th>
                            <th className="px-4 py-2 text-right">Discs</th>
                            <th className="px-4 py-2 text-right">KS Rows</th>
                            <th className="px-4 py-2 text-right">Total Turns</th>
                            <th className="px-4 py-2 text-right">Bay Drop</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {windingIndices.map((rowIdx, wIdx) => {
                            const wdgKey = `wdg${wIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
                            const w = data?.[wdgKey];
                            if (!w) return null;

                            const row = processedRows[rowIdx];
                            
                            // Find previous stick/duct thickness
                            let stickThk = 0;
                            if (rowIdx > 0) {
                                const prev = processedRows[rowIdx - 1];
                                if (prev.name.toLowerCase().includes('duct') || prev.name.toLowerCase().includes('stk')) {
                                    stickThk = prev.thk;
                                }
                            }

                            const paper = parseFloat(String(w.paperInsul || '0'));
                            const width = parseFloat(String(w.bareWidth || '0'));
                            const thk = parseFloat(String(w.bareThk || '0'));
                            const strands = parseFloat(String(w.strands || '0'));
                            const ksCircle = parseFloat(String(w.ksCircle || '0'));
                            const ratedTurns = parseFloat(String(w.ratedTurns || '0'));
                            const discs = parseFloat(String(w.discVal || '0')); // Trns/Lyr is total discs
                            const tpd = parseFloat(String(w.lyrsVal || '0')); // Trns/Disc

                            const ctcWidth = ((width + 0.005) * 2 + 0.003 + paper) - (paper * 0.1);
                            // Formula Updated: Subtract 0.0625
                            const ctcHeight = ((thk + 0.005) * mround(strands/2, 1) + paper) - 0.0625;
                            const ccSpacers = ksCircle > 0 ? mround((row.calculatedID * Math.PI) / ksCircle, 0.125) : 0;
                            
                            const turnsDrop = mround(tpd, 1) * discs - ratedTurns;
                            // Formula Updated: Multiply by KS Circle
                            const bayDrop = turnsDrop * ksCircle;

                            return (
                                <tr key={`ctc-${wIdx}`} className="hover:bg-slate-50">
                                    <td className="px-4 py-2 font-bold text-slate-700">{windingNames[wIdx]}</td>
                                    <td className="px-4 py-2 text-right font-mono">{ctcWidth.toFixed(4)}</td>
                                    <td className="px-4 py-2 text-right font-mono">{ctcHeight.toFixed(4)}</td>
                                    <td className="px-4 py-2 text-right font-mono">{ccSpacers.toFixed(3)}</td>
                                    <td className="px-4 py-2 text-right font-mono text-slate-500">{stickThk.toFixed(3)}</td>
                                    <td className="px-4 py-2 text-right font-mono">{discs}</td>
                                    <td className="px-4 py-2 text-right font-mono">{ksCircle}</td>
                                    <td className="px-4 py-2 text-right font-mono">{ratedTurns}</td>
                                    <td className="px-4 py-2 text-right font-mono font-bold text-indigo-600">{bayDrop.toFixed(2)}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
  };

  // Rounding Control Button Helper
  const renderRoundingControl = (current: 'C' | 'F' | 'M', onClick: (mode: 'C' | 'F' | 'M') => void) => (
      <div className="flex space-x-0.5 mt-1 justify-center">
          {(['C', 'F', 'M'] as const).map(m => (
              <button
                  key={m}
                  onClick={() => onClick(m)}
                  className={`px-1.5 py-0.5 text-[9px] font-bold border rounded transition-colors ${current === m ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-400 border-slate-200 hover:border-slate-300'}`}
                  title={m === 'C' ? 'Ceiling' : m === 'F' ? 'Floor' : 'MROUND'}
              >
                  {m}
              </button>
          ))}
      </div>
  );

  const getRoundingLabel = (mode: 'C' | 'F' | 'M') => mode === 'C' ? 'CEILING' : mode === 'F' ? 'FLOOR' : 'MROUND';

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      <div className="flex items-center justify-between mb-4">
        <button onClick={onBack} className="flex items-center text-slate-600 hover:text-slate-900 transition-colors bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm hover:shadow-md">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Main
        </button>
        <h2 className="text-xl font-bold text-slate-800">Radial Build & Tube List</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
          {/* STACK CONTROL PANEL */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 flex flex-col justify-between">
              <h3 className="text-sm font-bold text-slate-700 mb-3 flex items-center">
                  <Layers className="w-4 h-4 mr-2 text-indigo-500" />
                  Stack Controls
              </h3>
              <div className="flex items-end space-x-6">
                <div className="flex flex-col space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Base Core OD</label>
                    <input type="number" step="0.0001" className="text-lg font-mono font-bold text-slate-800 border-b border-slate-200 focus:border-indigo-500 focus:outline-none w-32 py-1 bg-white" value={baseOD} onChange={(e) => setBaseOD(parseFloat(e.target.value) || 0)} />
                </div>
                <div className="flex flex-col space-y-1 pb-1 px-2 border-l border-slate-100">
                     <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Calculations</span>
                     <span className="text-[10px] text-slate-500">ID = Previous OD</span>
                     <span className="text-[9px] text-slate-400 italic">Core ID uses Ceiling(Core, 0.0625) + 0.5</span>
                </div>
              </div>
          </div>

          {/* TUBE CALCULATION SETTINGS */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
              <h3 className="text-sm font-bold text-slate-700 mb-3 flex items-center">
                  <Settings className="w-4 h-4 mr-2 text-indigo-500" />
                  Tube Height Calculation
              </h3>
              <div className="grid grid-cols-3 gap-4">
                  <div className="flex flex-col space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase">WdgSpace</label>
                      <div className="text-sm font-mono font-bold text-slate-700 py-1 border-b border-slate-100">{data?.brackets.wdgSpace || '-'}</div>
                  </div>
                  <div className="flex flex-col space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase">Wdg To Top</label>
                      <div className="text-sm font-mono font-bold text-slate-700 py-1 border-b border-slate-100">{topDist || '-'}</div>
                  </div>
                  <div className="flex flex-col space-y-1">
                      <label className="text-[10px] font-bold text-indigo-600 uppercase">Tolerance</label>
                      <input 
                        type="number" step="0.001" 
                        className="text-sm font-mono font-bold text-indigo-700 border-b border-indigo-200 focus:border-indigo-500 focus:outline-none py-1 bg-indigo-50/30" 
                        value={tubeTolerance} 
                        onChange={(e) => setTubeTolerance(parseFloat(e.target.value) || 0)} 
                      />
                  </div>
              </div>
              <div className="mt-2 text-[9px] text-slate-400 leading-tight">
                  Core: (WdgSpace + Top) - Tol | Major: WdgSpace (-0.5 if common ks) | Cover: WdgSpace
              </div>
          </div>
      </div>

      {/* STACK EDITOR */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex justify-between items-end mb-4">
            <div className="flex items-center space-x-2">
                 <h3 className="font-bold text-sm text-slate-800 uppercase tracking-widest">Stack Layers</h3>
            </div>

            <div className="flex space-x-2">
                 <button onClick={handleAddRow} className="flex items-center px-3 py-2 bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100 transition-colors font-medium text-xs"><Plus className="w-4 h-4 mr-1" /> Add Row</button>
                 <button onClick={handleCopyStackTable} className="flex items-center px-3 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors font-medium text-xs">{copySuccess ? <Check className="w-4 h-4 mr-1 text-emerald-600"/> : <Copy className="w-4 h-4 mr-1"/>} Copy Stack</button>
            </div>
        </div>
        <div className="overflow-x-auto rounded-lg border border-slate-100">
            <table className="w-full text-sm text-left table-fixed">
                <thead className="bg-slate-800 text-white font-bold border-b border-slate-200">
                    <tr>
                        <th className="px-4 py-3 w-12 text-center text-slate-300">#</th>
                        <th className="px-4 py-3 text-left w-auto">ITEM</th>
                        <th className="px-4 py-3 w-28 text-right">Bld/Thk</th>
                        <th className="px-4 py-3 w-32 text-right bg-slate-700/50">ID (Calc)</th>
                        <th className="px-4 py-3 w-48 text-right bg-slate-700">
                            <div className="flex flex-col items-end">
                                <span>OD (Calc)</span>
                                <div className="flex space-x-1 mt-1">
                                   <button onClick={() => setAllRounding('M')} className="px-1.5 py-0.5 text-[9px] bg-slate-600 border border-slate-500 rounded text-slate-100 hover:bg-indigo-500 transition-colors" title="Set All to MROUND">M</button>
                                   <button onClick={() => setAllRounding('F')} className="px-1.5 py-0.5 text-[9px] bg-slate-600 border border-slate-500 rounded text-slate-100 hover:bg-indigo-500 transition-colors" title="Set All to FLOOR">F</button>
                                   <button onClick={() => setAllRounding('C')} className="px-1.5 py-0.5 text-[9px] bg-slate-600 border border-slate-500 rounded text-slate-100 hover:bg-indigo-500 transition-colors" title="Set All to CEILING">C</button>
                                   <button onClick={() => setAllRounding(null)} className="px-1.5 py-0.5 text-[9px] bg-slate-600 border border-slate-500 rounded text-rose-300 hover:bg-rose-500 transition-colors" title="Reset All">X</button>
                                </div>
                            </div>
                        </th>
                        <th className="px-4 py-3 w-24 text-right">Length</th>
                        <th className="px-4 py-3 w-24 text-center">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {processedRows.map((item, idx) => {
                        let rowClass = "hover:bg-slate-50";
                        if (item.type === 'winding') rowClass = "bg-blue-50/80 border-2 border-blue-400 font-medium"; 
                        else if (item.type === 'core') rowClass = "bg-slate-50"; 

                        return (
                            <tr key={item.id} className={rowClass}>
                                <td className="px-4 py-2 text-slate-400 font-mono text-xs text-center">{idx + 1}</td>
                                <td className="px-4 py-2">
                                    <div className="flex items-center w-full">
                                        <input type="text" value={item.name} onChange={(e) => handleUpdate(idx, 'name', e.target.value)} className={`flex-1 bg-transparent focus:outline-none border-b border-transparent focus:border-indigo-300 transition-colors text-slate-700 ${item.type === 'winding' ? 'font-bold text-blue-800' : 'font-medium'} min-w-0`} />
                                        {item.type !== 'winding' && (
                                            <button onClick={() => handleUpdate(idx, 'isTube', !item.isTube)} className={`ml-2 text-[10px] px-1.5 py-0.5 rounded border whitespace-nowrap ${item.isTube ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-slate-100 text-slate-400 border-slate-200'}`} title="Include in Tube Cutting List?">Tube</button>
                                        )}
                                    </div>
                                </td>
                                <td className="px-4 py-2 text-right">
                                    <input type="number" step="0.0001" value={item.thk} onChange={(e) => handleUpdate(idx, 'thk', parseFloat(e.target.value))} className={`w-full text-right bg-transparent focus:outline-none border-b border-transparent focus:border-indigo-300 transition-colors font-mono ${item.type === 'winding' ? 'text-blue-900 font-bold' : 'text-slate-700'}`} />
                                </td>
                                <td className="px-4 py-2 text-right font-mono text-slate-600 bg-blue-50/30">{item.calculatedID.toFixed(4)}</td>
                                <td className={`px-4 py-2 text-right font-mono font-bold ${item.type === 'winding' ? 'text-blue-900 bg-blue-100/50' : 'text-slate-800 bg-slate-50/50'}`}>
                                    <div className="flex items-center justify-end space-x-2">
                                        <div className="flex space-x-0.5">
                                           <button onClick={() => toggleRounding(idx, 'M')} className={`px-1 py-0.5 text-[8px] font-bold border rounded transition-colors ${item.roundingMode === 'M' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-400 border-slate-200 hover:border-slate-300'}`}>M</button>
                                           <button onClick={() => toggleRounding(idx, 'F')} className={`px-1 py-0.5 text-[8px] font-bold border rounded transition-colors ${item.roundingMode === 'F' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-400 border-slate-200 hover:border-slate-300'}`}>F</button>
                                           <button onClick={() => toggleRounding(idx, 'C')} className={`px-1 py-0.5 text-[8px] font-bold border rounded transition-colors ${item.roundingMode === 'C' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-400 border-slate-200 hover:border-slate-300'}`}>C</button>
                                        </div>
                                        <span>{item.calculatedOD.toFixed(4)}</span>
                                    </div>
                                </td>
                                <td className="px-4 py-2 text-right">
                                     <input type="text" value={item.length} onChange={(e) => handleUpdate(idx, 'length', e.target.value)} className="w-full text-right bg-transparent focus:outline-none border-b border-transparent focus:border-indigo-300 transition-colors font-mono text-slate-600" />
                                </td>
                                <td className="px-4 py-2">
                                    <div className="flex items-center justify-center space-x-1">
                                        <button onClick={() => handleMove(idx, -1)} disabled={idx === 0} className="p-1 text-slate-400 hover:text-indigo-600 disabled:opacity-30 transition-colors"><ArrowUp className="w-4 h-4" /></button>
                                        <button onClick={() => handleMove(idx, 1)} disabled={idx === items.length - 1} className="p-1 text-slate-400 hover:text-indigo-600 disabled:opacity-30 transition-colors"><ArrowDown className="w-4 h-4" /></button>
                                        <button onClick={() => handleDelete(idx)} className="p-1 text-slate-400 hover:text-rose-600 transition-colors ml-2"><Trash2 className="w-4 h-4" /></button>
                                    </div>
                                </td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
        <div className="flex justify-end mt-4">
            <div className="bg-blue-50/50 rounded-lg border border-blue-100 p-4 text-right shadow-sm min-w-[240px]">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Total OD (Calculated)</div>
                <div className="text-xl font-mono font-bold text-slate-700">{finalOD.toFixed(4)}</div>
                <div className="my-3 border-t border-blue-200"></div>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">With Ceiling (0.125)</div>
                <div className="text-3xl font-mono font-bold text-blue-700">{totalCeiledOD.toFixed(3)}</div>
            </div>
        </div>
      </div>

      {/* TUBE CUTTING LIST */}
      {tubeRows.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center"><Scissors className="w-5 h-5 mr-2 text-emerald-600" /><h3 className="text-lg font-bold text-slate-800">Tube Cutting List</h3></div>
                  <button onClick={handleCopyTubeTable} className="flex items-center px-3 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors font-medium text-xs">{tubeCopySuccess ? <Check className="w-4 h-4 mr-1 text-emerald-600"/> : <Copy className="w-4 h-4 mr-1"/>} Copy List</button>
              </div>
              <div className="overflow-x-auto rounded-lg border border-slate-100">
                  <table className="w-full text-sm text-left">
                      <thead className="bg-slate-800 text-white font-bold">
                          <tr>
                              <th className="px-4 py-2 w-20">Part#</th>
                              <th className="px-4 py-2 w-16 text-center">Qty</th>
                              <th className="px-4 py-2">Item Description</th>
                              <th className="px-4 py-2 text-right">T</th>
                              <th className="px-4 py-2 text-right">ID</th>
                              <th className="px-4 py-2 text-center text-slate-400">H</th>
                              <th className="px-4 py-2 text-center">S</th>
                              <th className="px-4 py-2 text-right text-emerald-300">L</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {tubeRows.map((row, idx) => (
                              <tr key={row.id} className="hover:bg-slate-50">
                                  <td className="px-4 py-2 font-mono text-slate-600">12CY</td>
                                  <td className="px-4 py-2 font-mono text-center">3</td>
                                  <td className="px-4 py-2 font-medium text-slate-800">{row.name}</td>
                                  <td className="px-4 py-2 text-right font-mono text-slate-600">{row.thk.toFixed(3)}</td>
                                  <td className="px-4 py-2 text-right font-mono font-bold text-slate-800">{row.tubeListID.toFixed(4)}</td>
                                  <td className="px-4 py-2 text-center font-mono font-bold text-indigo-600">{row.calculatedH.toFixed(4)}</td>
                                  <td className="px-4 py-2 text-center font-mono text-slate-600">4</td>
                                  <td className="px-4 py-2 text-right font-mono font-bold text-emerald-600 bg-emerald-50/30">{row.calculatedL.toFixed(4)}</td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
          </div>
      )}

      {/* STICKS LIST */}
      {stickRows.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center"><List className="w-5 h-5 mr-2 text-amber-600" /><h3 className="text-lg font-bold text-slate-800">Sticks List</h3></div>
                  <div className="flex items-center space-x-3">
                      <div className="flex items-center bg-slate-100 rounded-lg p-1">
                          {(['ENPAY', 'WEIDMAN'] as Vendor[]).map(v => (
                              <button key={v} onClick={() => setSelectedVendor(v)} className={`px-2 py-1 text-[10px] font-bold rounded-md transition-colors ${selectedVendor === v ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>{v}</button>
                          ))}
                      </div>
                      <button onClick={handleCopyStickTable} className="flex items-center px-3 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors font-medium text-xs">{stickCopySuccess ? <Check className="w-4 h-4 mr-1 text-emerald-600"/> : <Copy className="w-4 h-4 mr-1"/>} Copy List</button>
                  </div>
              </div>
              <div className="overflow-x-auto rounded-lg border border-slate-100">
                  <table className="w-full text-sm text-left">
                      <thead className="bg-slate-800 text-white font-bold">
                          <tr>
                            <th className="px-4 py-2 w-32">Part Number</th>
                            <th className="px-4 py-2">Description</th>
                            <th className="px-4 py-2 text-right">Thk</th>
                            <th className="px-4 py-2 text-right w-20">Lock Qty</th>
                            <th className="px-4 py-2 text-right w-20">Plain Qty</th>
                            <th className="px-4 py-2 text-right w-20">Total Qty</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {stickRows.map((row, idx) => {
                              if (row.type === 'winding') {
                                  const simpleName = row.name.split('(')[0].replace('Radial', '').trim();
                                  return (<tr key={row.id} className="bg-blue-50 text-blue-800 border-y border-blue-100"><td colSpan={6} className="px-4 py-1.5 font-bold text-center text-xs uppercase tracking-wider">{simpleName}</td></tr>);
                              }
                              
                              const totalQty = (row.lockQty || 0) + (row.plainQty || 0);

                              return (
                                  <tr key={row.id} className="hover:bg-slate-50">
                                      <td className="px-4 py-2 font-mono font-bold text-slate-700">{row.partNumber}</td>
                                      <td className="px-4 py-2 font-medium text-slate-800">{row.displayName}</td>
                                      <td className="px-4 py-2 text-right font-mono text-slate-600">{row.thk.toFixed(4)}</td>
                                      <td className="px-4 py-2 text-right font-mono text-slate-500 bg-slate-50/50">{row.lockQty > 0 ? row.lockQty : '-'}</td>
                                      <td className="px-4 py-2 text-right font-mono text-slate-500 bg-slate-50/50">{row.plainQty > 0 ? row.plainQty : '-'}</td>
                                      <td className="px-4 py-2 text-right font-mono font-bold text-indigo-700">{totalQty > 0 ? totalQty : '-'}</td>
                                  </tr>
                              );
                          })}
                      </tbody>
                  </table>
              </div>
          </div>
      )}

      {/* TABLES CONTAINER */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          
          {/* SER & KS HEADER */}
          <div className="flex justify-between items-center mb-6">
              <div className="flex items-center space-x-2">
                  <Circle className="w-5 h-5 text-indigo-500" />
                  <h3 className="text-lg font-bold text-slate-800">SER & KS Dimensions</h3>
              </div>
              <div className="flex items-center space-x-4 bg-slate-50 p-2 rounded-lg border border-slate-100">
                  <span className="text-xs font-bold text-slate-400 uppercase">Select Winding</span>
                  <select
                      value={washerWindingIndex}
                      onChange={(e) => setWasherWindingIndex(parseInt(e.target.value))}
                      className="text-xs border border-slate-300 rounded px-2 py-1 bg-white text-slate-700 focus:outline-none focus:border-indigo-500 font-bold"
                  >
                      {windingNames.slice(0, windingCount).map((name, idx) => (
                          <option key={idx} value={idx}>{name}</option>
                      ))}
                  </select>
                  <div className="h-4 w-px bg-slate-300 mx-2"></div>
                  <button 
                      onClick={() => setCalculationMethod(calculationMethod === 'mround' ? 'ceiling' : 'mround')}
                      className={`flex items-center space-x-1 px-2 py-1 rounded text-[10px] border transition-colors ${calculationMethod === 'ceiling' ? 'bg-indigo-50 border-indigo-200 text-indigo-700 font-bold' : 'bg-white border-slate-200 text-slate-500'}`}
                      title="Toggle Calculation Method for L"
                  >
                      <Settings className="w-3 h-3" />
                      <span>{calculationMethod === 'ceiling' ? 'Ceiling (Outer)' : 'MROUND (Inner)'}</span>
                  </button>
              </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {/* SER TABLE (formerly Washer) */}
              <div>
                   <table className="w-full text-sm text-left border-collapse border border-slate-200 shadow-sm">
                      <thead className="bg-slate-100">
                           <tr>
                               <th colSpan={2} className="px-4 py-2 border-b border-slate-200 text-center font-bold text-slate-700">SER</th>
                           </tr>
                      </thead>
                      <tbody>
                           <tr className="border-b border-slate-200">
                               <td className="px-4 py-2 bg-slate-50 font-medium text-slate-600 border-r border-slate-200">Qty / transformer</td>
                               <td className="px-4 py-2 bg-slate-50 font-bold text-center text-slate-800">= 6</td>
                           </tr>
                           <tr className="bg-slate-100 border-b border-slate-200">
                               <th className="px-4 py-2 font-bold text-slate-700 border-r border-slate-200">Item</th>
                               <th className="px-4 py-2 font-bold text-center text-slate-700">Dimension</th>
                           </tr>
                           <tr className="border-b border-slate-100">
                               <td className="px-4 py-2 font-medium text-slate-600 border-r border-slate-100">ID</td>
                               <td className="px-4 py-2 font-mono font-bold text-center text-slate-800">{serDims.id.toFixed(4)}</td>
                           </tr>
                           <tr>
                               <td className="px-4 py-2 font-medium text-slate-600 border-r border-slate-100">OD</td>
                               <td className="px-4 py-2 font-mono font-bold text-center text-slate-800">{serDims.od.toFixed(4)}</td>
                           </tr>
                      </tbody>
                   </table>
              </div>

              {/* KS TABLE */}
              <div>
                   <table className="w-full text-sm text-left border-collapse border border-slate-200 shadow-sm">
                      <thead className="bg-slate-100">
                           <tr>
                               <th className="px-2 py-2 border-b border-slate-200 font-bold text-slate-700 text-center w-1/3">VTC Part #</th>
                               <th className="px-2 py-2 border-b border-slate-200 text-center">
                                   <input type="text" value={currentAccessoryData.vtcPart} onChange={(e) => setVtcPart(e.target.value)} className="bg-transparent text-center font-mono text-slate-800 focus:outline-none w-full font-bold" />
                               </th>
                           </tr>
                           <tr className="border-b border-slate-200">
                               <th className="px-2 py-2 bg-slate-50 font-medium text-slate-600 text-center border-r border-slate-200">Extra KS</th>
                               <th className="px-2 py-2 bg-slate-50 text-center">
                                   <input type="number" value={currentAccessoryData.extraKS} onChange={(e) => setExtraKS(parseFloat(e.target.value) || 0)} className="bg-transparent text-center font-mono text-slate-800 focus:outline-none w-full font-bold" />
                               </th>
                           </tr>
                           <tr className="border-b border-slate-200">
                               <th className="px-2 py-2 bg-slate-50 font-medium text-slate-600 text-center border-r border-slate-200">Qty / transformer =</th>
                               <th className="px-2 py-2 bg-slate-50 text-center">
                                   <input type="text" value={currentAccessoryData.ksQty} onChange={(e) => setKsQty(e.target.value)} className="bg-transparent text-center font-mono text-slate-800 focus:outline-none w-full font-bold" />
                               </th>
                           </tr>
                      </thead>
                   </table>
                   <table className="w-full text-sm text-left border-collapse border-x border-b border-slate-200 shadow-sm mt-[-1px]">
                      <thead>
                           <tr className="bg-slate-100 border-y border-slate-200">
                               <th className="px-4 py-2 font-bold text-slate-700 border-r border-slate-200 text-center w-1/2">Item</th>
                               <th className="px-4 py-2 font-bold text-center text-slate-700 w-1/2">Dimension</th>
                           </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                           <tr><td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">A</td><td className="px-4 py-1 text-center font-mono text-slate-800">{ksDims.a}</td></tr>
                           <tr><td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">B</td><td className="px-4 py-1 text-center font-mono text-slate-800">{ksDims.b}</td></tr>
                           <tr><td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">C</td><td className="px-4 py-1 text-center font-mono text-slate-800">{ksDims.c}</td></tr>
                           <tr><td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">D</td><td className="px-4 py-1 text-center font-mono text-slate-800">{ksDims.d}</td></tr>
                           <tr><td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">F</td><td className="px-4 py-1 text-center font-mono text-slate-800">{ksDims.f}</td></tr>
                           <tr className="bg-blue-50/30"><td className="px-4 py-1 text-center font-bold text-blue-700 border-r border-slate-100">W</td><td className="px-4 py-1 text-center font-mono font-bold text-blue-800">{ksDims.w}</td></tr>
                           <tr className="bg-blue-50/30"><td className="px-4 py-1 text-center font-bold text-blue-700 border-r border-slate-100">T</td><td className="px-4 py-1 text-center font-mono font-bold text-blue-800">{ksDims.t}</td></tr>
                           <tr className="bg-emerald-50/30"><td className="px-4 py-1 text-center font-bold text-emerald-700 border-r border-slate-100">L</td><td className="px-4 py-1 text-center font-mono font-bold text-emerald-800">{ksDims.l.toFixed(4)}</td></tr>
                           <tr className="bg-emerald-50/30"><td className="px-4 py-1 text-center font-bold text-emerald-700 border-r border-slate-100">FL</td><td className="px-4 py-1 text-center font-mono font-bold text-emerald-800">{ksDims.fl.toFixed(4)}</td></tr>
                      </tbody>
                   </table>
              </div>

              {/* ANGLE SECTOR TABLE */}
              <div>
                   <table className="w-full text-sm text-left border-collapse border border-slate-200 shadow-sm">
                      <thead className="bg-slate-100">
                           <tr>
                               <th colSpan={2} className="px-4 py-2 border-b border-slate-200 text-center font-bold text-slate-700">Angle Sector</th>
                           </tr>
                      </thead>
                      <tbody>
                           <tr>
                               <th className="px-2 py-2 border-b border-slate-200 font-bold text-slate-700 text-center w-1/3 bg-white">VTC Part #</th>
                               <th className="px-2 py-2 border-b border-slate-200 text-center bg-white">
                                   <input type="text" value={currentAccessoryData.asVtcPart} onChange={(e) => setAsVtcPart(e.target.value)} className="bg-transparent text-center font-mono text-slate-800 focus:outline-none w-full font-bold" />
                               </th>
                           </tr>
                           <tr className="border-b border-slate-200">
                               <th className="px-2 py-2 bg-slate-50 font-medium text-slate-600 text-center border-r border-slate-200">Qty / transformer =</th>
                               <th className="px-2 py-2 bg-slate-50 font-mono font-bold text-slate-800 text-center">
                                   {asVals.qty.toFixed(0)}
                               </th>
                           </tr>
                      </tbody>
                   </table>
                   <table className="w-full text-sm text-left border-collapse border-x border-b border-slate-200 shadow-sm mt-[-1px]">
                      <thead>
                           <tr className="bg-slate-100 border-y border-slate-200">
                               <th className="px-4 py-2 font-bold text-slate-700 border-r border-slate-200 text-center w-1/2">Item</th>
                               <th className="px-4 py-2 font-bold text-center text-slate-700 w-1/2">Dimension</th>
                           </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                           {/* Item Selector */}
                           <tr>
                               <td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">Stack Item</td>
                               <td className="px-1 py-1 text-center">
                                    <select 
                                        value={currentAccessoryData.asItemIndex} 
                                        onChange={(e) => setAsItemIndex(parseInt(e.target.value))}
                                        className="w-full text-center text-xs border-none bg-transparent focus:ring-0 cursor-pointer font-bold text-indigo-700"
                                    >
                                        <option value={-1}>-</option>
                                        {processedRows.map((item, idx) => (
                                            <option key={item.id} value={idx}>{idx + 1}. {item.name}</option>
                                        ))}
                                    </select>
                               </td>
                           </tr>
                           <tr>
                               <td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">T</td>
                               <td className="px-4 py-1 text-center">
                                   <input type="number" step="0.001" value={currentAccessoryData.asT} onChange={(e) => setAsT(parseFloat(e.target.value))} className="w-full text-center font-mono text-slate-800 bg-transparent focus:outline-none" />
                               </td>
                           </tr>
                           <tr className="bg-emerald-50/30">
                               <td className="px-4 py-1 text-center font-bold text-emerald-700 border-r border-slate-100">I R</td>
                               <td className="px-4 py-1 text-center font-mono font-bold text-emerald-800">{asVals.ir.toFixed(4)}</td>
                           </tr>
                           <tr className="bg-emerald-50/30">
                               <td className="px-4 py-1 text-center font-bold text-emerald-700 border-r border-slate-100">B</td>
                               <td className="px-4 py-1 text-center">
                                   <div className="flex items-center justify-center space-x-2">
                                        <button onClick={() => setAsBAdjust(prev => prev - 0.0625)} className="w-4 h-4 bg-white border border-slate-200 rounded flex items-center justify-center text-slate-500 hover:text-rose-600 hover:border-rose-200"><Minus className="w-3 h-3"/></button>
                                        <span className="font-mono font-bold text-emerald-800 min-w-[60px]">{asVals.b.toFixed(4)}</span>
                                        <button onClick={() => setAsBAdjust(prev => prev + 0.0625)} className="w-4 h-4 bg-white border border-slate-200 rounded flex items-center justify-center text-slate-500 hover:text-emerald-600 hover:border-emerald-200"><Plus className="w-3 h-3"/></button>
                                   </div>
                               </td>
                           </tr>
                           <tr>
                               <td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">H</td>
                               <td className="px-4 py-1 text-center">
                                   <input type="text" value={currentAccessoryData.asH} onChange={(e) => setAsH(parseFloat(e.target.value))} className="w-full text-center font-mono text-slate-800 bg-transparent focus:outline-none" />
                               </td>
                           </tr>
                           <tr>
                               <td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">R</td>
                               <td className="px-4 py-1 text-center">
                                   <input type="number" step="0.001" value={currentAccessoryData.asR} onChange={(e) => setAsR(parseFloat(e.target.value))} className="w-full text-center font-mono text-slate-800 bg-transparent focus:outline-none" />
                               </td>
                           </tr>
                           <tr>
                               <td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">S</td>
                               <td className="px-4 py-1 text-center">
                                   <input type="text" value={currentAccessoryData.asS} onChange={(e) => setAsS(parseFloat(e.target.value))} className="w-full text-center font-mono text-slate-800 bg-transparent focus:outline-none" />
                               </td>
                           </tr>
                           <tr className="bg-emerald-50/30">
                               <td className="px-4 py-1 text-center font-bold text-emerald-700 border-r border-slate-100">L</td>
                               <td className="px-4 py-1 text-center font-mono font-bold text-emerald-800">{asVals.l.toFixed(4)}</td>
                           </tr>
                      </tbody>
                   </table>
              </div>

              {/* ANGLE CAP TABLE */}
              <div>
                   <table className="w-full text-sm text-left border-collapse border border-slate-200 shadow-sm">
                      <thead className="bg-slate-100">
                           <tr>
                               <th colSpan={2} className="px-4 py-2 border-b border-slate-200 text-center font-bold text-slate-700">Angle Cap</th>
                           </tr>
                      </thead>
                      <tbody>
                           <tr>
                               <th className="px-2 py-2 border-b border-slate-200 font-bold text-slate-700 text-center w-1/3 bg-white">VTC Part #</th>
                               <th className="px-2 py-2 border-b border-slate-200 text-center bg-white">
                                   <input type="text" value={currentAccessoryData.acVtcPart} onChange={(e) => setAcVtcPart(e.target.value)} className="bg-transparent text-center font-mono text-slate-800 focus:outline-none w-full font-bold" />
                               </th>
                           </tr>
                           <tr className="border-b border-slate-200">
                               <th className="px-2 py-2 bg-slate-50 font-medium text-slate-600 text-center border-r border-slate-200">Qty / transformer =</th>
                               <th className="px-2 py-2 bg-slate-50 font-mono font-bold text-slate-800 text-center">
                                   {acVals.qty.toFixed(0)}
                               </th>
                           </tr>
                      </tbody>
                   </table>
                   <table className="w-full text-sm text-left border-collapse border-x border-b border-slate-200 shadow-sm mt-[-1px]">
                      <thead>
                           <tr className="bg-slate-100 border-y border-slate-200">
                               <th className="px-4 py-2 font-bold text-slate-700 border-r border-slate-200 text-center w-1/2">Item</th>
                               <th className="px-4 py-2 font-bold text-center text-slate-700 w-1/2">Dimension</th>
                           </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                           {/* Item Selector */}
                           <tr>
                               <td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">Stack Item</td>
                               <td className="px-1 py-1 text-center">
                                    <select 
                                        value={currentAccessoryData.acItemIndex} 
                                        onChange={(e) => setAcItemIndex(parseInt(e.target.value))}
                                        className="w-full text-center text-xs border-none bg-transparent focus:ring-0 cursor-pointer font-bold text-indigo-700"
                                    >
                                        <option value={-1}>-</option>
                                        {processedRows.map((item, idx) => (
                                            <option key={item.id} value={idx}>{idx + 1}. {item.name}</option>
                                        ))}
                                    </select>
                               </td>
                           </tr>
                           <tr>
                               <td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">T</td>
                               <td className="px-4 py-1 text-center">
                                   <input type="number" step="0.001" value={currentAccessoryData.acT} onChange={(e) => setAcT(parseFloat(e.target.value))} className="w-full text-center font-mono text-slate-800 bg-transparent focus:outline-none" />
                               </td>
                           </tr>
                           <tr className="bg-emerald-50/30">
                               <td className="px-4 py-1 text-center font-bold text-emerald-700 border-r border-slate-100">I R</td>
                               <td className="px-4 py-1 text-center font-mono font-bold text-emerald-800">{acVals.ir.toFixed(4)}</td>
                           </tr>
                           <tr className="bg-emerald-50/30">
                               <td className="px-4 py-1 text-center font-bold text-emerald-700 border-r border-slate-100">B</td>
                               <td className="px-4 py-1 text-center">
                                   <div className="flex items-center justify-center space-x-2">
                                        <button onClick={() => setAcBAdjust(prev => prev - 0.0625)} className="w-4 h-4 bg-white border border-slate-200 rounded flex items-center justify-center text-slate-500 hover:text-rose-600 hover:border-rose-200"><Minus className="w-3 h-3"/></button>
                                        <span className="font-mono font-bold text-emerald-800 min-w-[60px]">{acVals.b.toFixed(4)}</span>
                                        <button onClick={() => setAcBAdjust(prev => prev + 0.0625)} className="w-4 h-4 bg-white border border-slate-200 rounded flex items-center justify-center text-slate-500 hover:text-emerald-600 hover:border-emerald-200"><Plus className="w-3 h-3"/></button>
                                   </div>
                               </td>
                           </tr>
                           <tr>
                               <td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">H</td>
                               <td className="px-4 py-1 text-center">
                                   <input type="text" value={currentAccessoryData.acH} onChange={(e) => setAcH(parseFloat(e.target.value))} className="w-full text-center font-mono text-slate-800 bg-transparent focus:outline-none" />
                               </td>
                           </tr>
                           <tr>
                               <td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">R</td>
                               <td className="px-4 py-1 text-center">
                                   <input type="number" step="0.001" value={currentAccessoryData.acR} onChange={(e) => setAcR(parseFloat(e.target.value))} className="w-full text-center font-mono text-slate-800 bg-transparent focus:outline-none" />
                               </td>
                           </tr>
                           <tr>
                               <td className="px-4 py-1 text-center font-medium text-slate-600 border-r border-slate-100">S</td>
                               <td className="px-4 py-1 text-center">
                                   <input type="text" value={currentAccessoryData.acS} onChange={(e) => setAcS(parseFloat(e.target.value))} className="w-full text-center font-mono text-slate-800 bg-transparent focus:outline-none" />
                               </td>
                           </tr>
                           <tr className="bg-emerald-50/30">
                               <td className="px-4 py-1 text-center font-bold text-emerald-700 border-r border-slate-100">L</td>
                               <td className="px-4 py-1 text-center font-mono font-bold text-emerald-800">{acVals.l.toFixed(4)}</td>
                           </tr>
                      </tbody>
                   </table>
              </div>

          </div>
      </div>

      {/* ID SEAL TABLE (Moved to Bottom) */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mt-6">
          <div className="flex justify-between items-center mb-4">
              <div className="flex items-center">
                  <Box className="w-5 h-5 mr-2 text-indigo-500" />
                  <h3 className="text-lg font-bold text-slate-800">ID OGW</h3>
              </div>
              <button onClick={handleCopyIdSealTable} className="flex items-center px-3 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors font-medium text-xs">{idSealCopySuccess ? <Check className="w-4 h-4 mr-1 text-emerald-600"/> : <Copy className="w-4 h-4 mr-1"/>} Copy List</button>
          </div>
          
          <div className="flex flex-wrap gap-6">
              {processedRows.map((row, idx) => {
                  if (row.type !== 'winding') return null;
                  const s = idSealState[row.id];
                  if (!s) return null;

                  // Find matching KS
                  const windingOrderIdx = windingIndices.indexOf(idx);
                  const wdgKey = `wdg${windingOrderIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
                  const ks = parseFloat(String(data?.[wdgKey]?.ksCircle || '0'));
                  const n = ks > 0 ? ks * 2 : 0;
                  const angle = n > 0 ? (360 / n).toFixed(2) : '0';
                  
                  // Slot Depth D: Previous Item Thickness
                  const prevItem = idx > 0 ? processedRows[idx - 1] : null;
                  const slotDepth = prevItem ? prevItem.thk.toFixed(3) : '0';
                  
                  // Dimensions - UPDATED: ID uses previous item's calculated ID
                  const sourceID = prevItem ? prevItem.calculatedID : row.calculatedID;
                  const dimA = applyRounding(sourceID, idSealRounding.id).toFixed(4);
                  const dimB = applyRounding(row.calculatedOD, idSealRounding.od).toFixed(4);
                  
                  // Qty Calc
                  const qtyCalc = s.qtyOpt === 3 ? 3 : s.qtyOpt === 5 ? 6 : 9;

                  return (
                      <div key={row.id} className="border border-slate-300 rounded overflow-hidden shadow-sm min-w-[250px]">
                           <div className="bg-slate-100 text-slate-800 font-bold text-center py-2 border-b border-slate-300">
                               {row.name}
                           </div>
                           <table className="w-full text-xs text-left">
                               <tbody>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 font-medium border-r border-slate-200">VTC Part #</td>
                                       <td className="px-3 py-1.5">
                                           <input 
                                               type="text" 
                                               value={s.vtcPart} 
                                               onChange={(e) => updateIdSealState(row.id, 'vtcPart', e.target.value)} 
                                               className="w-full bg-transparent focus:outline-none font-mono"
                                           />
                                       </td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 font-medium border-r border-slate-200">Qty / transformer</td>
                                       <td className="px-3 py-1.5 flex items-center space-x-2">
                                           <span>=</span>
                                           <select 
                                               value={s.qtyOpt} 
                                               onChange={(e) => updateIdSealState(row.id, 'qtyOpt', parseInt(e.target.value))}
                                               className="bg-transparent border border-slate-200 rounded px-1"
                                           >
                                               <option value={3}>3</option>
                                               <option value={5}>5</option>
                                               <option value={7}>7</option>
                                           </select>
                                           <span className="font-bold text-indigo-600">{qtyCalc}</span>
                                       </td>
                                   </tr>
                                   <tr className="bg-slate-50 border-b border-slate-200 font-bold">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">Item</td>
                                       <td className="px-3 py-1.5 text-center">Dimension</td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">T</td>
                                       <td className="px-3 py-1.5 text-center">
                                           <input 
                                               type="number" step="0.001" 
                                               value={s.t} 
                                               onChange={(e) => updateIdSealState(row.id, 't', parseFloat(e.target.value))} 
                                               className="w-16 text-center bg-transparent focus:outline-none font-mono"
                                           />
                                       </td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">
                                           <div className="flex flex-col items-center">
                                               <span>ID (A)</span>
                                               {renderRoundingControl(idSealRounding.id, (m) => setIdSealRounding('id', m))}
                                           </div>
                                       </td>
                                       <td className="px-3 py-1.5 text-center font-mono font-bold text-blue-600">{dimA}</td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">
                                           <div className="flex flex-col items-center">
                                               <span>OD (B)</span>
                                               {renderRoundingControl(idSealRounding.od, (m) => setIdSealRounding('od', m))}
                                           </div>
                                       </td>
                                       <td className="px-3 py-1.5 text-center font-mono font-bold text-blue-600">{dimB}</td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">N</td>
                                       <td className="px-3 py-1.5 text-center font-mono">{n}</td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">Angle (degrees)</td>
                                       <td className="px-3 py-1.5 text-center font-mono">{angle}</td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">Slot Depth ( D )</td>
                                       <td className="px-3 py-1.5 text-center font-mono">{slotDepth}</td>
                                   </tr>
                                   <tr>
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">Slot Width ( C )</td>
                                       <td className="px-3 py-1.5 text-center">
                                           <input 
                                               type="number" step="0.001" 
                                               value={s.c} 
                                               onChange={(e) => updateIdSealState(row.id, 'c', parseFloat(e.target.value))} 
                                               className="w-16 text-center bg-transparent focus:outline-none font-mono"
                                           />
                                       </td>
                                   </tr>
                               </tbody>
                           </table>
                           <div className="text-[10px] text-slate-400 bg-slate-50/50 px-2 py-1 text-center border-t border-slate-200">
                               ID: {getRoundingLabel(idSealRounding.id)}(Stk ID) | OD: {getRoundingLabel(idSealRounding.od)}(Calc OD)
                           </div>
                      </div>
                  );
              })}
          </div>
      </div>
      
      {/* OD SEAL TABLE (New) */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mt-6">
          <div className="flex justify-between items-center mb-4">
              <div className="flex items-center">
                  <Box className="w-5 h-5 mr-2 text-indigo-500" />
                  <h3 className="text-lg font-bold text-slate-800">OD OGW</h3>
              </div>
              <button onClick={handleCopyOdSealTable} className="flex items-center px-3 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors font-medium text-xs">{odSealCopySuccess ? <Check className="w-4 h-4 mr-1 text-emerald-600"/> : <Copy className="w-4 h-4 mr-1"/>} Copy List</button>
          </div>
          
          <div className="flex flex-wrap gap-6">
              {processedRows.map((row, idx) => {
                  if (row.type !== 'winding') return null;
                  const s = odSealState[row.id];
                  const idState = idSealState[row.id];
                  if (!s || !idState) return null;

                  // Find matching KS
                  const windingOrderIdx = windingIndices.indexOf(idx);
                  const wdgKey = `wdg${windingOrderIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
                  const ks = parseFloat(String(data?.[wdgKey]?.ksCircle || '0'));
                  const n = ks > 0 ? ks * 2 : 0;
                  const angle = n > 0 ? (360 / n).toFixed(2) : '0';
                  
                  // Slot Depth D: Next Item Thickness (after winding)
                  const nextItem = idx < processedRows.length - 1 ? processedRows[idx + 1] : null;
                  const slotDepth = nextItem ? nextItem.thk.toFixed(3) : '0';
                  
                  // Dimensions - UPDATED: ID uses previous item's calculated OD
                  const prevItem = idx > 0 ? processedRows[idx - 1] : null;
                  const sourceID = prevItem ? prevItem.calculatedOD : row.calculatedOD;
                  const dimA = applyRounding(sourceID, odSealRounding.id).toFixed(4);
                  const dimB = nextItem ? applyRounding(nextItem.calculatedOD, odSealRounding.od).toFixed(4) : '0';
                  
                  // Qty Calc: ((ID_Qty + 1) / 2) * 3
                  // 3 -> 6, 5 -> 9, 7 -> 12
                  const qtyCalc = ((idState.qtyOpt + 1) / 2) * 3;

                  return (
                      <div key={row.id} className="border border-slate-300 rounded overflow-hidden shadow-sm min-w-[250px]">
                           <div className="bg-slate-100 text-slate-800 font-bold text-center py-2 border-b border-slate-300">
                               {row.name}
                           </div>
                           <table className="w-full text-xs text-left">
                               <tbody>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 font-medium border-r border-slate-200">VTC Part #</td>
                                       <td className="px-3 py-1.5">
                                           <input 
                                               type="text" 
                                               value={s.vtcPart} 
                                               onChange={(e) => updateOdSealState(row.id, 'vtcPart', e.target.value)} 
                                               className="w-full bg-transparent focus:outline-none font-mono"
                                           />
                                       </td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 font-medium border-r border-slate-200">Qty / transformer</td>
                                       <td className="px-3 py-1.5 flex items-center space-x-2">
                                           <span>=</span>
                                           <span className="font-bold text-indigo-600">{qtyCalc}</span>
                                       </td>
                                   </tr>
                                   <tr className="bg-slate-50 border-b border-slate-200 font-bold">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">Item</td>
                                       <td className="px-3 py-1.5 text-center">Dimension</td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">T</td>
                                       <td className="px-3 py-1.5 text-center">
                                           <input 
                                               type="number" step="0.001" 
                                               value={s.t} 
                                               onChange={(e) => updateOdSealState(row.id, 't', parseFloat(e.target.value))} 
                                               className="w-16 text-center bg-transparent focus:outline-none font-mono"
                                           />
                                       </td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">
                                           <div className="flex flex-col items-center">
                                               <span>ID (A)</span>
                                               {renderRoundingControl(odSealRounding.id, (m) => setOdSealRounding('id', m))}
                                           </div>
                                       </td>
                                       <td className="px-3 py-1.5 text-center font-mono font-bold text-blue-600">{dimA}</td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">
                                           <div className="flex flex-col items-center">
                                               <span>OD (B)</span>
                                               {renderRoundingControl(odSealRounding.od, (m) => setOdSealRounding('od', m))}
                                           </div>
                                       </td>
                                       <td className="px-3 py-1.5 text-center font-mono font-bold text-blue-600">{dimB}</td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">N</td>
                                       <td className="px-3 py-1.5 text-center font-mono">{n}</td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">Angle (degrees)</td>
                                       <td className="px-3 py-1.5 text-center font-mono">{angle}</td>
                                   </tr>
                                   <tr className="border-b border-slate-200">
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">Slot Depth ( D )</td>
                                       <td className="px-3 py-1.5 text-center font-mono">{slotDepth}</td>
                                   </tr>
                                   <tr>
                                       <td className="px-3 py-1.5 text-center border-r border-slate-200">Slot Width ( C )</td>
                                       <td className="px-3 py-1.5 text-center">
                                           <input 
                                               type="number" step="0.001" 
                                               value={s.c} 
                                               onChange={(e) => updateOdSealState(row.id, 'c', parseFloat(e.target.value))} 
                                               className="w-16 text-center bg-transparent focus:outline-none font-mono"
                                           />
                                       </td>
                                   </tr>
                               </tbody>
                           </table>
                           <div className="text-[10px] text-slate-400 bg-slate-50/50 px-2 py-1 text-center border-t border-slate-200">
                               ID: {getRoundingLabel(odSealRounding.id)}(Stk ID) | OD: {getRoundingLabel(odSealRounding.od)}(Next OD)
                           </div>
                      </div>
                  );
              })}
          </div>
      </div>

      {/* TOP & BOTTOM HEAD SHEET TABLE */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mt-6">
          <div className="flex justify-between items-center mb-4">
              <div className="flex items-center">
                  <Layers className="w-5 h-5 mr-2 text-indigo-500" />
                  <h3 className="text-lg font-bold text-slate-800">Top & Bottom Head Sheet</h3>
              </div>
              <button onClick={handleCopyHeadSheet} className="flex items-center px-3 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors font-medium text-xs">{headSheetCopySuccess ? <Check className="w-4 h-4 mr-1 text-emerald-600"/> : <Copy className="w-4 h-4 mr-1"/>} Copy List</button>
          </div>
          
          <div className="overflow-x-auto rounded-lg border border-slate-100">
                <table className="w-full text-xs text-left border-collapse border border-slate-200 shadow-sm">
                    <thead className="bg-slate-100">
                        <tr>
                            <th className="px-4 py-2 border-b border-slate-200 text-left font-bold text-slate-700">Item</th>
                            <th className="px-4 py-2 border-b border-slate-200 text-center font-bold text-slate-700">Dimension</th>
                            <th className="px-4 py-2 border-b border-slate-200 text-left font-bold text-slate-400">Formula / Note</th>
                        </tr>
                    </thead>
                    <tbody>
                        {/* Header Rows */}
                        <tr className="border-b border-slate-200">
                            <td className="px-4 py-2 font-medium text-slate-600 border-r border-slate-200">VTC Part</td>
                            <td className="px-4 py-2 text-center bg-white border-r border-slate-200 p-0">
                                <input type="text" value={headSheet.vtcPart} onChange={(e) => setHeadSheet('vtcPart', e.target.value)} className="w-full h-full text-center bg-transparent focus:outline-none font-mono font-bold text-slate-800 py-1" />
                            </td>
                            <td className="px-4 py-2 text-slate-400 italic">std</td>
                        </tr>
                        <tr className="border-b border-slate-200">
                            <td className="px-4 py-2 font-medium text-slate-600 border-r border-slate-200">Qty / transformer</td>
                            <td className="px-4 py-2 text-center bg-white border-r border-slate-200 p-0">
                                <input type="number" value={headSheet.qty} onChange={(e) => setHeadSheet('qty', parseFloat(e.target.value) || 0)} className="w-full h-full text-center bg-transparent focus:outline-none font-mono font-bold text-slate-800 py-1" />
                            </td>
                            <td className="px-4 py-2 text-slate-400 italic">std</td>
                        </tr>
                        
                        {/* Detail Rows */}
                        <tr className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="px-4 py-2 font-bold text-slate-700 border-r border-slate-100">T</td>
                            <td className="px-4 py-2 text-center bg-white border-r border-slate-100 p-0">
                                <input type="number" step="0.001" value={headSheet.t} onChange={(e) => setHeadSheet('t', parseFloat(e.target.value) || 0)} className="w-full h-full text-center bg-transparent focus:outline-none font-mono text-slate-800 py-1" />
                            </td>
                            <td className="px-4 py-2 text-slate-400 italic">std</td>
                        </tr>
                        <tr className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="px-4 py-2 font-bold text-slate-700 border-r border-slate-100">A</td>
                            <td className="px-4 py-2 text-center font-mono font-bold text-blue-700 border-r border-slate-100">{headSheetVals.a.toFixed(4)}</td>
                            <td className="px-4 py-2 text-slate-500 font-mono text-[10px]">=CEILING.MATH(Outmost winding's ID ,0.0625)</td>
                        </tr>
                        <tr className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="px-4 py-2 font-bold text-slate-700 border-r border-slate-100">B</td>
                            <td className="px-4 py-2 text-center font-mono font-bold text-blue-700 border-r border-slate-100">{headSheetVals.b.toFixed(4)}</td>
                            <td className="px-4 py-2 text-slate-500 font-mono text-[10px]">=MROUND(outmost winding's OD + 4,0.0625)</td>
                        </tr>
                        <tr className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="px-4 py-2 font-bold text-slate-700 border-r border-slate-100">C</td>
                            <td className="px-4 py-2 text-center font-mono font-bold text-blue-700 border-r border-slate-100">{headSheetVals.c.toFixed(4)}</td>
                            <td className="px-4 py-2 text-slate-500 font-mono text-[10px]">Leg center-0.75</td>
                        </tr>
                        <tr className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="px-4 py-2 font-bold text-slate-700 border-r border-slate-100">D</td>
                            <td className="px-4 py-2 text-center bg-white border-r border-slate-100 p-0">
                                <input type="number" step="0.1" value={headSheet.d} onChange={(e) => setHeadSheet('d', parseFloat(e.target.value) || 0)} className="w-full h-full text-center bg-transparent focus:outline-none font-mono text-slate-800 py-1" />
                            </td>
                            <td className="px-4 py-2 text-slate-400 italic">std</td>
                        </tr>
                        <tr className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="px-4 py-2 font-bold text-slate-700 border-r border-slate-100">E</td>
                            <td className="px-4 py-2 text-center font-mono font-bold text-emerald-700 border-r border-slate-100">{headSheetVals.e.toFixed(4)}</td>
                            <td className="px-4 py-2 text-slate-500 font-mono text-[10px]">=C+2*D</td>
                        </tr>
                        <tr className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="px-4 py-2 font-bold text-slate-700 border-r border-slate-100">F</td>
                            <td className="px-4 py-2 text-center font-mono font-bold text-emerald-700 border-r border-slate-100">{headSheetVals.f.toFixed(4)}</td>
                            <td className="px-4 py-2 text-slate-500 font-mono text-[10px]">=MROUND( C /4,0.0625)</td>
                        </tr>
                        <tr className="hover:bg-slate-50">
                            <td className="px-4 py-2 font-bold text-slate-700 border-r border-slate-100">G</td>
                            <td className="px-4 py-2 text-center font-mono font-bold text-emerald-700 border-r border-slate-100">{headSheetVals.g.toFixed(4)}</td>
                            <td className="px-4 py-2 text-slate-500 font-mono text-[10px]">=F+6</td>
                        </tr>
                    </tbody>
                </table>
          </div>
      </div>

      {renderCTCRisersTable()}
    </div>
  );
};

export default Page6;

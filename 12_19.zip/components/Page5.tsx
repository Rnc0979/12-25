
import React, { useState, useEffect } from 'react';
import { ArrowLeft, Table as TableIcon, Copy, Check, ArrowRight, RotateCcw, LayoutTemplate, Box, Sigma, FunctionSquare, Calculator, ChevronDown, ChevronUp } from 'lucide-react';
import { ExtractedData, Page5State } from '../types';
import { calculateWindingDetails } from '../utils/calculations';

interface Page5Props {
  data: ExtractedData | null;
  mainData: ExtractedData | null;
  onBack: () => void;
  windingNames: string[];
  windingCount: number;
  pageState: Page5State;
  setPageState: React.Dispatch<React.SetStateAction<Page5State>>;
}

const Page5: React.FC<Page5Props> = ({ onBack, pageState, setPageState, mainData, windingNames, windingCount }) => {
  const [parsedGrid, setParsedGrid] = useState<string[][]>([]);
  const [copySuccess, setCopySuccess] = useState<string | null>(null);
  const [showFormulas, setShowFormulas] = useState(false);
  
  // Collapsible State
  const [isWindingDetailsExpanded, setIsWindingDetailsExpanded] = useState(false);
  const [isArrangementExpanded, setIsArrangementExpanded] = useState(false);

  // Parse input text whenever it changes
  useEffect(() => {
      const rows = pageState.inputText.split('\n').filter(r => r.trim() !== '');
      // Split by tabs or multiple spaces
      const grid = rows.map(r => r.trim().split(/\s+/));
      setParsedGrid(grid);
  }, [pageState.inputText]);

  // Set default selection for Column 1 if null
  useEffect(() => {
      if (pageState.col1WindingIndex === null) {
          // Default to "Near Outermost" (windingCount - 2, 0-indexed)
          const defaultIdx = Math.max(0, windingCount - 2);
          setPageState(prev => ({ ...prev, col1WindingIndex: defaultIdx }));
      }
  }, [windingCount, pageState.col1WindingIndex]);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setPageState(prev => ({ ...prev, inputText: e.target.value }));
  };

  // Logic for Primary Rows (Row 1 & 2): Deletion triggers upshift
  const handlePrimaryDelete = (tableId: string, visualColIndex: number) => {
      setPageState(prev => {
          const currentDeleted = prev.deletedPrimaryIndices[tableId] || [];
          
          // Map visual index to original index
          let originalIndex = -1;
          let validCount = -1;
          
          for (let i = 0; i < 2000; i++) {
               if (!currentDeleted.includes(i)) {
                   validCount++;
               }
               if (validCount === visualColIndex) {
                   originalIndex = i;
                   break;
               }
          }
          
          if (originalIndex !== -1) {
              return {
                  ...prev,
                  deletedPrimaryIndices: {
                      ...prev.deletedPrimaryIndices,
                      [tableId]: [...currentDeleted, originalIndex].sort((a,b) => a-b)
                  }
              };
          }
          return prev;
      });
  };

  // Logic for Secondary Rows (Row 3 & 4): Click toggles specific cell mask
  const handleSecondaryToggle = (tableId: string, rowIndex: number, colIndex: number) => {
      setPageState(prev => {
          const cellId = `${tableId}-${rowIndex}-${colIndex}`;
          const currentExcluded = prev.excludedCells || [];
          const isExcluded = currentExcluded.includes(cellId);
          
          let newExcluded;
          if (isExcluded) {
              newExcluded = currentExcluded.filter(id => id !== cellId);
          } else {
              newExcluded = [...currentExcluded, cellId];
          }

          return {
              ...prev,
              excludedCells: newExcluded
          };
      });
  };

  const handleResetTable = (tableId: string) => {
      setPageState(prev => ({
          ...prev,
          deletedPrimaryIndices: { ...prev.deletedPrimaryIndices, [tableId]: [] },
          // Filter out excluded cells that belong to this tableId
          excludedCells: (prev.excludedCells || []).filter(id => !id.startsWith(`${tableId}-`))
      }));
  };

  // --- Calculations for Winding Details ---
  const wdg1Calc = mainData ? calculateWindingDetails(mainData.wdg1) : null;
  const wdg2Calc = mainData ? calculateWindingDetails(mainData.wdg2) : null;
  const wdg3Calc = mainData ? calculateWindingDetails(mainData.wdg3) : null;

  const handleCopyWindingDetails = (index: number) => {
    if (!wdg1Calc || !wdg2Calc || !wdg3Calc) return;
    
    let target;
    if (index === 0) target = wdg1Calc;
    else if (index === 1) target = wdg2Calc;
    else target = wdg3Calc;

    const values = [
        target.calcStrands,
        target.calcTotal,
        target.thk,
        target.width
    ];
    navigator.clipboard.writeText(values.join('\n')).then(() => {
        setCopySuccess(`wdg-details-${index}`);
        setTimeout(() => setCopySuccess(null), 2000);
    });
  };

  // --- Comparison Logic ---
  // Column 1 Table compares with Selected Winding (Rated Turns)
  // Column 2 Table compares with Outermost Winding (Max Turns)
  
  const getReferenceValues = () => {
      if (!mainData) return { ref1: 0, ref2: 0, details1: null, details2: null };

      // Outermost Winding Key (e.g., wdg3 for 3 windings, wdg2 for 2 windings)
      const outerIndex = windingCount - 1;
      const outerKey = `wdg${windingCount}` as 'wdg1' | 'wdg2' | 'wdg3';
      
      // Selected Winding Key for Col 1
      const selectedIndex = pageState.col1WindingIndex !== null ? pageState.col1WindingIndex : Math.max(0, windingCount - 2);
      const selectedKey = `wdg${selectedIndex + 1}` as 'wdg1' | 'wdg2' | 'wdg3';

      // Ref 2 (for Col 2 Table): Max Turns of Outermost
      const ref2 = mainData[outerKey]?.maxTurns || mainData[outerKey]?.ratedTurns || 0;

      // Ref 1 (for Col 1 Table): Rated Turns of Selected Winding
      const ref1 = mainData[selectedKey]?.ratedTurns || 0;

      // Get Details objects
      const detailsList = [wdg1Calc, wdg2Calc, wdg3Calc];
      const details1 = detailsList[selectedIndex];
      const details2 = detailsList[outerIndex];

      return { ref1, ref2, details1, details2 };
  };

  const { ref1, ref2, details1, details2 } = getReferenceValues();


  // --- Table Processing Logic ---
  const getReversedColumn = (colIndex: number) => {
      if (parsedGrid.length === 0) return [];
      const colData = parsedGrid.map(row => row[colIndex]).filter(val => val !== undefined && val.trim() !== '');
      return [...colData].reverse();
  };

  const roundValue = (val: string) => {
      const num = parseFloat(val);
      if (isNaN(num)) return val;
      return num.toFixed(2);
  };

  const processColumnTable = (
      primaryColIndex: number, 
      secondaryColIndex: number, 
      tableId: string
  ) => {
      const reversedPrimary = getReversedColumn(primaryColIndex);
      const reversedSecondary = getReversedColumn(secondaryColIndex);
      
      if (reversedPrimary.length < 3) return null;

      // 1. Generate Primary Rows (Row 1 & 2)
      const rawRow1: string[] = [];
      const rawRow2: string[] = [];
      for (let i = 1; i < reversedPrimary.length - 1; i++) {
          rawRow1.push(roundValue(reversedPrimary[i]));
          rawRow2.push(roundValue(reversedPrimary[i + 1]));
      }

      // 2. Generate Secondary Rows (Row 3 & 4) - Full Copy
      const rawRow3: string[] = [];
      const rawRow4: string[] = [];
      for (let i = 0; i < reversedSecondary.length; i++) {
          const val = roundValue(reversedSecondary[i]);
          rawRow3.push(val);
          rawRow4.push(val);
      }

      // 3. Filter Primary Rows (Deletion/Upshift)
      const deletedIndices = pageState.deletedPrimaryIndices[tableId] || [];
      const filteredRow1 = rawRow1.filter((_, idx) => !deletedIndices.includes(idx));
      const filteredRow2 = rawRow2.filter((_, idx) => !deletedIndices.includes(idx));

      return {
          primary: [filteredRow1, filteredRow2],
          secondary: [rawRow3, rawRow4]
      };
  };

  const table1 = processColumnTable(0, 2, "t1"); // Col 1 & Col 3
  const table2 = processColumnTable(1, 3, "t2"); // Col 2 & Col 4

  const isCellExcluded = (tableId: string, rowIdx: number, colIdx: number) => {
      // RowIdx is relative to Secondary rows (0 for Row 3, 1 for Row 4)
      return (pageState.excludedCells || []).includes(`${tableId}-${rowIdx}-${colIdx}`);
  };

  const handleCopyTable = (
      data: { primary: string[][], secondary: string[][] } | null, 
      tableId: string,
      details: any // Calc Details
  ) => {
      if (!data) return;
      const { primary, secondary } = data;
      
      const width = Math.max(
          primary[0]?.length || 0,
          secondary[0]?.length || 0
      );

      const rowsForCopy: string[][] = [];
      
      // Rows 1-4 (Standard)
      for (let r = 0; r < 4; r++) {
          const rowData: string[] = [];
          for (let c = 0; c < width; c++) {
              let val = "";
              if (r < 2) {
                  val = primary[r][c] || "";
              } else {
                  const secRowIdx = r - 2;
                  if (isCellExcluded(tableId, secRowIdx, c)) {
                      val = "";
                  } else {
                      val = secondary[secRowIdx][c] || "";
                  }
              }
              rowData.push(val);
          }
          rowsForCopy.push(rowData);
      }

      // Rows 5-8 (Static Details)
      if (details) {
          const staticValues = [
              String(details.calcStrands || ''),
              String(details.calcTotal || ''),
              String(details.thk || ''),
              String(details.width || '')
          ];
          staticValues.forEach(val => {
              const rowData: string[] = [];
              for(let c = 0; c < width; c++) {
                  rowData.push(val);
              }
              rowsForCopy.push(rowData);
          });
      }

      const text = rowsForCopy.map(row => row.join('\t')).join('\n');
      navigator.clipboard.writeText(text).then(() => {
          setCopySuccess(tableId);
          setTimeout(() => setCopySuccess(null), 2000);
      });
  };

  const renderProcessedTable = (
      data: { primary: string[][], secondary: string[][] } | null, 
      title: string, 
      tableId: string,
      referenceValue: number,
      details: any,
      showWindingSelector: boolean = false
  ) => {
      if (!data) return null;
      const { primary, secondary } = data;
      const deletedCount = (pageState.deletedPrimaryIndices[tableId]?.length || 0);
      
      const width = Math.max(
          primary[0]?.length || 0,
          secondary[0]?.length || 0
      );
      
      const grid: React.ReactNode[][] = [];
      const rowTotals: number[] = [];

      // Render Rows 1-4
      for (let r = 0; r < 4; r++) {
          const rowNodes: React.ReactNode[] = [];
          let currentSum = 0;

          for (let c = 0; c < width; c++) {
              let content = "";
              let isExcluded = false;
              let isPrimary = r < 2;

              if (isPrimary) {
                  content = primary[r][c] || "";
              } else {
                  const secRowIdx = r - 2;
                  content = secondary[secRowIdx][c] || "";
                  isExcluded = isCellExcluded(tableId, secRowIdx, c);
              }

              // Summation Logic for Row 3 & 4
              if (!isPrimary && !isExcluded && content) {
                  const val = parseFloat(content);
                  if (!isNaN(val)) currentSum += val;
              }

              rowNodes.push(
                  <td key={c} className="border-r border-slate-100 last:border-r-0 min-w-[60px] p-0 relative group">
                      <button
                          onClick={() => isPrimary ? handlePrimaryDelete(tableId, c) : handleSecondaryToggle(tableId, r - 2, c)}
                          className={`w-full h-full px-4 py-2 font-mono text-xs text-left transition-colors focus:outline-none 
                              ${isPrimary 
                                  ? 'hover:bg-rose-50 hover:text-rose-700 text-slate-700' 
                                  : isExcluded 
                                      ? 'bg-slate-50 text-slate-300 line-through decoration-slate-300 hover:text-slate-400' 
                                      : 'hover:bg-amber-50 hover:text-amber-700 text-slate-700'
                              }
                          `}
                          title={isPrimary ? "Click to Delete (Upshift)" : "Click to Exclude (Mask)"}
                      >
                          {content}
                      </button>
                  </td>
              );
          }
          grid.push(rowNodes);
          rowTotals.push(currentSum);
      }

      // Render Rows 5-8 (Static)
      if (details) {
          const staticLabels = ['Strands', 'Total', 'Thk', 'Width'];
          const staticValues = [details.calcStrands, details.calcTotal, details.thk, details.width];
          
          staticValues.forEach((val, idx) => {
              const rowNodes: React.ReactNode[] = [];
              for(let c = 0; c < width; c++) {
                  rowNodes.push(
                      <td key={`static-${idx}-${c}`} className="border-r border-slate-100 last:border-r-0 px-4 py-2 font-mono text-xs text-slate-500 bg-slate-50/30">
                          {val || '-'}
                      </td>
                  );
              }
              grid.push(rowNodes);
              rowTotals.push(-1); // Marker for non-summable rows
          });
      }

      // Generate Numbered Headers (1, 2, 3...)
      const getColumnLabel = (index: number) => {
          return (index + 1).toString();
      };

      return (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col mt-4">
              <div className="px-4 py-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                      <div className="flex items-center">
                        <ArrowRight className="w-4 h-4 mr-2 text-indigo-500" />
                        <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800">{title}</h3>
                      </div>
                      
                      {showWindingSelector && (
                          <div className="flex items-center ml-4">
                             <select 
                                value={pageState.col1WindingIndex ?? ''}
                                onChange={(e) => setPageState(prev => ({ ...prev, col1WindingIndex: parseInt(e.target.value) }))}
                                className="text-xs border border-slate-300 rounded px-2 py-1 bg-white text-slate-700 focus:outline-none focus:border-indigo-500"
                             >
                                {windingNames.map((name, idx) => {
                                    // Exclude Outermost Winding from Selection
                                    if (idx === windingCount - 1) return null;
                                    return <option key={idx} value={idx}>{name}</option>;
                                })}
                             </select>
                          </div>
                      )}

                      {(deletedCount > 0 || (pageState.excludedCells?.length || 0) > 0) && (
                          <button 
                            onClick={() => handleResetTable(tableId)}
                            className="flex items-center px-2 py-1 rounded text-[10px] font-bold border bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100"
                          >
                             <RotateCcw className="w-3 h-3 mr-1" />
                             Reset
                          </button>
                      )}
                  </div>

                  <button 
                      onClick={() => handleCopyTable(data, tableId, details)}
                      className="text-xs flex items-center text-slate-500 hover:text-indigo-600 transition-colors bg-white border border-slate-200 px-2 py-1 rounded hover:border-indigo-300 shadow-sm"
                  >
                      {copySuccess === tableId ? <Check className="w-3 h-3 mr-1 text-emerald-500"/> : <Copy className="w-3 h-3 mr-1"/>}
                      Copy
                  </button>
              </div>
              
              {showFormulas && (
                 <div className="bg-amber-50 px-4 py-1.5 border-b border-amber-100 text-[10px] text-amber-800 font-mono flex items-center">
                     <FunctionSquare className="w-3 h-3 mr-2 opacity-70"/>
                     <span className="font-bold mr-1">Formula:</span>
                     <span className="opacity-80">TOTAL = SUM( {tableId === 't1' ? 'Col 3' : 'Col 4'} ) - Excluded Cells</span>
                 </div>
              )}

              <div className="overflow-x-auto p-0">
                  <table className="w-full text-xs text-left border-collapse">
                      <thead className="bg-slate-50 text-slate-400 font-mono text-[10px]">
                          <tr>
                             {/* Total Header Column */}
                             <th className="px-4 py-2 border-b border-slate-200 border-r text-center bg-slate-100 whitespace-nowrap min-w-[80px]">
                                 {showFormulas ? <Sigma className="w-3 h-3 mx-auto text-slate-400"/> : 'Total'}
                             </th>
                             {/* Numbered Headers (Spreadsheet Style) */}
                             {Array.from({ length: width }).map((_, i) => (
                                 <th key={i} className="px-4 py-2 border-b border-slate-200 border-r last:border-r-0 text-center">
                                     {getColumnLabel(i)}
                                 </th>
                             ))}
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {grid.map((rowNodes, rIdx) => (
                              <tr key={rIdx} className="hover:bg-slate-50">
                                  {/* Row Total / Label Cell */}
                                  <td className="px-2 py-2 border-r border-slate-200 bg-slate-50 font-bold text-slate-600 text-center min-w-[80px]">
                                      {rIdx < 4 ? (
                                           rIdx >= 2 ? (
                                                <div className="flex flex-col items-center justify-center leading-tight">
                                                    <span className="text-indigo-600">{rowTotals[rIdx].toFixed(2)}</span>
                                                    {referenceValue > 0 && (
                                                        <span className="text-[9px] text-slate-400 font-normal mt-0.5">
                                                            / {referenceValue}
                                                        </span>
                                                    )}
                                                </div>
                                           ) : <span className="text-slate-300 text-[10px]">{rIdx + 1}</span>
                                      ) : (
                                          // Labels for Rows 5-8
                                          <span className="text-[10px] uppercase text-slate-400">
                                              {['Strands', 'Total', 'Thk', 'Width'][rIdx - 4]}
                                          </span>
                                      )}
                                  </td>
                                  {/* Data Cells */}
                                  {rowNodes}
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
          </div>
      );
  };

  const renderArrangementTable = () => {
    if (!mainData) return null;

    const windings = [mainData.wdg1, mainData.wdg2, mainData.wdg3].slice(0, windingCount);
    
    // Helpers for Simulation
    const cleanFloat = (v: any) => parseFloat(String(v || 0));
    
    // 1. Calculate Inner Radii (ID/2)
    const innerRadii = windings.map(w => cleanFloat(w.id) / 2);
    // 2. Get Radial Widths
    const radialWidths = windings.map(w => cleanFloat(w.radial));
    // 3. Calculate Theoretical Outer Radius (IR + Radial)
    const calculatedOR = innerRadii.map((ir, i) => ir + radialWidths[i]);
    // 4. Get Actual Outer Radius (OD/2) for comparison
    const actualOR = windings.map(w => cleanFloat(w.od) / 2);
    // 5. Calculate Gaps (Next IR - Current OR)
    const gaps = [];
    for(let i=0; i < windings.length - 1; i++) {
        gaps.push(innerRadii[i+1] - actualOR[i]);
    }
    gaps.push(0); // Last winding has no next gap context here

    const rows = [
        {
            label: "INNER RADIUS (ID/2)",
            values: innerRadii.map(v => v.toFixed(2))
        },
        {
            label: "RADIAL WIDTH",
            values: radialWidths.map(v => v.toFixed(2))
        }
    ];

    if (showFormulas) {
        rows.push({
            label: "CALC OUTER RADIUS (IR+W)",
            values: calculatedOR.map(v => v.toFixed(2))
        });
        rows.push({
            label: "ACTUAL OUTER RADIUS (OD/2)",
            values: actualOR.map(v => v.toFixed(2))
        });
        rows.push({
            label: "GAP TO NEXT",
            values: gaps.map((v, i) => i === gaps.length - 1 ? '-' : v.toFixed(2))
        });
    }

    // Add existing rows
    const staticRows = [
        {
            label: "TERMINAL NR.",
            values: Array.from({ length: windingCount }, (_, i) => windingCount - i)
        },
        {
            label: "NR. PARALL GR",
            values: windings.map(w => w.parallelGroups || '-')
        },
        {
            label: "CURRENT +1/-1",
            values: [-1, 1, -1].slice(0, windingCount)
        },
        {
            label: "1=Cu, 2=Al",
            values: [1, 1, 1].slice(0, windingCount)
        },
        {
            label: "SPACER BLOCK NR",
            values: windings.map(w => w.ksCircle || '-')
        },
        {
            label: "SPACER BLOCK WIDTH",
            values: windings.map(w => w.ksWidth || '-')
        }
    ];

    const allRows = [...rows, ...staticRows];

    const copyArrangementTable = () => {
        const lines = allRows.map(r => r.values.join('\t'));
        navigator.clipboard.writeText(lines.join('\n')).then(() => {
            setCopySuccess('arrangement-table');
            setTimeout(() => setCopySuccess(null), 2000);
        });
    };

    return (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6 transition-all duration-300">
            <div 
                className="px-4 py-3 bg-slate-50 border-b border-slate-100 flex justify-between items-center cursor-pointer hover:bg-slate-100 transition-colors"
                onClick={() => setIsArrangementExpanded(!isArrangementExpanded)}
            >
                <div className="flex items-center">
                    <LayoutTemplate className="w-5 h-5 mr-2 text-indigo-500" />
                    <h3 className="text-lg font-semibold text-slate-700">Arrangement Table</h3>
                    <span className="ml-2 text-[10px] text-slate-400 font-normal">
                        {isArrangementExpanded ? '(Click to collapse)' : '(Click to expand)'}
                    </span>
                </div>
                <div className="flex items-center space-x-3">
                    {isArrangementExpanded && (
                        <>
                            {showFormulas && (
                                <span className="text-[10px] bg-indigo-50 text-indigo-600 px-2 py-1 rounded font-bold animate-pulse">
                                    Simulation Active
                                </span>
                            )}
                            <select 
                                value={pageState.selectedTableType}
                                onChange={(e) => {
                                    e.stopPropagation();
                                    setPageState(prev => ({...prev, selectedTableType: e.target.value as any}));
                                }}
                                onClick={(e) => e.stopPropagation()}
                                className="text-xs border border-slate-300 rounded px-2 py-1 bg-white text-slate-700 focus:outline-none focus:border-indigo-500"
                            >
                                <option value="autotransformer">AutoTransformer</option>
                            </select>
                            <button 
                                onClick={(e) => {
                                    e.stopPropagation();
                                    copyArrangementTable();
                                }}
                                className="text-xs flex items-center text-slate-500 hover:text-indigo-600 transition-colors bg-white border border-slate-200 px-2 py-1 rounded hover:border-indigo-300 shadow-sm"
                            >
                                {copySuccess === 'arrangement-table' ? <Check className="w-3 h-3 mr-1 text-emerald-500"/> : <Copy className="w-3 h-3 mr-1"/>}
                                Copy
                            </button>
                        </>
                    )}
                    {isArrangementExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                </div>
            </div>

            {isArrangementExpanded && (
                <div className="p-6 animate-fadeIn">
                    <div className="overflow-x-auto rounded-lg border border-slate-100">
                        <table className="w-full text-sm text-left">
                            <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
                                <tr>
                                    <th className="px-4 py-2 w-1/3">Parameter</th>
                                    {windings.map((_, i) => (
                                        <th key={i} className={`px-4 py-2 ${i === 0 ? 'text-blue-700' : i === 1 ? 'text-orange-700' : 'text-purple-700'}`}>
                                            {windingNames[i]}
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {allRows.map((row, idx) => (
                                    <tr key={idx} className={`hover:bg-slate-50 ${showFormulas && (idx === 2 || idx === 4) ? 'bg-indigo-50/30' : ''}`}>
                                        <td className="px-4 py-2 font-medium text-slate-600 text-xs uppercase">{row.label}</td>
                                        {row.values.map((val, vIdx) => (
                                            <td key={vIdx} className="px-4 py-2 font-mono text-slate-800 font-bold text-xs">
                                                {val}
                                            </td>
                                        ))}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
  };

  const renderCoreSpecsTable = () => {
    if (!mainData) return null;

    const windowHt = mainData.core.windowHt || '-';
    const feCircle = mainData.core.feCircle || '-';

    const handleCopyCoreSpecs = () => {
        const text = `${windowHt}\t${feCircle}`;
        navigator.clipboard.writeText(text).then(() => {
            setCopySuccess('core-specs');
            setTimeout(() => setCopySuccess(null), 2000);
        });
    }

    return (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 mb-4">
            <div className="flex justify-between items-center mb-4">
                <div className="flex items-center">
                    <Box className="w-5 h-5 mr-2 text-indigo-500" />
                    <h3 className="text-lg font-semibold text-slate-700">Core Specs</h3>
                </div>
                <button onClick={handleCopyCoreSpecs} className="text-xs flex items-center text-slate-500 hover:text-indigo-600 transition-colors bg-white border border-slate-200 px-2 py-1 rounded hover:border-indigo-300 shadow-sm">
                    {copySuccess === 'core-specs' ? <Check className="w-3 h-3 mr-1 text-emerald-500"/> : <Copy className="w-3 h-3 mr-1"/>}
                    Copy
                </button>
            </div>
            <div className="overflow-x-auto rounded-lg border border-slate-100">
                <table className="w-full text-sm text-left">
                    <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
                        <tr>
                            <th className="px-4 py-2">Window Ht</th>
                            <th className="px-4 py-2">Fe Circle</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        <tr className="hover:bg-slate-50">
                            <td className="px-4 py-2 font-mono text-slate-800 font-bold text-xs">{windowHt}</td>
                            <td className="px-4 py-2 font-mono text-slate-800 font-bold text-xs">{feCircle}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      <div className="flex items-center justify-between mb-4">
        <button onClick={onBack} className="flex items-center text-slate-600 hover:text-slate-900 transition-colors bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm hover:shadow-md">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Main
        </button>
        
        <div className="flex items-center space-x-3">
             <button 
                onClick={() => setShowFormulas(!showFormulas)}
                className={`flex items-center px-3 py-2 rounded-lg text-xs font-bold transition-all border ${showFormulas ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-600 border-slate-300 hover:border-indigo-400'}`}
             >
                 <Calculator className="w-3 h-3 mr-2" />
                 {showFormulas ? 'Simulation Mode: ON' : 'Simulate Formulas'}
             </button>
             <h2 className="text-xl font-bold text-slate-800 hidden md:block">FLD 12</h2>
        </div>
      </div>

      {/* Winding Details Table - Collapsible */}
      {mainData && wdg1Calc && wdg2Calc && wdg3Calc && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6 transition-all duration-300">
            <div 
                className="px-4 py-3 bg-slate-50 border-b border-slate-100 flex justify-between items-center cursor-pointer hover:bg-slate-100 transition-colors"
                onClick={() => setIsWindingDetailsExpanded(!isWindingDetailsExpanded)}
            >
                <div className="flex items-center">
                    <Box className="w-5 h-5 mr-2 text-indigo-500" />
                    <h3 className="text-lg font-semibold text-slate-700">Winding Details</h3>
                    <span className="ml-2 text-[10px] text-slate-400 font-normal">
                        {isWindingDetailsExpanded ? '(Click to collapse)' : '(Click to expand)'}
                    </span>
                </div>
                {isWindingDetailsExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
            </div>

            {isWindingDetailsExpanded && (
                <div className="p-6 animate-fadeIn">
                    <div className="overflow-x-auto rounded-lg border border-slate-100">
                        <table className="w-full text-sm text-left">
                            <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
                                <tr>
                                    <th className="px-4 py-3">Parameter</th>
                                    <th className="px-4 py-3 text-blue-700">
                                        <div className="flex items-center space-x-2">
                                            <span>{windingNames[0]}</span>
                                            <button 
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleCopyWindingDetails(0);
                                                }}
                                                className="text-slate-400 hover:text-blue-600 transition-colors p-1 rounded hover:bg-slate-200" 
                                                title="Copy Column"
                                            >
                                                {copySuccess === 'wdg-details-0' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                                            </button>
                                        </div>
                                    </th>
                                    <th className="px-4 py-3 text-orange-700">
                                        <div className="flex items-center space-x-2">
                                            <span>{windingNames[1]}</span>
                                            <button 
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleCopyWindingDetails(1);
                                                }}
                                                className="text-slate-400 hover:text-orange-600 transition-colors p-1 rounded hover:bg-slate-200" 
                                                title="Copy Column"
                                            >
                                                {copySuccess === 'wdg-details-1' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                                            </button>
                                        </div>
                                    </th>
                                    {windingCount === 3 && <th className="px-4 py-3 text-purple-700">
                                        <div className="flex items-center space-x-2">
                                            <span>{windingNames[2]}</span>
                                            <button 
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleCopyWindingDetails(2);
                                                }}
                                                className="text-slate-400 hover:text-purple-600 transition-colors p-1 rounded hover:bg-slate-200" 
                                                title="Copy Column"
                                            >
                                                {copySuccess === 'wdg-details-2' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                                            </button>
                                        </div>
                                    </th>}
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                <tr className="hover:bg-slate-50">
                                    <td className="px-4 py-3 font-medium text-slate-600">Strands</td>
                                    <td className="px-4 py-3 font-mono font-bold">{wdg1Calc.calcStrands}</td>
                                    <td className="px-4 py-3 font-mono font-bold">{wdg2Calc.calcStrands}</td>
                                    {windingCount === 3 && <td className="px-4 py-3 font-mono font-bold">{wdg3Calc.calcStrands}</td>}
                                </tr>
                                <tr className="hover:bg-slate-50 bg-slate-50/50">
                                    <td className="px-4 py-3 font-medium text-slate-600">Total</td>
                                    <td className="px-4 py-3 font-mono font-bold">{wdg1Calc.calcTotal}</td>
                                    <td className="px-4 py-3 font-mono font-bold">{wdg2Calc.calcTotal}</td>
                                    {windingCount === 3 && <td className="px-4 py-3 font-mono font-bold">{wdg3Calc.calcTotal}</td>}
                                </tr>
                                <tr className="hover:bg-slate-50">
                                    <td className="px-4 py-3 font-medium text-slate-600">Thk</td>
                                    <td className="px-4 py-3 font-mono">{wdg1Calc.thk}</td>
                                    <td className="px-4 py-3 font-mono">{wdg2Calc.thk}</td>
                                    {windingCount === 3 && <td className="px-4 py-3 font-mono">{wdg3Calc.thk}</td>}
                                </tr>
                                <tr className="hover:bg-slate-50">
                                    <td className="px-4 py-3 font-medium text-slate-600">Width</td>
                                    <td className="px-4 py-3 font-mono">{wdg1Calc.width}</td>
                                    <td className="px-4 py-3 font-mono">{wdg2Calc.width}</td>
                                    {windingCount === 3 && <td className="px-4 py-3 font-mono">{wdg3Calc.width}</td>}
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
          </div>
      )}

      {/* NEW: Arrangement Table - Collapsible */}
      {renderArrangementTable()}

      {/* NEW: Core Specs Table */}
      {renderCoreSpecsTable()}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 flex flex-col h-full">
           <div className="flex justify-between items-center mb-4">
               <h3 className="text-sm font-bold text-slate-500 uppercase">Excel Input</h3>
               <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-1 rounded border border-slate-200">Paste raw sheet data</span>
           </div>
           {/* Reduced height to h-32 */}
           <textarea
             className="w-full h-64 p-4 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 resize-none"
             placeholder="Paste Excel columns here..."
             value={pageState.inputText}
             onChange={handleTextChange}
           />
           <div className="mt-3 text-[10px] text-slate-400 space-y-1">
             <p>• Data is processed from bottom to top (Bottom = Index 1).</p>
             <p>• <strong>Rows 1 & 2:</strong> Generated from Column 1/2 Stagger. Click to <strong>Delete/Upshift</strong>.</p>
             <p>• <strong>Rows 3 & 4:</strong> Generated from Column 3/4. Click to <strong>Exclude Single Cell</strong>.</p>
             <p>• <strong>Rows 5-8:</strong> Auto-populated with Winding Details (Strands, Total, Thk, Width).</p>
           </div>
        </div>

        {/* Output Section */}
        <div className="space-y-6">
            {/* Processed Tables */}
            {(table1 || table2) && (
                <div className="space-y-4 animate-slideIn pb-8">
                    <div className="flex items-center space-x-2 pb-2 border-b border-slate-200">
                         <h3 className="text-sm font-bold text-slate-700">Processed Staggered Tables</h3>
                    </div>
                    
                    {renderProcessedTable(table1, "Column 1 Processed", "t1", ref1, details1, true)}
                    {renderProcessedTable(table2, "Column 2 Processed", "t2", ref2, details2, false)}
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default Page5;

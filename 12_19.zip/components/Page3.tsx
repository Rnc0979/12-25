import React, { useState, useEffect } from 'react';
import { ArrowLeft, Copy, Check, Table, FileText, Settings, Zap, Terminal, X, RefreshCcw, Layers, Thermometer, Box, TrendingUp, ChevronDown, ChevronUp } from 'lucide-react';
import { ExtractedData, WindingStats } from '../types';
import { 
  getI2RComponents, 
  calculateTotalStrayEddy, 
  calculateGrandTotalLoss, 
  calculateLossFactor, 
  calculateStrayI2RFactor, 
  calculateWindingDetails
} from '../utils/calculations';

interface Page3Props {
  data: ExtractedData | null;
  onBack: () => void;
  windingCount: number;
}

const Page3: React.FC<Page3Props> = ({ data, onBack, windingCount }) => {
  const [showDebug, setShowDebug] = useState(false); // Debug State
  const [copySuccess, setCopySuccess] = useState<string | null>(null);
  const [bracketBaseValue, setBracketBaseValue] = useState<12 | 15 | 18>(15);
  // NEW STATE FOR TABLE SWITCHING
  const [activeStrayTable, setActiveStrayTable] = useState<'bolted' | 'inputs'>('bolted');
  const [activeBottomTable, setActiveBottomTable] = useState<'short-circuit' | 'core-temp' | 'gradient'>('short-circuit');
  
  // Collapsible state
  const [isStrayLossExpanded, setIsStrayLossExpanded] = useState(false);

  // Loss Factor State - Initialize from LocalStorage if available
  const [nllFactor, setNllFactor] = useState<number>(() => {
      const saved = localStorage.getItem('nllFactor');
      return saved ? parseFloat(saved) : 1.0;
  });
  const [loadLossFactor, setLoadLossFactor] = useState<number>(() => {
      const saved = localStorage.getItem('loadLossFactor');
      return saved ? parseFloat(saved) : 1.0;
  });

  // State for toggling I2R components
  const [excludedI2RIds, setExcludedI2RIds] = useState<string[]>(() => {
      const saved = localStorage.getItem('excludedI2RIds');
      try {
          return saved ? JSON.parse(saved) : [];
      } catch (e) {
          return [];
      }
  });

  // State for Short Circuit Voltage Winding Selection (Default to Inner/Winding 1)
  // windingCount - 2 usually targets the inner winding in a 2-winding setup (0 index)
  const [scVoltageWindingIndex, setScVoltageWindingIndex] = useState(Math.max(0, windingCount - 2));

  // Save to LocalStorage whenever they change
  useEffect(() => {
      localStorage.setItem('nllFactor', nllFactor.toString());
  }, [nllFactor]);

  useEffect(() => {
      localStorage.setItem('loadLossFactor', loadLossFactor.toString());
  }, [loadLossFactor]);

  useEffect(() => {
      localStorage.setItem('excludedI2RIds', JSON.stringify(excludedI2RIds));
  }, [excludedI2RIds]);

  if (!data) return <div className="p-8 text-center text-slate-400">No data available. Go back and upload a PDF.</div>;

  // Determine HV and LV windings
  const hvKey = `wdg${windingCount}` as 'wdg1' | 'wdg2' | 'wdg3';
  const lvKey = `wdg${windingCount - 1}` as 'wdg1' | 'wdg2';
  
  const hv = data[hvKey];
  const lv = data[lvKey];

  // Logic to sum "Major Details" thickness
  const calculateMajorTotal = () => {
      const coverIndex = data.tubeTables.findIndex(t => t.title.toLowerCase().includes("cover details"));
      if (coverIndex > 0) {
          const targetTable = data.tubeTables[coverIndex - 1];
          const total = targetTable.rows.reduce((sum, r) => sum + (parseFloat(r.thk) || 0), 0);
          return total > 0 ? total.toFixed(4) : null;
      }
      const majorTables = data.tubeTables.filter(t => t.title.toLowerCase().includes("major"));
      if (majorTables.length > 0) {
           let total = 0;
           majorTables.forEach(table => {
                table.rows.forEach(r => {
                    total += parseFloat(r.thk) || 0;
                });
           });
           return total > 0 ? total.toFixed(4) : null;
      }
      return null;
  };

  const majorTotal = calculateMajorTotal();

  // Winding Height Calculation
  const calculateRoundedWindingHeight = () => {
      const val = parseFloat(String(hv.wireSpaceMech));
      if (isNaN(val) || val === 0) return '-';
      const rounded = Math.ceil(val / 0.125) * 0.125;
      return rounded.toFixed(3);
  };

  // Calculations for Bolted Yoke Table
  const lvTotalAmpTurns = (lv.ratedTurns && lv.ratedAmps) ? (lv.ratedTurns * parseFloat(String(lv.ratedAmps))).toFixed(2) : '-';
  
  const calculateBracketClearance = (isTop: boolean) => {
      if (!data.core.lamWidth) return '-';
      const maxLam = parseFloat(data.core.lamWidth);
      if (isNaN(maxLam)) return '-';
      
      const bracketVal = isTop ? data.brackets.top : data.brackets.bottom;
      if (bracketVal === null) return '-';
      
      const keepBack = data.keepBack || 0;
      
      const clearance = (Math.abs(bracketBaseValue - maxLam) / 2) + bracketVal + keepBack;
      return clearance.toFixed(4);
  };

  // --- LOSS CALCULATIONS ---
  const extractedNll = data.nllExp ? parseFloat(data.nllExp) : 0;
  const updatedNll = extractedNll * nllFactor;

  // I2R Component Logic
  const i2rComponents = getI2RComponents(data, windingCount);
  
  const toggleI2RComponent = (id: string) => {
      setExcludedI2RIds(prev => {
          if (prev.includes(id)) return prev.filter(item => item !== id);
          return [...prev, id];
      });
  };

  const handleResetI2R = () => setExcludedI2RIds([]);

  const activeI2RComponents = i2rComponents.filter(c => !excludedI2RIds.includes(c.id));
  const totalI2R = activeI2RComponents.reduce((acc, c) => acc + c.value, 0);
  const updatedLoadLoss = totalI2R * loadLossFactor;

  const strayInputs = [
      { label: "Base MVA", value: data.mva },
      { label: "Frequency", value: "60" },
      { label: "No of Phases", value: "3" },
      { label: "LV Turns", value: lv.ratedTurns },
      { label: "HV Turns", value: hv.ratedTurns },
      { label: "LV Amps (Coil)", value: lv.ratedAmps || '-' },
      { label: "HV Amps (Nominal)", value: hv.ratedAmps || '-' },
      { label: "Window Height", value: data.core.windowHt },
      { label: "Winding Height", value: calculateRoundedWindingHeight() }, 
      { label: "LV ID", value: lv.id },
      { label: "HV ID", value: hv.id },
      { label: "LV MT", value: lv.meanTurn },
      { label: "HV MT", value: hv.meanTurn },
      { label: "Major", value: majorTotal || '-' },
      { label: "LV Radial", value: lv.radial },
      { label: "HV Radial", value: hv.radial },
      { label: "Tank Front Clearance", value: data.tank.clearanceFront || '-' },
      { label: "Tank Back Clearance", value: data.tank.clearanceBack || '-' },
      { label: "Tank Left Clearance", value: data.tank.clearanceLeft || '-' },
      { label: "Tank Right Clearance", value: data.tank.clearanceRight || '-' },
      { label: "Tank Width", value: data.tank.width || '-' },
      { label: "Tank Depth", value: data.tank.depth || '-' },
      { label: "Tank Height", value: data.tank.height || '-' },
  ];

  const boltedYokeInputs = [
      { label: "Base MVA", value: data.mva },
      { label: "LV total amp tuen", value: lvTotalAmpTurns },
      { label: "LV coil amps", value: lv.ratedAmps || '-' }, 
      { label: "Window Height", value: data.core.windowHt },
      { label: "Winding Height", value: calculateRoundedWindingHeight() },
      { label: "LV MT", value: lv.meanTurn },
      { label: "HV MT", value: hv.meanTurn },
      { label: "LV Radial", value: lv.radial },
      { label: "HV Radial", value: hv.radial },
      { label: "Major", value: majorTotal || '-' },
      { label: "%Z", value: data.impedance.percentZ || '-' },
      { label: "Bracket height (MC channel)", value: bracketBaseValue, isControl: true },
      { label: "Bracket to winding clearance @ Top", value: calculateBracketClearance(true) },
      { label: "Bracket to winding clearance @ Bottom", value: calculateBracketClearance(false) },
      { label: "Tank Front Clearance", value: data.tank.clearanceFront || '-' },
      { label: "Tank Back Clearance", value: data.tank.clearanceBack || '-' },
      { label: "Tank Left Clearance", value: data.tank.clearanceLeft || '-' },
      { label: "Tank Right Clearance", value: data.tank.clearanceRight || '-' },
      { label: "Tank Width", value: data.tank.width || '-' },
      { label: "Tank Depth", value: data.tank.depth || '-' },
      { label: "Tank Height", value: data.tank.height || '-' },
  ];

  const handleCopyStrayInputs = () => {
      const values = strayInputs.map(item => item.value !== null && item.value !== undefined ? item.value : '-');
      const text = values.join('\n');
      navigator.clipboard.writeText(text).then(() => {
          setCopySuccess('stray');
          setTimeout(() => setCopySuccess(null), 2000);
      });
  };

  const handleCopyBoltedYokeInputs = () => {
      const values = boltedYokeInputs.map(item => item.value !== null && item.value !== undefined ? item.value : '-');
      const text = values.join('\n');
      navigator.clipboard.writeText(text).then(() => {
          setCopySuccess('bolted');
          setTimeout(() => setCopySuccess(null), 2000);
      });
  };

  // --- Winding Wise Details Table Logic ---
  const w1Calc = data ? calculateWindingDetails(data.wdg1) : null;
  const w2Calc = data ? calculateWindingDetails(data.wdg2) : null;
  const w3Calc = data ? calculateWindingDetails(data.wdg3) : null;

  const getWindingVal = (wKey: 'wdg1' | 'wdg2' | 'wdg3', field: keyof WindingStats) => {
      const val = data?.[wKey]?.[field];
      return val !== null && val !== undefined ? val : '-';
  };

  const getCalcVal = (wIdx: number, field: 'calcStrands' | 'calcTotal' | 'thk' | 'width') => {
      const target = wIdx === 0 ? w1Calc : wIdx === 1 ? w2Calc : w3Calc;
      return target ? target[field] : '-';
  };

  const windingDetailRows = [
      { label: 'Z ht', getValue: (_k: any, _i: number) => '' },
      { label: 'Radial build', getValue: (k: any, _i: number) => getWindingVal(k, 'radial') },
      { label: 'Mean turn', getValue: (k: any, _i: number) => getWindingVal(k, 'meanTurn') },
      { label: 'KS/Circle (±2)', getValue: (k: any, _i: number) => getWindingVal(k, 'ksCircle') },
      { label: 'KS Width', getValue: (k: any, _i: number) => getWindingVal(k, 'ksWidth') },
      { label: 'T turn', getValue: (_k: any, _i: number) => '' },
      { label: 'Strands', getValue: (_k: any, idx: number) => getCalcVal(idx, 'calcStrands') },
      { label: 'Total', getValue: (_k: any, idx: number) => getCalcVal(idx, 'calcTotal') },
      { label: 'Thk', getValue: (_k: any, idx: number) => getCalcVal(idx, 'thk') },
      { label: 'Width', getValue: (_k: any, idx: number) => getCalcVal(idx, 'width') },
  ];

  const handleCopyWindingDetails = () => {
      const lines = windingDetailRows.map(row => {
          const vals = [];
          for (let i = 0; i < windingCount; i++) {
              const key = `wdg${i + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
              vals.push(row.getValue(key, i));
          }
          return vals.join('\t');
      });
      navigator.clipboard.writeText(lines.join('\n')).then(() => {
          setCopySuccess('winding-details');
          setTimeout(() => setCopySuccess(null), 2000);
      });
  };

  const handleCopySingleWindingDetails = (idx: number) => {
      const key = `wdg${idx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
      const lines = windingDetailRows.map(row => {
          return row.getValue(key, idx);
      });
      navigator.clipboard.writeText(lines.join('\n')).then(() => {
          setCopySuccess(`wdg-details-${idx}`);
          setTimeout(() => setCopySuccess(null), 2000);
      });
  };

  // --- SHORT CIRCUIT TABLE LOGIC ---
  const getShortCircuitValues = () => {
      // Winding for Voltage selection
      const scWindingKey = `wdg${scVoltageWindingIndex + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
      const scWinding = data?.[scWindingKey];
      
      let voltageValue = '';
      // Prefer extracted Line Voltage
      if (scWinding?.lineVoltage) {
          voltageValue = String(scWinding.lineVoltage);
      } else if (scWinding?.ratedTurns && data?.voltsPerTurn) {
          // Fallback to calculation if Line Voltage not found
          const turns = parseFloat(String(scWinding.ratedTurns));
          const vt = parseFloat(data.voltsPerTurn);
          if (!isNaN(turns) && !isNaN(vt)) {
              voltageValue = (turns * vt).toFixed(2);
          }
      }

      const loadLossKw = updatedLoadLoss > 0 ? (updatedLoadLoss / 1000).toFixed(4) : '-';

      return [
          { label: 'F', value: '60' },
          { label: 'Base MVA', value: data?.mva || '-' },
          { 
              label: 'Inner Winding Voltage', 
              value: voltageValue || '-', 
              isSelector: true,
              options: Array.from({length: windingCount}).map((_, i) => ({
                  value: i,
                  label: `Winding ${i+1}`
              }))
          },
          { label: 'Connection', value: '' }, // Blank as requested
          { label: '%Z', value: data?.impedance.percentZ || '-' },
          { label: 'Load Loss', value: loadLossKw },
          { label: 'Phase Amps', value: lv.ratedAmps || '-' },
          { label: 'Voltage pu', value: '1' },
      ];
  };

  // --- CORE TEMP TABLE LOGIC ---
  const getCoreTempValues = () => {
      // Updated to divide by 1000 for kW
      const loadLossVal = updatedLoadLoss > 0 ? (updatedLoadLoss / 1000).toFixed(3) : '-';
      const maxMva = parseFloat(data?.maxMva || '0');
      const baseMva = parseFloat(data?.mva || '0');
      const ratio = (maxMva && baseMva) ? (maxMva / baseMva).toFixed(2) : '-';
      const nllVal = updatedNll > 0 ? (updatedNll / 1000).toFixed(3) : '-';

      return [
        { label: "Base MVA", value: data?.mva || '-' },
        { label: "%Z", value: data?.impedance.percentZ || '-' },
        { label: "NLL (Exp)", value: nllVal },
        { label: "Load Loss", value: loadLossVal },
        { label: "Core Selection", value: "" }, // Blank
        { label: "Flux Density", value: data?.core.fluxDen || '-' },
        { label: "Core Weight", value: data?.core.weight || '-' },
        { label: "Core Grad", value: data?.core.coreGrad || '-' },
        { label: "Power Factor", value: "0.8" },
        { label: "Voltage pu", value: "1.05" },
        { label: "Ratio", value: ratio }
      ];
  };

  // --- CORE TEMP EXTRA TABLE LOGIC ---
  const getCoreTempExtraValues = () => {
      return [
        { label: "Core Dia", value: data?.core.feCircle || '-' },
        { label: "Core Ht", value: data?.core.coreHt || '-' },
        { label: "1", value: "" },
        { label: "2", value: "" },
        { label: "Core Length", value: data?.core.coreLength || '-' },
        { label: "Window Width", value: data?.core.windowWidth || '-' },
      ];
  };

  // --- GRADIENT TABLE LOGIC ---
  const getGradientRows = () => {
      const rows = [
          { label: 'Watts/in² (OA)', key: 'wattsOA' },
          { label: 'Watts/in² (Max)', key: 'wattsMax' },
          { label: 'radial of wdg', key: 'radial' },
          { label: 'ks thickness', value: '0.0984' },
          { label: 'between disc', value: '2' },
          { 
            label: 'Conductor Insulation', 
            transform: (val: any) => {
                 const v = parseFloat(val);
                 return !isNaN(v) ? (v * 1000).toFixed(2) : '-';
            },
            key: 'paperInsul' 
          },
          { label: '', value: '' },
          { label: '', value: '' },
          { label: 'Disc', key: 'discVal' },
          { label: 'Vertical Duct Thk -Inner', value: '0.250' },
          { label: 'Conductor Width', key: 'bareWidth' },
          { 
              label: 'Radial Strands/Disc', 
              calcKey: 'calcStrands'
          },
          { label: 'gradient =S_Grad (OA)', key: 'sGradOA' },
          { label: 'gradient =S_Grad (Max)', key: 'sGradMax' },
      ];
      return rows;
  };

  const handleCopyShortCircuit = () => {
      const values = getShortCircuitValues().map(item => {
          if (item.value === '') return ''; 
          return item.value;
      });
      const text = values.join('\n');
      navigator.clipboard.writeText(text).then(() => {
          setCopySuccess('short-circuit');
          setTimeout(() => setCopySuccess(null), 2000);
      });
  };

  const handleCopyCoreTemp = () => {
      const values = getCoreTempValues().map(item => item.value);
      const text = values.join('\n');
      navigator.clipboard.writeText(text).then(() => {
          setCopySuccess('core-temp');
          setTimeout(() => setCopySuccess(null), 2000);
      });
  };

  const handleCopyCoreTempExtra = () => {
      const values = getCoreTempExtraValues().map(item => item.value);
      const text = values.join('\n');
      navigator.clipboard.writeText(text).then(() => {
          setCopySuccess('core-temp-extra');
          setTimeout(() => setCopySuccess(null), 2000);
      });
  };

  const handleCopyGradient = () => {
      const rows = getGradientRows();
      const lines = rows.map(row => {
          const vals = [];
          for (let i = 0; i < windingCount; i++) {
              if (row.value !== undefined) {
                   vals.push(row.value);
              } else {
                   const key = `wdg${i + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
                   // @ts-ignore
                   if (row.calcKey) {
                       // @ts-ignore
                       vals.push(getCalcVal(i, row.calcKey));
                   } else {
                       // @ts-ignore
                       let val = getWindingVal(key, row.key);
                       // @ts-ignore
                       if (row.transform) val = row.transform(val);
                       vals.push(val);
                   }
              }
          }
          return vals.join('\t');
      });
      navigator.clipboard.writeText(lines.join('\n')).then(() => {
          setCopySuccess('gradient');
          setTimeout(() => setCopySuccess(null), 2000);
      });
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      <div className="flex items-center justify-between mb-4">
        <button 
          onClick={onBack}
          className="flex items-center text-slate-600 hover:text-slate-900 transition-colors bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm hover:shadow-md"
        >
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Main
        </button>
        
        <div className="flex items-center space-x-3">
             <button onClick={() => setShowDebug(!showDebug)} className={`flex items-center px-3 py-2 rounded-lg text-xs font-mono transition-colors border ${showDebug ? 'bg-slate-800 text-white border-slate-800' : 'bg-white text-slate-500 border-slate-200 hover:border-slate-400'}`}>
                <Terminal className="w-3 h-3 mr-2" />
                {showDebug ? 'Hide Debug' : 'Show Debug Log'}
             </button>
             <h2 className="text-xl font-bold text-slate-800 hidden md:block">LLS Inputs</h2>
        </div>
      </div>

      {showDebug && data.debugLog && (
          <div className="bg-slate-900 rounded-xl shadow-lg border border-slate-800 overflow-hidden text-left relative mb-6">
              <div className="flex justify-between items-center px-4 py-2 bg-slate-950 border-b border-slate-800">
                  <span className="text-xs font-mono text-slate-400">Extraction Log</span>
                  <button onClick={() => setShowDebug(false)} className="text-slate-500 hover:text-white"><X className="w-4 h-4" /></button>
              </div>
              <div className="p-4 overflow-x-auto max-h-64 overflow-y-auto">
                  <pre className="text-[10px] font-mono text-emerald-400 whitespace-pre-wrap leading-relaxed">{data.debugLog.join('\n')}</pre>
              </div>
          </div>
      )}

      {/* MVA Helper Table */}
      {(data.mva || data.maxMva) && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
            <div className="px-4 py-3 bg-indigo-50 border-b border-indigo-100 flex items-center">
                <FileText className="w-4 h-4 mr-2 text-indigo-600" />
                <h3 className="font-bold text-xs uppercase tracking-wider text-indigo-800">MVA Ratings</h3>
            </div>
            <div className="p-4 flex space-x-12">
                <div>
                    <span className="block text-xs text-slate-400 uppercase font-bold mb-1">Base MVA</span>
                    <span className="text-xl font-mono font-bold text-slate-800">{data.mva || '-'}</span>
                </div>
                <div>
                    <span className="block text-xs text-slate-400 uppercase font-bold mb-1">Max MVA</span>
                    <span className="text-xl font-mono font-bold text-slate-800">{data.maxMva || '-'}</span>
                </div>
            </div>
        </div>
      )}

      {/* NEW: Losses Overview & Adjustments */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
         <div className="px-4 py-3 bg-amber-50 border-b border-amber-100 flex items-center">
             <Zap className="w-4 h-4 mr-2 text-amber-600" />
             <h3 className="font-bold text-xs uppercase tracking-wider text-amber-800">Losses Overview & Adjustments</h3>
         </div>
         <div className="p-4 grid grid-cols-1 lg:grid-cols-3 gap-4">
             {/* 1. Extracted Losses Summary (Moved from Page 1) */}
             <div className="bg-slate-50 rounded-lg border border-slate-200 overflow-hidden h-full">
                 <table className="w-full text-xs text-left h-full">
                     <tbody className="divide-y divide-slate-100">
                         <tr>
                             <td className="px-3 py-2 text-slate-500 font-medium">Stray/Eddy</td>
                             <td className="px-3 py-2 font-mono font-bold text-slate-700 text-right">{calculateTotalStrayEddy(data, windingCount)}</td>
                         </tr>
                         <tr>
                             <td className="px-3 py-2 text-slate-500 font-medium">Total Loss</td>
                             <td className="px-3 py-2 font-mono font-bold text-indigo-700 text-right">{calculateGrandTotalLoss(data, windingCount)}</td>
                         </tr>
                         <tr>
                             <td className="px-3 py-2 text-slate-500 font-medium">Factor</td>
                             <td className="px-3 py-2 font-mono font-bold text-indigo-700 text-right">{calculateLossFactor(data, windingCount)}</td>
                         </tr>
                         <tr>
                             <td className="px-3 py-2 text-slate-500 font-medium">Ratio (S/I2R)</td>
                             <td className="px-3 py-2 font-mono font-bold text-emerald-700 text-right">{calculateStrayI2RFactor(data, windingCount)}</td>
                         </tr>
                     </tbody>
                 </table>
             </div>

             {/* 2. NLL Row */}
             <div className="flex flex-col justify-between bg-slate-50 p-3 rounded-lg border border-slate-100 h-full">
                 <div className="flex items-center justify-between">
                     <div className="flex flex-col">
                        <span className="text-xs font-bold text-slate-500 uppercase">NLL (Exp)</span>
                        <span className="text-lg font-mono font-bold text-slate-800">{extractedNll || '-'}</span>
                     </div>
                     <div className="flex items-center space-x-1">
                        <span className="text-[10px] text-slate-400 font-bold uppercase">Factor</span>
                        <input 
                            type="number" step="0.01"
                            value={nllFactor}
                            onChange={(e) => setNllFactor(parseFloat(e.target.value) || 0)}
                            className="w-16 px-1 py-1 text-sm border border-slate-300 bg-white rounded focus:border-amber-500 focus:outline-none text-center font-mono"
                        />
                     </div>
                 </div>
                 <div className="flex justify-between items-end mt-2 pt-2 border-t border-slate-200/50">
                     <span className="text-xs font-bold text-emerald-600 uppercase">Updated</span>
                     <span className="text-xl font-mono font-bold text-emerald-700">{updatedNll.toFixed(0)}</span>
                 </div>
             </div>

             {/* 3. Load Loss Row */}
             <div className="flex flex-col bg-slate-50 p-3 rounded-lg border border-slate-100 h-full">
                 <div className="flex items-center justify-between mb-2">
                    <div className="flex flex-col">
                        <span className="text-xs font-bold text-slate-500 uppercase">Load Loss</span>
                        <div className="flex items-baseline space-x-2">
                             <span className="text-lg font-mono font-bold text-slate-800">{totalI2R.toFixed(0)}</span>
                             {excludedI2RIds.length > 0 && (
                                 <button onClick={handleResetI2R} className="text-[10px] text-rose-500 hover:text-rose-700 flex items-center">
                                     <RefreshCcw className="w-3 h-3 mr-1" />
                                 </button>
                             )}
                        </div>
                    </div>
                    <div className="flex items-center space-x-1">
                        <span className="text-[10px] text-slate-400 font-bold uppercase">Factor</span>
                        <input 
                            type="number" step="0.01"
                            value={loadLossFactor}
                            onChange={(e) => setLoadLossFactor(parseFloat(e.target.value) || 0)}
                            className="w-16 px-1 py-1 text-sm border border-slate-300 bg-white rounded focus:border-amber-500 focus:outline-none text-center font-mono"
                        />
                    </div>
                 </div>
                 
                 <div className="flex justify-between items-end mb-2">
                    <span className="text-xs font-bold text-emerald-600 uppercase">Updated</span>
                    <span className="text-xl font-mono font-bold text-emerald-700">{updatedLoadLoss.toFixed(0)}</span>
                 </div>

                 {/* I2R Component Toggles */}
                 <div className="flex flex-wrap gap-1.5 mt-auto pt-2 border-t border-slate-200/60">
                     {i2rComponents.map((comp) => {
                         const isActive = !excludedI2RIds.includes(comp.id);
                         return (
                             <button
                                key={comp.id}
                                onClick={() => toggleI2RComponent(comp.id)}
                                className={`flex items-center px-1.5 py-0.5 rounded text-[9px] font-mono border transition-all ${
                                    isActive 
                                    ? 'bg-white border-slate-300 text-slate-700 hover:border-slate-400 shadow-sm' 
                                    : 'bg-slate-100 border-slate-200 text-slate-400 line-through decoration-slate-400'
                                }`}
                                title={isActive ? "Click to exclude" : "Click to include"}
                             >
                                <span className={`mr-1 font-bold ${isActive ? 'text-indigo-500' : 'text-slate-400'}`}>{comp.label}</span>
                                <span>{comp.value}</span>
                             </button>
                         );
                     })}
                 </div>
             </div>
         </div>
      </div>

      {/* COMBINED STRAY LOSS TABLES - COLLAPSIBLE */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6 transition-all duration-300">
        <div 
            className="px-4 py-3 bg-slate-50 border-b border-slate-100 flex justify-between items-center cursor-pointer hover:bg-slate-100 transition-colors"
            onClick={() => setIsStrayLossExpanded(!isStrayLossExpanded)}
        >
            <div className="flex items-center space-x-2">
                <Settings className="w-4 h-4 text-slate-600" />
                <div className="relative" onClick={(e) => e.stopPropagation()}>
                    <select
                        value={activeStrayTable}
                        onChange={(e) => setActiveStrayTable(e.target.value as 'bolted' | 'inputs')}
                        className="appearance-none bg-white border border-slate-300 hover:border-indigo-400 text-slate-700 text-xs font-bold uppercase py-1.5 pl-3 pr-8 rounded focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer shadow-sm transition-all"
                    >
                        <option value="bolted">Stray Loss for Bolted Yoke</option>
                        <option value="inputs">Stray Loss Inputs</option>
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-500">
                        <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                    </div>
                </div>
            </div>
            
            <div className="flex items-center space-x-3">
                <button 
                    onClick={(e) => {
                        e.stopPropagation();
                        activeStrayTable === 'bolted' ? handleCopyBoltedYokeInputs() : handleCopyStrayInputs();
                    }}
                    className="flex items-center text-xs font-medium text-slate-500 hover:text-indigo-600 transition-colors bg-white border border-slate-200 hover:border-indigo-200 px-3 py-1.5 rounded shadow-sm"
                    title="Copy Table Values"
                >
                    {copySuccess === (activeStrayTable === 'bolted' ? 'bolted' : 'stray') ? (
                        <>
                            <Check className="w-3 h-3 mr-1.5 text-emerald-500" /> Copied!
                        </>
                    ) : (
                        <>
                            <Copy className="w-3 h-3 mr-1.5" /> Copy Values
                        </>
                    )}
                </button>
                {isStrayLossExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
            </div>
        </div>

        {isStrayLossExpanded && (
            <div className="overflow-x-auto animate-fadeIn">
                <table className="w-full text-sm text-left">
                    <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                        <tr>
                            <th className="px-6 py-2 w-1/2">Parameter</th>
                            <th className="px-6 py-2 font-mono">Value</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {(activeStrayTable === 'bolted' ? boltedYokeInputs : strayInputs).map((item, idx) => (
                            <tr key={idx} className="hover:bg-slate-50">
                                <td className="px-6 py-1.5 text-slate-600 font-medium text-xs">{item.label}</td>
                                <td className="px-6 py-1.5 font-mono text-slate-800 font-bold text-xs">
                                    {/* @ts-ignore - Handle special isControl property */}
                                    {item.isControl ? (
                                        <div className="flex items-center space-x-1">
                                            {[12, 15, 18].map((v) => (
                                                <button
                                                    key={v}
                                                    onClick={() => setBracketBaseValue(v as 12 | 15 | 18)}
                                                    className={`px-2 py-0.5 text-[10px] font-bold rounded border transition-colors ${
                                                        bracketBaseValue === v
                                                            ? 'bg-indigo-600 text-white border-indigo-600'
                                                            : 'bg-white text-slate-500 border-slate-200 hover:border-slate-300'
                                                    }`}
                                                >
                                                    {v}
                                                </button>
                                            ))}
                                        </div>
                                    ) : (
                                        item.value !== null && item.value !== undefined ? item.value : '-'
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        )}
      </div>

      {/* Stress on Conductor Input (formerly Winding Wise Details) - Moved Here */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
          <div className="px-4 py-3 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
             <div className="flex items-center">
                 <Layers className="w-4 h-4 mr-2 text-slate-600" />
                 <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800">Stress on Conductor Input</h3>
             </div>
             <button 
                 onClick={handleCopyWindingDetails}
                 className="flex items-center text-xs font-medium text-slate-500 hover:text-indigo-600 transition-colors bg-white border border-slate-200 hover:border-indigo-200 px-3 py-1.5 rounded shadow-sm"
             >
                 {copySuccess === 'winding-details' ? (
                     <>
                         <Check className="w-3 h-3 mr-1.5 text-emerald-500" /> Copied!
                     </>
                 ) : (
                     <>
                         <Copy className="w-3 h-3 mr-1.5" /> Copy Values
                     </>
                 )}
             </button>
          </div>
          <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                  <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                      <tr>
                          <th className="px-4 py-2">Parameter</th>
                          <th className="px-4 py-2 text-blue-700">
                                <div className="flex items-center space-x-2">
                                    <span>Winding 1</span>
                                    <button 
                                        onClick={() => handleCopySingleWindingDetails(0)} 
                                        className="text-slate-400 hover:text-blue-600 transition-colors p-1 rounded hover:bg-slate-200" 
                                        title="Copy Column"
                                    >
                                        {copySuccess === 'wdg-details-0' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                                    </button>
                                </div>
                          </th>
                          <th className="px-4 py-2 text-orange-700">
                                <div className="flex items-center space-x-2">
                                    <span>Winding 2</span>
                                    <button 
                                        onClick={() => handleCopySingleWindingDetails(1)} 
                                        className="text-slate-400 hover:text-orange-600 transition-colors p-1 rounded hover:bg-slate-200" 
                                        title="Copy Column"
                                    >
                                        {copySuccess === 'wdg-details-1' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                                    </button>
                                </div>
                          </th>
                          {windingCount === 3 && <th className="px-4 py-2 text-purple-700">
                                <div className="flex items-center space-x-2">
                                    <span>Winding 3</span>
                                    <button 
                                        onClick={() => handleCopySingleWindingDetails(2)} 
                                        className="text-slate-400 hover:text-purple-600 transition-colors p-1 rounded hover:bg-slate-200" 
                                        title="Copy Column"
                                    >
                                        {copySuccess === 'wdg-details-2' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                                    </button>
                                </div>
                          </th>}
                      </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                      {windingDetailRows.map((row, idx) => (
                          <tr key={idx} className="hover:bg-slate-50">
                              <td className="px-4 py-1.5 text-slate-600 font-medium text-xs">{row.label}</td>
                              <td className="px-4 py-1.5 font-mono text-slate-800 text-xs font-bold">{row.getValue('wdg1', 0)}</td>
                              <td className="px-4 py-1.5 font-mono text-slate-800 text-xs font-bold">{row.getValue('wdg2', 1)}</td>
                              {windingCount === 3 && <td className="px-4 py-1.5 font-mono text-slate-800 text-xs font-bold">{row.getValue('wdg3', 2)}</td>}
                          </tr>
                      ))}
                  </tbody>
              </table>
          </div>
      </div>

      {/* CALCULATED PARAMETERS TABLE (SHORT CIRCUIT / CORE TEMP / GRADIENT) */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-4 py-3 bg-red-50 border-b border-red-100 flex justify-between items-center">
              <div className="flex items-center space-x-2">
                  <div className="flex items-center">
                    {activeBottomTable === 'short-circuit' ? <Zap className="w-4 h-4 mr-2 text-red-600" /> : activeBottomTable === 'core-temp' ? <Thermometer className="w-4 h-4 mr-2 text-red-600" /> : <TrendingUp className="w-4 h-4 mr-2 text-red-600" />}
                  </div>
                  <div className="relative">
                     <select 
                        value={activeBottomTable}
                        onChange={(e) => setActiveBottomTable(e.target.value as any)}
                        className="appearance-none bg-white border border-slate-300 hover:border-red-400 text-red-800 text-xs font-bold uppercase py-1.5 pl-3 pr-8 rounded focus:outline-none focus:ring-1 focus:ring-red-500 cursor-pointer shadow-sm transition-all"
                     >
                         <option value="short-circuit">Short Circuit</option>
                         <option value="core-temp">Core Temp</option>
                         <option value="gradient">Gradient</option>
                     </select>
                     <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-red-500">
                        <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                    </div>
                  </div>
              </div>
              <button 
                  onClick={() => {
                      if (activeBottomTable === 'short-circuit') handleCopyShortCircuit();
                      else if (activeBottomTable === 'core-temp') handleCopyCoreTemp();
                      else if (activeBottomTable === 'gradient') handleCopyGradient(); // Need to implement this
                  }}
                  className="flex items-center text-xs font-medium text-slate-500 hover:text-red-600 transition-colors bg-white border border-slate-200 hover:border-red-200 px-3 py-1.5 rounded shadow-sm"
              >
                  {copySuccess === (activeBottomTable) ? (
                      <>
                          <Check className="w-3 h-3 mr-1.5 text-emerald-500" /> Copied!
                      </>
                  ) : (
                      <>
                          <Copy className="w-3 h-3 mr-1.5" /> Copy Values
                      </>
                  )}
              </button>
          </div>
          <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                  {activeBottomTable === 'gradient' ? (
                      <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                        <tr>
                            <th className="px-6 py-2">Parameter</th>
                            <th className="px-4 py-2 text-blue-700">Winding 1</th>
                            <th className="px-4 py-2 text-orange-700">Winding 2</th>
                            {windingCount === 3 && <th className="px-4 py-2 text-purple-700">Winding 3</th>}
                        </tr>
                      </thead>
                  ) : (
                      <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                        <tr>
                            <th className="px-6 py-2 w-1/2">Parameter</th>
                            <th className="px-6 py-2 font-mono">Value</th>
                        </tr>
                      </thead>
                  )}
                  <tbody className="divide-y divide-slate-100">
                      {activeBottomTable === 'short-circuit' ? (
                        getShortCircuitValues().map((item, idx) => (
                          <tr key={idx} className="hover:bg-slate-50">
                              <td className="px-6 py-1.5 text-slate-600 font-medium text-xs">{item.label}</td>
                              <td className="px-6 py-1.5 font-mono text-slate-800 font-bold text-xs">
                                  {/* @ts-ignore */}
                                  {item.isSelector ? (
                                      <select 
                                          value={scVoltageWindingIndex}
                                          onChange={(e) => setScVoltageWindingIndex(parseInt(e.target.value))}
                                          className="bg-white border border-slate-200 text-xs rounded px-2 py-1 focus:outline-none focus:border-red-400"
                                      >
                                          {/* @ts-ignore */}
                                          {item.options.map((opt) => (
                                              <option key={opt.value} value={opt.value}>{opt.label}</option>
                                          ))}
                                      </select>
                                  ) : (
                                      item.value
                                  )}
                                  {/* @ts-ignore */}
                                  {item.isSelector && (
                                     <span className="ml-2 text-slate-500 font-normal">
                                        = {item.value} V
                                     </span>
                                  )}
                              </td>
                          </tr>
                        ))
                      ) : activeBottomTable === 'core-temp' ? (
                        getCoreTempValues().map((item, idx) => (
                           <tr key={idx} className="hover:bg-slate-50">
                               <td className="px-6 py-1.5 text-slate-600 font-medium text-xs">{item.label}</td>
                               <td className="px-6 py-1.5 font-mono text-slate-800 font-bold text-xs">{item.value}</td>
                           </tr>
                        ))
                      ) : (
                        // GRADIENT TABLE ROWS
                        getGradientRows().map((row, idx) => (
                           <tr key={idx} className="hover:bg-slate-50">
                               <td className="px-6 py-1.5 text-slate-600 font-medium text-xs">{row.label}</td>
                               {[0, 1, 2].slice(0, windingCount).map(wIdx => {
                                   let val: any = '-';
                                   // @ts-ignore
                                   if (row.value !== undefined) {
                                       // Constant or Empty
                                       // @ts-ignore
                                       val = row.value;
                                   } else {
                                       const key = `wdg${wIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
                                       // @ts-ignore
                                       if (row.calcKey) {
                                           // @ts-ignore
                                           val = getCalcVal(wIdx, row.calcKey);
                                       } else {
                                           // @ts-ignore
                                           val = getWindingVal(key, row.key);
                                           // @ts-ignore
                                           if (row.transform) val = row.transform(val);
                                       }
                                   }
                                   
                                   const colorClass = wIdx === 0 ? 'text-blue-800' : wIdx === 1 ? 'text-orange-800' : 'text-purple-800';

                                   return (
                                       <td key={wIdx} className={`px-4 py-1.5 font-mono text-xs font-bold ${colorClass}`}>
                                           {val}
                                       </td>
                                   );
                               })}
                           </tr>
                        ))
                      )}
                  </tbody>
              </table>
          </div>
      </div>

      {/* EXTRA CORE DETAILS TABLE (Visible only when Core Temp is selected) */}
      {activeBottomTable === 'core-temp' && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mt-6">
              <div className="px-4 py-3 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                      <Box className="w-4 h-4 mr-2 text-slate-600" />
                      <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800">Additional Core Details</h3>
                  </div>
                  <button 
                      onClick={handleCopyCoreTempExtra}
                      className="flex items-center text-xs font-medium text-slate-500 hover:text-indigo-600 transition-colors bg-white border border-slate-200 hover:border-indigo-200 px-3 py-1.5 rounded shadow-sm"
                  >
                      {copySuccess === 'core-temp-extra' ? (
                          <>
                              <Check className="w-3 h-3 mr-1.5 text-emerald-500" /> Copied!
                          </>
                      ) : (
                          <>
                              <Copy className="w-3 h-3 mr-1.5" /> Copy Values
                          </>
                      )}
                  </button>
              </div>
              <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                      <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                          <tr>
                              <th className="px-6 py-2 w-1/2">Parameter</th>
                              <th className="px-6 py-2 font-mono">Value</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                          {getCoreTempExtraValues().map((item, idx) => (
                              <tr key={idx} className="hover:bg-slate-50">
                                  <td className="px-6 py-1.5 text-slate-600 font-medium text-xs">{item.label}</td>
                                  <td className="px-6 py-1.5 font-mono text-slate-800 font-bold text-xs">{item.value}</td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
          </div>
      )}

    </div>
  );
};

export default Page3;
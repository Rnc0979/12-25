
import React, { useState } from 'react';
import { ArrowLeft, RotateCcw, Calculator, Settings, FunctionSquare, Link as LinkIcon, RefreshCw, ChevronDown } from 'lucide-react';
import { Page8State, ExtractedData } from '../types';

interface Page8Props {
    data: ExtractedData | null;
    onBack: () => void;
    windingNames: string[];
    windingCount: number;
    pageState: Page8State;
    setPageState: React.Dispatch<React.SetStateAction<Page8State>>;
}

const Page8: React.FC<Page8Props> = ({ data, onBack, windingNames, windingCount, pageState, setPageState }) => {
    
    // State for the OA Max Dropdown
    const [showOaMaxDropdown, setShowOaMaxDropdown] = useState(false);

    const updateState = (field: keyof Page8State, value: number) => {
        setPageState(prev => {
            const newState = { ...prev, [field]: value };
            
            // Logic for LV1: Sync Nom -> Min if Nom changed
            if (field === 'lvLoss1') {
                newState.lvLoss1Min = value;
            }

            // Logic for LV2: Sync Nom -> Min if Nom changed AND Calc is OFF
            if (field === 'lvLoss' && !prev.useLvMinCalc) {
                newState.lvLossMin = value;
            }
            
            // Recalculate LV2 Min if Calc is ON and relevant fields changed
            if ((field === 'lvLoss' || field === 'lvMaxCurrent' || field === 'lvNomCurrent') && prev.useLvMinCalc) {
                if (newState.lvNomCurrent !== 0) {
                    const ratio = newState.lvMaxCurrent / newState.lvNomCurrent;
                    newState.lvLossMin = newState.lvLoss * ratio * ratio;
                }
            }

            // Logic for HV: Sync Nom -> Min if Nom changed (using factor)
            if (field === 'hvLoss' || field === 'user1' || field === 'user2') {
                const factor = 1 / (1 - (newState.user1 * newState.user2 / 100));
                newState.hvLossMin = newState.hvLoss * factor;
            }

            return newState;
        });
    };

    const toggleLvCalc = () => {
        setPageState(prev => {
            const useLvMinCalc = !prev.useLvMinCalc;
            let lvLossMin = prev.lvLossMin;
            
            if (useLvMinCalc) {
                 // Recalculate immediately upon enabling
                 if (prev.lvNomCurrent !== 0) {
                    const ratio = prev.lvMaxCurrent / prev.lvNomCurrent;
                    lvLossMin = prev.lvLoss * ratio * ratio;
                 }
            } else {
                // Reset to match nominal when disabling
                lvLossMin = prev.lvLoss;
            }

            return { ...prev, useLvMinCalc, lvLossMin };
        });
    };

    const resetDefaults = () => {
        setPageState({
            nomMva: 12000,
            oaMax: 20000,
            maxMva: 22400,
            nll: 11356,
            strayPct: 13,
            lvLoss1: 0,
            lvLoss: 17323,
            hvLoss: 24376,
            lvLoss1Min: 0,
            lvLossMin: 17323,
            hvLossMin: 25659,
            addLl: 0,
            addNll: 0,
            user1: 2,
            user2: 2.5,
            useLvMinCalc: false,
            lvMaxCurrent: 0,
            lvNomCurrent: 0
        });
    };

    const handleLinkData = () => {
        if (!data) return;

        // 1. MVA Ratings
        const nomMva = parseFloat(data.mva || '0') * 1000;
        const maxMva = parseFloat(data.maxMva || data.mva || '0') * 1000;
        
        // 2. NLL from LLS (using factor)
        const rawNll = parseFloat(data.nllExp || '0');
        const nllFactorStr = localStorage.getItem('nllFactor');
        const nllFactor = nllFactorStr ? parseFloat(nllFactorStr) : 1.0;
        // Kept in Watts (Removed / 1000)
        const nll = (rawNll * nllFactor);

        // 3. I2R Losses (Winding Wise)
        // Helper to extract first number from I2R string if slash-separated
        const extractI2R = (val: string | number | null): number => {
            if (!val) return 0;
            let numVal = 0;
            if (typeof val === 'number') {
                numVal = val;
            } else {
                const parts = val.split('/');
                // Usually the first value corresponds to Nominal Tap
                numVal = parseFloat(parts[0]) || 0;
            }
            // Kept in Watts (Removed / 1000)
            return numVal;
        };

        // Determine windings
        const outerKey = `wdg${windingCount}` as 'wdg1' | 'wdg2' | 'wdg3';
        const innerKey = `wdg${windingCount - 1}` as 'wdg1' | 'wdg2';
        
        const hvLoss = extractI2R(data[outerKey]?.i2r);
        const lvLoss = extractI2R(data[innerKey]?.i2r);
        
        let lvLoss1 = 0;
        if (windingCount > 2) {
             // If 3 windings, assumin W1 is LV1, W2 is LV2 (Main), W3 is HV
             // This logic depends on the specific transformer config, but standard is Inner->Outer
             const innerMostKey = `wdg${windingCount - 2}` as 'wdg1';
             lvLoss1 = extractI2R(data[innerMostKey]?.i2r);
        }

        // Apply Updates
        setPageState(prev => {
            // Factor for HV Min Calculation from User inputs
            const hvFactor = 1 / (1 - (prev.user1 * prev.user2 / 100));

            return {
                ...prev,
                nomMva: nomMva > 0 ? nomMva : prev.nomMva,
                maxMva: maxMva > 0 ? maxMva : prev.maxMva,
                // Default OA Max to Base if not set, or keep current if valid
                oaMax: nomMva > 0 ? nomMva : prev.oaMax, 
                nll: nll > 0 ? nll : prev.nll,
                hvLoss: hvLoss > 0 ? hvLoss : prev.hvLoss,
                lvLoss: lvLoss > 0 ? lvLoss : prev.lvLoss,
                lvLoss1: lvLoss1 > 0 ? lvLoss1 : prev.lvLoss1,
                
                // Sync Min Taps (Link Equally)
                lvLoss1Min: lvLoss1 > 0 ? lvLoss1 : prev.lvLoss1Min,
                // Only sync LV2 Min if Calc is OFF
                lvLossMin: (!prev.useLvMinCalc && lvLoss > 0) ? lvLoss : prev.lvLossMin,
                // Recalculate HV Min based on new HV Loss
                hvLossMin: hvLoss > 0 ? hvLoss * hvFactor : prev.hvLossMin
            };
        });
    };

    const getAvailableMvaOptions = () => {
        if (!data) return [];
        const options = [];
        if (data.mva) options.push({ label: 'Base Rating', value: parseFloat(data.mva) * 1000 });
        if (data.maxMva && data.maxMva !== data.mva) options.push({ label: 'Max Rating', value: parseFloat(data.maxMva) * 1000 });
        return options;
    };


    // --- CALCULATIONS ---
    const CU_CONST = 234.5;
    
    // Temp Correction Factors
    const factorRes85 = (CU_CONST + 85) / (CU_CONST + 75);
    const factorStray85 = (CU_CONST + 75) / (CU_CONST + 85);

    // --- NOMINAL TAP CALCS ---
    // Include LV1 in total I2R
    const i2r_75_nom = pageState.lvLoss1 + pageState.lvLoss + pageState.hvLoss;
    const i2r_85_nom = i2r_75_nom * factorRes85;
    
    const stray_75_nom = i2r_75_nom * (pageState.strayPct / 100);
    const stray_85_nom = stray_75_nom * factorStray85;

    // Apply Adder to LL Total
    const total_ll_75_nom = i2r_75_nom + stray_75_nom + (pageState.addLl || 0);
    const total_ll_85_nom = i2r_85_nom + stray_85_nom + (pageState.addLl || 0);

    const total_nll = pageState.nll + (pageState.addNll || 0);

    const total_loss_75_nom = total_ll_75_nom + total_nll;
    const total_loss_85_nom = total_ll_85_nom + total_nll;

    // 71% FA2 Scaling (Nominal)
    const target_mva_71 = 0.71 * pageState.oaMax;
    const scale_71 = pageState.nomMva > 0 ? Math.pow(target_mva_71 / pageState.nomMva, 2) : 0;
    
    const ll_71_fa2_nom = total_ll_75_nom * scale_71;
    const total_loss_71_fa2_nom = ll_71_fa2_nom + total_nll;

    // Max Rating Scaling (Nominal)
    const scale_max = pageState.nomMva > 0 ? Math.pow(pageState.maxMva / pageState.nomMva, 2) : 0;
    
    // 85C
    const ll_max_rating_nom = total_ll_85_nom * scale_max;
    const total_max_rating_nom = ll_max_rating_nom + total_nll;

    // 75C
    const ll_max_rating_75_nom = total_ll_75_nom * scale_max;
    const total_max_rating_75_nom = ll_max_rating_75_nom + total_nll;


    // --- MINIMUM TAP CALCS ---
    const i2r_75_min = pageState.lvLoss1Min + pageState.lvLossMin + pageState.hvLossMin;
    const i2r_85_min = i2r_75_min * factorRes85;

    const stray_75_min = i2r_75_min * (pageState.strayPct / 100);
    const stray_85_min = stray_75_min * factorStray85;

    const total_ll_75_min = i2r_75_min + stray_75_min + (pageState.addLl || 0);
    const total_ll_85_min = i2r_85_min + stray_85_min + (pageState.addLl || 0);

    const total_loss_75_min = total_ll_75_min + total_nll;
    const total_loss_85_min = total_ll_85_min + total_nll;

    const ll_71_fa2_min = total_ll_75_min * scale_71;
    const total_loss_71_fa2_min = ll_71_fa2_min + total_nll;

    // Max Rating Scaling (Min Tap)
    // 85C
    const ll_max_rating_min = total_ll_85_min * scale_max;
    const total_max_rating_min = ll_max_rating_min + total_nll;
    
    // 75C
    const ll_max_rating_75_min = total_ll_75_min * scale_max;
    const total_max_rating_75_min = ll_max_rating_75_min + total_nll;


    // --- RENDERING HELPERS ---
    // Round to integer strings
    const format = (num: number) => Math.round(num).toLocaleString();
    
    const renderInput = (field: Exclude<keyof Page8State, 'useLvMinCalc'>) => (
        <input 
            type="number" 
            className="w-full h-full text-right px-2 font-bold text-indigo-700 bg-white focus:outline-none focus:bg-indigo-50"
            value={pageState[field]}
            onChange={(e) => updateState(field, parseFloat(e.target.value) || 0)}
        />
    );

    return (
        <div className="space-y-6 animate-fadeIn pb-12">
            <div className="flex items-center justify-between mb-4">
                <button onClick={onBack} className="flex items-center text-slate-600 hover:text-slate-900 transition-colors bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm">
                    <ArrowLeft className="w-4 h-4 mr-2" /> Back
                </button>
                <div className="flex items-center space-x-3">
                    {data && (
                        <button 
                            onClick={handleLinkData}
                            className="flex items-center px-4 py-2 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-bold hover:bg-emerald-100 transition-colors shadow-sm"
                            title="Populate from Extracted Data"
                        >
                            <LinkIcon className="w-3 h-3 mr-2" /> Link Data
                        </button>
                    )}
                    <div className="bg-white border border-indigo-100 rounded-lg flex items-center px-3 py-1 shadow-sm">
                        <Settings className="w-3 h-3 text-indigo-400 mr-2" />
                        <div className="flex items-center space-x-2 text-xs">
                             <span className="font-bold text-slate-500" title="Number of taps from nominal to min (from nor how many max taps are way)">Taps:</span>
                             <input 
                                type="number" className="w-12 border-b border-indigo-200 focus:border-indigo-500 outline-none text-center font-bold text-indigo-700 bg-white"
                                value={pageState.user1} onChange={e => updateState('user1', parseFloat(e.target.value))}
                             />
                             <span className="font-bold text-slate-500 ml-2">U2:</span>
                             <input 
                                type="number" className="w-12 border-b border-indigo-200 focus:border-indigo-500 outline-none text-center font-bold text-indigo-700 bg-white"
                                value={pageState.user2} onChange={e => updateState('user2', parseFloat(e.target.value))}
                             />
                        </div>
                    </div>
                    <button onClick={resetDefaults} className="flex items-center px-3 py-2 bg-slate-100 text-slate-600 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 rounded-lg text-xs font-bold transition-colors">
                        <RotateCcw className="w-3 h-3 mr-2" /> Reset
                    </button>
                    <div className="bg-indigo-600 text-white px-4 py-2 rounded-lg shadow-sm text-sm font-bold flex items-center">
                        <Calculator className="w-4 h-4 mr-2" />
                        Loss Calculator
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full border-collapse text-sm min-w-[800px]">
                        <thead>
                            <tr className="bg-slate-100 text-slate-500 text-xs uppercase tracking-wider border-b border-slate-200">
                                <th className="w-8 py-2 border-r border-slate-200">#</th>
                                <th className="w-8 py-2 border-r border-slate-200">A</th>
                                <th className="w-64 py-2 border-r border-slate-200">B</th>
                                <th className="w-40 py-2 border-r border-slate-200 bg-slate-200 text-slate-800 font-bold">C (Nominal)</th>
                                <th className="w-32 py-2 border-r border-slate-200">D</th>
                                <th className="w-40 py-2 border-r border-slate-200 bg-slate-200 text-slate-800 font-bold">E (Min Tap)</th>
                                <th className="w-32 py-2 border-r border-slate-200">F</th>
                                <th className="py-2">G</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-mono text-xs">
                            {/* Row 1 */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">1</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Nominal MVA:</td>
                                <td className="border-2 border-indigo-200 bg-white p-0 h-8">{renderInput('nomMva')}</td>
                                <td className="px-3 text-slate-500">Base</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>
                            {/* Row 2 */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">2</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">OA Max:</td>
                                <td className="border-2 border-indigo-200 bg-white p-0 h-8 relative group">
                                    {renderInput('oaMax')}
                                    {data && (
                                        <div className="absolute right-0 top-0 h-full flex items-center pr-1">
                                            <button 
                                                onClick={() => setShowOaMaxDropdown(!showOaMaxDropdown)}
                                                className="p-0.5 rounded hover:bg-indigo-100 text-indigo-400"
                                            >
                                                <ChevronDown className="w-3 h-3" />
                                            </button>
                                            {showOaMaxDropdown && (
                                                <div className="absolute top-full right-0 mt-1 w-32 bg-white border border-slate-200 rounded shadow-lg z-50 text-xs">
                                                    <div className="p-1 font-bold text-slate-400 border-b border-slate-100">Select Rating</div>
                                                    {getAvailableMvaOptions().map((opt, i) => (
                                                        <button 
                                                            key={i}
                                                            className="w-full text-left px-2 py-1.5 hover:bg-indigo-50 text-slate-700"
                                                            onClick={() => { updateState('oaMax', opt.value); setShowOaMaxDropdown(false); }}
                                                        >
                                                            {opt.label}: {opt.value.toLocaleString()}
                                                        </button>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </td>
                                <td className="px-3 text-slate-500">OA max</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>
                            {/* Row 3 */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">3</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Max MVA:</td>
                                <td className="border-2 border-indigo-200 bg-white p-0 h-8">{renderInput('maxMva')}</td>
                                <td className="px-3 text-slate-500">Max Last</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>
                            {/* Row 4 Header */}
                            <tr className="bg-slate-100 border-y-2 border-slate-300">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">4</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-800">Load Loss Calculations :</td>
                                <td className="px-3 text-center font-bold text-slate-800 bg-slate-200/50 border-r border-slate-300">Nominal Tap</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 text-center font-bold text-slate-800 bg-slate-200/50 border-r border-slate-300">Minimum Tap</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>
                            {/* Row 5 */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">5</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Total No Load Losses:</td>
                                <td className="border-2 border-indigo-200 bg-white p-0 h-8">{renderInput('nll')}</td>
                                <td className="px-3 text-slate-500">NLL</td>
                                <td className="px-3 text-right font-medium text-slate-700 border-r border-slate-200">{format(total_nll)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>
                            {/* Row 6 Spacer */}
                            <tr className="bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">6</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1 font-bold text-slate-600">Main XFMR</td>
                                <td colSpan={4} className="border-r border-slate-100"></td>
                                <td className="px-3 text-red-400 italic">Enter OA last stage if you have six stage</td>
                            </tr>
                            {/* Row 7 (Formerly Placeholder) Now Editable LV1 */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">7</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">LV I2R Loss:</td>
                                <td className="border-2 border-indigo-200 bg-white p-0 h-8">{renderInput('lvLoss1')}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="border-2 border-indigo-200 bg-white p-0 h-8">{renderInput('lvLoss1Min')}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 text-red-400 italic">Enter Last stage value if You have six stage cooling</td>
                            </tr>
                            {/* Row 8 LV Actual */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">8</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">LV I2R Loss:</td>
                                <td className="border-2 border-indigo-200 bg-white p-0 h-8">{renderInput('lvLoss')}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="border-2 border-indigo-200 bg-white p-0 h-8 relative">
                                    {pageState.useLvMinCalc ? 
                                        <div className="w-full h-full flex items-center justify-end px-2 bg-slate-50 text-slate-500 italic text-[10px]">
                                            {format(pageState.lvLossMin)} (Calc)
                                        </div>
                                        : 
                                        renderInput('lvLossMin')
                                    }
                                </td>
                                <td className="border-r border-slate-100 px-1">
                                    <button 
                                        onClick={toggleLvCalc}
                                        className={`p-1 rounded transition-colors ${pageState.useLvMinCalc ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 text-slate-400 hover:bg-slate-200'}`}
                                        title="Toggle Formula Calculation"
                                    >
                                        <FunctionSquare className="w-4 h-4" />
                                    </button>
                                </td>
                                <td className="px-2">
                                    {pageState.useLvMinCalc && (
                                        <div className="flex space-x-2 items-center">
                                            <div className="flex flex-col">
                                                <span className="text-[9px] text-slate-400 uppercase font-bold">Max I</span>
                                                <input 
                                                    type="number" className="w-16 border-b border-indigo-200 focus:border-indigo-500 outline-none text-right font-mono text-xs bg-white"
                                                    value={pageState.lvMaxCurrent} onChange={e => updateState('lvMaxCurrent', parseFloat(e.target.value))}
                                                />
                                            </div>
                                            <div className="flex flex-col">
                                                <span className="text-[9px] text-slate-400 uppercase font-bold">Nom I</span>
                                                <input 
                                                    type="number" className="w-16 border-b border-indigo-200 focus:border-indigo-500 outline-none text-right font-mono text-xs bg-white"
                                                    value={pageState.lvNomCurrent} onChange={e => updateState('lvNomCurrent', parseFloat(e.target.value))}
                                                />
                                            </div>
                                        </div>
                                    )}
                                </td>
                            </tr>
                            {/* Row 9 HV Actual */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">9</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">HV I2R Loss:</td>
                                <td className="border-2 border-indigo-200 bg-white p-0 h-8">{renderInput('hvLoss')}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="border-2 border-indigo-200 bg-white p-0 h-8">{renderInput('hvLossMin')}</td>
                                <td className="border-r border-slate-100 text-xs text-slate-400 pl-1">(Calc)</td>
                                <td></td>
                            </tr>
                            {/* Row 10 Calc 75C */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">10</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Calculated I2R Loss @ 75°C:</td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(i2r_75_nom)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(i2r_75_min)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>
                            {/* Row 11 Calc 85C */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">11</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Calculated I2R Loss @ 85°C:</td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(i2r_85_nom)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(i2r_85_min)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>
                            {/* Row 12 Stray 75C */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">12</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">% Eddy & Stray assumed @ 75:</td>
                                <td className="border-2 border-indigo-200 bg-white p-0 h-8">{renderInput('strayPct')}</td>
                                <td className="px-3 text-slate-500">%</td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(stray_75_min)}</td>
                                <td className="px-3 text-slate-500">(Calc)</td>
                                <td></td>
                            </tr>
                            {/* Row 13 Stray 85C */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">13</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">% Eddy & Stray assumed @ 85:</td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(stray_85_nom)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(stray_85_min)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>
                            {/* Row 14 NLL Copy */}
                             <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">14</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">NLL Main XFMR</td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(pageState.nll)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(pageState.nll)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>

                            {/* Spacers */}
                            <tr className="bg-slate-50 h-8 border-y border-slate-200">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">15</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Additional Load Loss</td>
                                <td className="border-2 border-indigo-200 bg-white p-0 h-8">{renderInput('addLl')}</td>
                                <td colSpan={4} className="px-3 text-slate-400 text-xs italic">Added to Total Load Loss</td>
                            </tr>
                            <tr className="bg-slate-50 h-8 border-y border-slate-200">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">16</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Additional No Load Loss</td>
                                <td className="border-2 border-indigo-200 bg-white p-0 h-8">{renderInput('addNll')}</td>
                                <td colSpan={4} className="px-3 text-slate-400 text-xs italic">Added to Total NLL</td>
                            </tr>
                            <tr className="bg-slate-50 h-8 border-y border-slate-200">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">17-20</th>
                                <td colSpan={7} className="text-center text-slate-400 italic">...</td>
                            </tr>

                            {/* Row 21 Total LL 75 */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">21</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Total Load Losses at 75 deg</td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-slate-900 border-r border-slate-200 bg-indigo-50/30">{format(total_ll_75_nom)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-slate-900 border-r border-slate-200 bg-indigo-50/30">{format(total_ll_75_min)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>
                            {/* Row 22 Total LL 85 */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">22</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Total Load Losses at 85 deg</td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(total_ll_85_nom)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(total_ll_85_min)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>
                            {/* Row 23 Total NLL */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">23</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Total No Load Losses</td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(total_nll)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(total_nll)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>
                             {/* Row 24 71% FA2 */}
                             <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">24</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">If 71% FA2, Load Loss @ONAN@75°C</td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-slate-900 border-r border-slate-200 bg-amber-50/30">{format(ll_71_fa2_nom)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-slate-900 border-r border-slate-200 bg-amber-50/30">{format(ll_71_fa2_min)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>

                            {/* Row 25 Total Loss 75 */}
                            <tr className="hover:bg-slate-50 border-t-2 border-slate-300">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">25</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Total Loss at 75 deg</td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-slate-900 border-r border-slate-200 border-b-4 border-double border-slate-400">{format(total_loss_75_nom)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-slate-900 border-r border-slate-200 border-b-4 border-double border-slate-400 bg-gray-300">{format(total_loss_75_min)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 text-xs font-bold text-slate-500">ONAN for 65 D</td>
                            </tr>
                            {/* Row 26 Total Loss 85 */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">26</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Total Loss at 85 deg</td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(total_loss_85_nom)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono text-slate-800 border-r border-slate-200">{format(total_loss_85_min)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>

                            {/* Row 27 Total 71% FA2 */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">27</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Total Loss @ 75°C with 71% of FA2</td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-slate-900 border-r border-slate-200">{format(total_loss_71_fa2_nom)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-slate-900 border-r border-slate-200 bg-gray-300">{format(total_loss_71_fa2_min)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 text-xs font-bold text-slate-500">71% ONAN at 65</td>
                            </tr>

                            {/* Row 28 Load Loss Max Rating 75C */}
                            <tr className="hover:bg-slate-50 border-t border-slate-200">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">28</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Load Loss at Max FA Rating (75°C)</td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-indigo-700 border-r border-slate-200">{format(ll_max_rating_75_nom)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-indigo-700 border-r border-slate-200">{format(ll_max_rating_75_min)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>

                             {/* Row 29 Load Loss Max Rating 85C */}
                             <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">29</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Load Loss at Max FA Rating (85°C)</td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-indigo-700 border-r border-slate-200">{format(ll_max_rating_nom)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-indigo-700 border-r border-slate-200">{format(ll_max_rating_min)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>

                            {/* Row 30 Total Loss Max Rating 75C */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">30</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Total Losses at Max FA Rating (75°C)</td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-emerald-700 border-r border-slate-200">{format(total_max_rating_75_nom)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-emerald-700 border-r border-slate-200 bg-gray-300">{format(total_max_rating_75_min)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td></td>
                            </tr>

                            {/* Row 31 Total Loss Max Rating 85C */}
                            <tr className="hover:bg-slate-50">
                                <th className="text-center text-slate-400 bg-slate-50 border-r border-slate-200">31</th>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 font-bold text-slate-700 text-right bg-slate-50/50">Total Losses at Max FA Rating (85°C)</td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-emerald-700 border-r border-slate-200">{format(total_max_rating_nom)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 py-1.5 text-right font-mono font-bold text-emerald-700 border-r border-slate-200 bg-gray-300">{format(total_max_rating_min)}</td>
                                <td className="border-r border-slate-100"></td>
                                <td className="px-3 text-xs font-bold text-slate-500">ONAF at 65</td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Page8;

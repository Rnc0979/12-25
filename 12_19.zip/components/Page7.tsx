

import React, { useState, useEffect } from 'react';
import { ArrowLeft, Activity, RotateCcw, FileSpreadsheet, ChevronDown, ChevronUp, Sliders, Box, Zap, Link as LinkIcon, RefreshCw } from 'lucide-react';
import { ExtractedData, Page7State } from '../types';

interface Page7Props {
    data: ExtractedData | null;
    onBack: () => void;
    windingNames: string[];
    windingCount: number;
    pageState: Page7State;
    setPageState: React.Dispatch<React.SetStateAction<Page7State>>;
}

const Page7: React.FC<Page7Props> = ({ data, onBack, windingNames, windingCount, pageState, setPageState }) => {
    
    // Default to the pair just inside the outermost (e.g., for 3 wdgs: W2-W3, so index 1)
    const [linkIndex, setLinkIndex] = useState(Math.max(0, windingCount - 2));

    useEffect(() => {
        setLinkIndex(Math.max(0, windingCount - 2));
    }, [windingCount]);

    // --- ACTIONS ---

    const updateState = (field: keyof Page7State, value: number) => {
        setPageState(prev => ({ ...prev, [field]: value }));
    };

    const resetSheet = () => {
         setPageState({
            isInitialized: true,
            r1: 2.0758,
            r2: 2.2830,
            r3: 3.1185,
            vt: 64.8598,
            height: 48.75,
            mva: 15,
            meanTurnLvRef: 73.9273,
            r1Ref: 2.0758,
            calibConst: 1.211081
        });
    };

    const handleLoadData = () => {
        if (!data) return;
        const innerIdx = linkIndex;
        const outerIdx = linkIndex + 1;
        
        if (outerIdx >= windingCount) return;

        const innerKey = `wdg${innerIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
        const outerKey = `wdg${outerIdx + 1}` as 'wdg1' | 'wdg2' | 'wdg3';
        const inner = data[innerKey];
        const outer = data[outerKey];

        // 1. Radial Widths
        const r1Val = parseFloat(String(inner.radial)) || 0;
        const r3Val = parseFloat(String(outer.radial)) || 0;

        // 2. Gap (R2) = (Outer ID - Inner OD) / 2
        const outerID = parseFloat(String(outer.id)) || 0;
        const innerOD = parseFloat(String(inner.od)) || 0;
        let r2Val = 0;
        if (outerID > 0 && innerOD > 0) {
            r2Val = (outerID - innerOD) / 2;
        }

        // 3. Mean Turn Ref (From Inner Winding)
        const mtRef = parseFloat(String(inner.meanTurn)) || 0;

        // 4. Height (From Outer Winding) -> Ceiling to 0.125
        const rawH = parseFloat(String(outer.wireSpaceMech)) || 0;
        const hVal = Math.ceil(rawH / 0.125) * 0.125;

        // 5. MVA
        const mvaVal = parseFloat(data.mva || '0') || 0;

        // 6. VT (Volts / Turn)
        let vtVal = pageState.vt;
        if (data.voltsPerTurn) {
             vtVal = parseFloat(data.voltsPerTurn) || pageState.vt;
        }

        setPageState(prev => ({
            ...prev,
            r1: r1Val,
            r2: Math.max(0, r2Val), 
            r3: r3Val,
            height: hVal,
            meanTurnLvRef: mtRef,
            r1Ref: r1Val, // Set Ref Width to match current Inner Width
            mva: mvaVal > 0 ? mvaVal : prev.mva,
            vt: vtVal
        }));
    };

    // --- CALCULATION LOGIC (Python Port) ---
    
    const { r1, r2, r3, vt, height, mva, meanTurnLvRef, r1Ref, calibConst } = pageState;
    const PI = Math.PI;
    const kva = mva * 1000;

    // 1. Derive Inner Diameter (D_start)
    // D_inner = (Mean Turn Ref / PI) - Ref Width
    const dStart = (meanTurnLvRef / PI) - r1Ref;

    // 2. Calculate Current Geometric Mean Diameters
    const dLv = dStart + r1;       // Mean Diameter LV
    const dGap = dLv + r1 + r2;    // Mean Diameter Gap (Accumulative)
    const dHv = dGap + r2 + r3;    // Mean Diameter HV (Accumulative)
  
    // 3. Calculate Effective Radial Sum
    const termLv = (r1 / 3) * dLv;
    const termGap = r2 * dGap;
    const termHv = (r3 / 3) * dHv;

    const sumRadialTerms = termLv + termGap + termHv;

    // 4. Final Impedance
    let percentZ = 0;
    const denominator = (Math.pow(vt, 2) * height);
    if (denominator !== 0) {
        percentZ = (calibConst * kva * sumRadialTerms) / denominator;
    }

    const calculatedMeanTurnLV = dLv * PI;

    // Get names for display
    const innerName = windingNames[linkIndex] || `Winding ${linkIndex + 1}`;
    const outerName = windingNames[linkIndex + 1] || `Winding ${linkIndex + 2}`;


    return (
        <div className="space-y-6 animate-fadeIn pb-12">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
                <button onClick={onBack} className="flex items-center text-slate-600 hover:text-slate-900 transition-colors bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm">
                    <ArrowLeft className="w-4 h-4 mr-2" /> Back
                </button>
                <div className="flex items-center space-x-3">
                    <button onClick={resetSheet} className="flex items-center px-3 py-2 bg-rose-50 text-rose-700 border border-rose-200 rounded-lg text-xs font-bold hover:bg-rose-100 transition-colors">
                        <RotateCcw className="w-3 h-3 mr-2" /> Reset Defaults
                    </button>
                    <div className="bg-slate-800 text-white px-4 py-2 rounded-lg shadow-sm text-sm font-bold flex items-center">
                        <FileSpreadsheet className="w-4 h-4 mr-2 text-emerald-400" />
                        Python Sim
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-12 gap-6">
                
                {/* INPUTS COLUMN */}
                <div className="col-span-12 lg:col-span-7 space-y-6">
                    
                    {/* DATA LINKING CARD */}
                    {data && (
                        <div className="bg-gradient-to-r from-indigo-50 to-blue-50 rounded-xl border border-indigo-100 p-4 flex flex-col sm:flex-row items-center justify-between shadow-sm">
                            <div className="flex items-center mb-3 sm:mb-0">
                                <LinkIcon className="w-5 h-5 text-indigo-600 mr-3" />
                                <div>
                                    <h3 className="font-bold text-sm text-indigo-900">Data Source</h3>
                                    <p className="text-xs text-indigo-600">Select winding pair to populate inputs</p>
                                </div>
                            </div>
                            <div className="flex items-center space-x-3 w-full sm:w-auto">
                                <select 
                                    className="bg-white border border-indigo-200 text-indigo-800 text-xs font-bold rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400 cursor-pointer flex-1 sm:flex-none"
                                    value={linkIndex}
                                    onChange={(e) => setLinkIndex(parseInt(e.target.value))}
                                >
                                    {Array.from({ length: windingCount - 1 }).map((_, idx) => (
                                        <option key={idx} value={idx}>
                                            {windingNames[idx]} vs {windingNames[idx+1]}
                                        </option>
                                    ))}
                                </select>
                                <button 
                                    onClick={handleLoadData}
                                    className="flex items-center bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2 rounded-lg transition-colors shadow-sm whitespace-nowrap"
                                >
                                    <RefreshCw className="w-3 h-3 mr-2" />
                                    Load & Calculate
                                </button>
                            </div>
                        </div>
                    )}

                    {/* Geometry Inputs */}
                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                        <div className="px-5 py-4 border-b border-slate-100 bg-white flex items-center justify-between">
                            <div className="flex items-center">
                                <Box className="w-4 h-4 mr-2 text-indigo-600" />
                                <h3 className="font-bold text-sm text-slate-800 uppercase tracking-wide">Geometry Inputs</h3>
                            </div>
                            {data && <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-1 rounded font-medium">Ref: {innerName} - {outerName}</span>}
                        </div>
                        <div className="p-5 grid grid-cols-1 sm:grid-cols-3 gap-6">
                            <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase">
                                    LV WIDTH (R1)
                                    <span className="text-[9px] text-slate-400 font-normal ml-1 normal-case">(Inner)</span>
                                </label>
                                <div className="relative">
                                    <input 
                                        type="number" step="0.0001"
                                        className="w-full pl-3 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 font-mono text-slate-800 bg-white"
                                        value={r1} onChange={e => updateState('r1', parseFloat(e.target.value))}
                                    />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase">GAP WIDTH (R2)</label>
                                <div className="relative">
                                    <input 
                                        type="number" step="0.0001"
                                        className="w-full pl-3 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 font-mono text-slate-800 bg-white"
                                        value={r2} onChange={e => updateState('r2', parseFloat(e.target.value))}
                                    />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase">
                                    HV WIDTH (R3)
                                    <span className="text-[9px] text-slate-400 font-normal ml-1 normal-case">(Outer)</span>
                                </label>
                                <div className="relative">
                                    <input 
                                        type="number" step="0.0001"
                                        className="w-full pl-3 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 font-mono text-slate-800 bg-white"
                                        value={r3} onChange={e => updateState('r3', parseFloat(e.target.value))}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Ratings Inputs */}
                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                        <div className="px-5 py-4 border-b border-slate-100 bg-white flex items-center">
                            <Zap className="w-4 h-4 mr-2 text-amber-600" />
                            <h3 className="font-bold text-sm text-slate-800 uppercase tracking-wide">Ratings Inputs</h3>
                        </div>
                        <div className="p-5 grid grid-cols-1 sm:grid-cols-3 gap-6">
                             <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase">VOLTS / TURN (VT)</label>
                                <input 
                                    type="number" step="0.01"
                                    className="w-full pl-3 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-mono text-slate-800 bg-white"
                                    value={vt} onChange={e => updateState('vt', parseFloat(e.target.value))}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase">
                                    HEIGHT (H)
                                    <span className="text-[9px] text-slate-400 font-normal ml-1 normal-case">(Ceiling 0.125)</span>
                                </label>
                                <input 
                                    type="number" step="0.01"
                                    className="w-full pl-3 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-mono text-slate-800 bg-white"
                                    value={height} onChange={e => updateState('height', parseFloat(e.target.value))}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase">MVA</label>
                                <input 
                                    type="number" step="0.1"
                                    className="w-full pl-3 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-mono text-slate-800 bg-white"
                                    value={mva} onChange={e => updateState('mva', parseFloat(e.target.value))}
                                />
                                <div className="text-[10px] text-slate-400 text-right">= {kva.toLocaleString()} kVA</div>
                            </div>
                        </div>
                    </div>

                    {/* Calibration Inputs */}
                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                        <div className="px-5 py-4 border-b border-slate-100 bg-white flex items-center">
                            <Sliders className="w-4 h-4 mr-2 text-slate-500" />
                            <h3 className="font-bold text-sm text-slate-700 uppercase tracking-wide">Calibration Parameters</h3>
                        </div>
                        <div className="p-5 grid grid-cols-1 sm:grid-cols-3 gap-6">
                            <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-400 uppercase">REF MEAN TURN LV</label>
                                <input 
                                    type="number" step="0.0001"
                                    className="w-full pl-3 pr-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-slate-400 focus:border-slate-400 font-mono text-slate-600 bg-white"
                                    value={meanTurnLvRef} onChange={e => updateState('meanTurnLvRef', parseFloat(e.target.value))}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-400 uppercase">REF LV WIDTH</label>
                                <input 
                                    type="number" step="0.0001"
                                    className="w-full pl-3 pr-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-slate-400 focus:border-slate-400 font-mono text-slate-600 bg-white"
                                    value={r1Ref} onChange={e => updateState('r1Ref', parseFloat(e.target.value))}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-400 uppercase">CALIBRATION CONST</label>
                                <input 
                                    type="number" step="0.000001"
                                    className="w-full pl-3 pr-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-slate-400 focus:border-slate-400 font-mono text-slate-600 bg-white"
                                    value={calibConst} onChange={e => updateState('calibConst', parseFloat(e.target.value))}
                                />
                            </div>
                        </div>
                    </div>

                </div>

                {/* RESULTS COLUMN */}
                <div className="col-span-12 lg:col-span-5 space-y-6">
                     <div className="bg-slate-800 rounded-xl shadow-lg border border-slate-700 overflow-hidden text-white sticky top-20">
                         <div className="px-6 py-5 border-b border-slate-700 bg-slate-900/50 flex justify-between items-center">
                             <h3 className="text-sm font-bold uppercase tracking-wider flex items-center">
                                 <Activity className="w-5 h-5 mr-2 text-emerald-400" />
                                 Simulation Result
                             </h3>
                         </div>
                         
                         <div className="p-8 text-center border-b border-slate-700/50">
                             <div className="text-xs text-slate-400 uppercase font-bold mb-2">SHORT CIRCUIT IMPEDANCE</div>
                             <div className="text-6xl font-mono font-bold text-white tracking-tight">
                                 {percentZ.toFixed(4)}<span className="text-3xl text-emerald-500 ml-1">%</span>
                             </div>
                         </div>

                         <div className="p-6">
                            <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-3">INTERMEDIATE VALUES</h4>
                            <div className="space-y-3 font-mono text-xs">
                                <div className="flex justify-between items-center p-2 rounded bg-slate-700/30">
                                    <span className="text-slate-400">D_start (ID Base)</span>
                                    <span className="text-white font-bold">{dStart.toFixed(4)}</span>
                                </div>
                                <div className="flex justify-between items-center p-2 rounded bg-slate-700/30">
                                    <span className="text-slate-400">D_lv (Mean LV)</span>
                                    <span className="text-indigo-300 font-bold">{dLv.toFixed(4)}</span>
                                </div>
                                <div className="flex justify-between items-center p-2 rounded bg-slate-700/30">
                                    <span className="text-slate-400">D_gap (Mean Gap)</span>
                                    <span className="text-amber-300 font-bold">{dGap.toFixed(4)}</span>
                                </div>
                                <div className="flex justify-between items-center p-2 rounded bg-slate-700/30">
                                    <span className="text-slate-400">D_hv (Mean HV)</span>
                                    <span className="text-purple-300 font-bold">{dHv.toFixed(4)}</span>
                                </div>
                                
                                <div className="h-px bg-slate-700 my-2"></div>
                                
                                <div className="flex justify-between items-center p-2">
                                    <span className="text-slate-400">Term LV (r1/3 * D_lv)</span>
                                    <span className="text-slate-300">{termLv.toFixed(4)}</span>
                                </div>
                                <div className="flex justify-between items-center p-2">
                                    <span className="text-slate-400">Term Gap (r2 * D_gap)</span>
                                    <span className="text-slate-300">{termGap.toFixed(4)}</span>
                                </div>
                                <div className="flex justify-between items-center p-2">
                                    <span className="text-slate-400">Term HV (r3/3 * D_hv)</span>
                                    <span className="text-slate-300">{termHv.toFixed(4)}</span>
                                </div>
                                <div className="flex justify-between items-center p-2 border-t border-slate-700">
                                    <span className="text-emerald-400 font-bold">Sum Radial Terms</span>
                                    <span className="text-white font-bold text-sm">{sumRadialTerms.toFixed(4)}</span>
                                </div>
                                
                                <div className="h-px bg-slate-700 my-2"></div>

                                <div className="flex justify-between items-center p-2 bg-slate-700/50 rounded border border-slate-600">
                                    <span className="text-slate-400 font-bold">Calculated Mean Turn LV</span>
                                    <span className="text-white font-mono font-bold">{calculatedMeanTurnLV.toFixed(4)}</span>
                                </div>

                            </div>
                         </div>
                     </div>
                </div>
            </div>
        </div>
    );
};

export default Page7;

import { CoreRow, ExtractedData, PdfTextItem, ProcessedRow, WindingStats } from '../types';

const INITIAL_WDG_STATE: WindingStats = {
    ratedTurns: null, maxTurns: null, minTurns: null, type: null, discVal: null, lyrsVal: null, ksCircle: null, ksWidth: null, ksThk: null, id: null, od: null, meanTurn: null, lineVoltage: null, coilVoltage: null, lossStr: null, totalLoss: null,
    paperInsul: null, bareThk: null, bareWidth: null, radial: null, i2r: null, wattsOA: null, wattsMax: null, gradOA: null, gradMax: null, sGradOA: null, sGradMax: null, pullsW: null, pullsH: null, strands: null, parallelGroups: null,
    ratedAmps: null, wireSpaceMech: null
};

export const processPdfFile = async (file: File): Promise<{ data: ExtractedData, windingCount: number, windingNames: string[] }> => {
    if (!window.pdfjsLib) throw new Error("PDF Processor not ready yet.");

    const arrayBuffer = await file.arrayBuffer();
    const pdf = await window.pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let allItems: PdfTextItem[] = [];

    for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageItems = textContent.items.map((item: any) => ({
            str: item.str, x: item.transform[4], y: item.transform[5], w: item.width, h: item.height
        }));
        allItems = [...allItems, ...pageItems];
    }

    return processSpatialData(allItems);
};

const getRowNumbers = (items: PdfTextItem[]) => {
    const numbers: number[] = [];
    items.forEach(item => {
        // Updated regex to capture any number of digits before decimal to handle voltages like 138000
        const matches = item.str.match(/(\d+\.?\d*)/);
        if (matches) {
            const val = parseFloat(matches[0]);
            if (!isNaN(val)) numbers.push(val);
        }
    });
    return numbers;
};

// Helper to map items to columns based on X coordinates
const extractColumnarValues = (items: PdfTextItem[], centers: number[], tolerance: number = 80): (string | null)[] => {
    const result: (string | null)[] = [null, null, null];
    // If no centers detected, we can't do spatial mapping
    if (centers.every(c => c === 0)) return result;

    const numericItems = items.filter(i => /[\d\.]+/.test(i.str));

    numericItems.forEach(item => {
        // Find the number in the string
        const valMatch = item.str.match(/(\d+\.?\d*)/);
        if (!valMatch) return;
        const val = valMatch[0];

        // Determine item center X
        const itemCenter = item.x + (item.w / 2);

        let bestCol = -1;
        let minDiff = tolerance;

        centers.forEach((center, idx) => {
            if (center === 0) return;
            const diff = Math.abs(itemCenter - center);
            if (diff < minDiff) {
                minDiff = diff;
                bestCol = idx;
            }
        });

        if (bestCol !== -1) {
            result[bestCol] = val;
        }
    });

    return result;
};

const processSpatialData = (items: PdfTextItem[]): { data: ExtractedData, windingCount: number, windingNames: string[] } => {
    const ROW_TOLERANCE = 4;
    const rows: { y: number, items: PdfTextItem[] }[] = [];

    // Sort items by Y (descending) to group lines
    items.sort((a, b) => b.y - a.y);

    items.forEach(item => {
        if (!item.str.trim()) return;
        const existingRow = rows.find(r => Math.abs(r.y - item.y) < ROW_TOLERANCE);
        if (existingRow) { existingRow.items.push(item); } else { rows.push({ y: item.y, items: [item] }); }
    });

    const processedRows: ProcessedRow[] = rows.map(row => {
        row.items.sort((a, b) => a.x - b.x);
        const textLine = row.items.map(i => i.str).join('   ');
        return { ...row, textLine, lowerLine: textLine.toLowerCase() };
    });

    let detectedCount = 2;
    let detectedNames = ['Winding 1', 'Winding 2', 'Winding 3'];
    let wdgXPositions: number[] = [0, 0, 0];

    const wdgRow = processedRows.find(r => r.lowerLine.includes("winding number") || r.lowerLine.includes("wdg 1"));
    if (wdgRow) {
        const wdgMatches = wdgRow.lowerLine.match(/wdg\s*\d/g);
        if (wdgMatches && wdgMatches.length >= 3) detectedCount = 3;
        else if (wdgMatches && wdgMatches.length === 2) detectedCount = 2;

        // Detect Column Centers
        // Look for items containing "1", "2", "3" to establish column centers
        wdgRow.items.forEach(item => {
            const txt = item.str.toLowerCase();
            if (txt.includes("wdg")) {
                if (txt.includes("1")) wdgXPositions[0] = item.x + (item.w / 2);
                if (txt.includes("2")) wdgXPositions[1] = item.x + (item.w / 2);
                if (txt.includes("3")) wdgXPositions[2] = item.x + (item.w / 2);
            } else {
                // Sometimes headers are just numbers "1", "2", "3" or "Winding 1"
                if (txt.trim() === "1" || txt.includes("winding 1")) wdgXPositions[0] = item.x + (item.w / 2);
                if (txt.trim() === "2" || txt.includes("winding 2")) wdgXPositions[1] = item.x + (item.w / 2);
                if (txt.trim() === "3" || txt.includes("winding 3")) wdgXPositions[2] = item.x + (item.w / 2);
            }
        });
    } else {
        const ratedRow = processedRows.find(r => r.lowerLine.includes("rated turns"));
        if (ratedRow) {
            const nums = getRowNumbers(ratedRow.items);
            if (nums.length >= 3) detectedCount = 3;
            // Fallback: Estimate X positions from Rated Turns if header missing
            if (nums.length >= 2) {
                // Try to find the items corresponding to these numbers to set positions
                // This is a rough heuristic
                const numItems = ratedRow.items.filter(i => /\d/.test(i.str));
                if (numItems.length >= 2) {
                    wdgXPositions[0] = numItems[0].x + (numItems[0].w / 2);
                    wdgXPositions[1] = numItems[1].x + (numItems[1].w / 2);
                    if (numItems.length >= 3) wdgXPositions[2] = numItems[2].x + (numItems[2].w / 2);
                }
            }
        }
    }

    const nameRow = processedRows.find(r => r.lowerLine.includes("name & bil") || r.lowerLine.includes("name & bil"));
    if (nameRow) {
        const potentialNames = nameRow.items
            .filter(i => !i.str.match(/\d/) && !i.str.toLowerCase().includes("name") && !i.str.toLowerCase().includes("bil") && i.str.trim().length > 0)
            .map(i => i.str.replace(/[-:]/g, '').trim());
        if (potentialNames.length > 0) {
            if (detectedCount === 3 && potentialNames.length >= 3) { detectedNames = [potentialNames[0], potentialNames[1], potentialNames[2]]; }
            else if (potentialNames.length >= 2) { detectedNames = [potentialNames[0], potentialNames[1], 'Winding 3']; }
        }
    }

    const data: ExtractedData = {
        wdg1: { ...INITIAL_WDG_STATE },
        wdg2: { ...INITIAL_WDG_STATE },
        wdg3: { ...INITIAL_WDG_STATE },
        tubeTables: [],
        coreTable: [],
        core: {
            weight: null, fluxDen: null, feCircle: null, windowHt: null, windowWidth: null, legCenter: null, coreLength: null, coreHt: null, lamWidth: null, coreGrad: null
        },
        tank: {
            clearanceRight: null, clearanceLeft: null, clearanceFront: null, clearanceBack: null, width: null, depth: null, height: null
        },
        mva: null,
        maxMva: null,
        voltsPerTurn: null,
        impedance: { percentZ: null },
        brackets: { wdgSpace: null, top: null, bottom: null },
        keepBack: null,
        nllExp: null,
        debugLog: []
    };

    const roundVal = (val: number) => Math.round(val);
    let currentTubeTable: any = null;
    let totalRowIndex = -1;
    let totalRowX = 0;
    let debugLog: string[] = [];
    let impedanceHeaderIndex = -1;

    // To track impedance priority (4=Combined, 3=HL/LH Main, 2=TV pairs, 1=Fallback, 0=None)
    let impedancePriorityFound = 0;

    debugLog.push(`Processing PDF with ${processedRows.length} text rows identified.`);
    debugLog.push(`Winding X Centers: W1=${wdgXPositions[0].toFixed(0)}, W2=${wdgXPositions[1].toFixed(0)}, W3=${wdgXPositions[2].toFixed(0)}`);

    processedRows.forEach((row, idx) => {
        const { lowerLine, items, textLine } = row;
        let nums = getRowNumbers(items);

        // Core Grad Extraction
        if (lowerLine.includes("coregrad") || lowerLine.includes("core grad")) {
            // Regex to find "CoreGrad value" or "CoreGrad value1/value2"
            // Handles cases like "CoreDetails: M3 StepLap D-Yoke CoreGrad 18.09/19.20"
            const matches = textLine.match(/CoreGrad\s*([\d\.]+)(?:\s*\/\s*([\d\.]+))?/i);
            if (matches) {
                const v1 = parseFloat(matches[1]);
                const v2 = matches[2] ? parseFloat(matches[2]) : 0;
                data.core.coreGrad = String(Math.max(v1, v2));
                debugLog.push(`[CoreGrad] Extracted: ${data.core.coreGrad} from "${matches[0]}"`);
            }
        }

        // MVA / KVA Extraction
        if (lowerLine.includes("kva") || lowerLine.includes("mva")) {
            const kvaMatch = textLine.match(/([\d\.,]+(?:\s*\/\s*[\d\.,]+)*)\s*(?:KVA|MVA)/i);

            if (kvaMatch) {
                const parts = kvaMatch[1].split('/').map(s => s.trim());
                if (parts.length > 0) {
                    const cleanNum = (s: string) => parseFloat(s.replace(/,/g, ''));
                    // Extract all kVA values
                    const allKvaValues: number[] = [];
                    parts.forEach(part => {
                        const kva = cleanNum(part);
                        if (kva > 0) allKvaValues.push(kva);
                    });

                    // Store all values
                    if (allKvaValues.length > 0) {
                        data.allKvaValues = allKvaValues;
                        debugLog.push(`[KVA] Extracted all values: ${allKvaValues.join(', ')}`);
                        const baseKva = allKvaValues[0];
                        data.mva = String(baseKva / 1000); // Base MVA

                        if (allKvaValues.length > 1) {
                            const maxKva = allKvaValues[allKvaValues.length - 1];
                            data.maxMva = String(maxKva / 1000); // Max MVA
                        }
                    }
                }
            } else if (lowerLine.includes("base kva")) {
                const baseNums = getRowNumbers(items);
                if (baseNums.length > 0) {
                    data.mva = String(baseNums[0] / 1000);
                    data.allKvaValues = [baseNums[0]];
                }
            }
        }

        // Volts/Turn Extraction
        if (lowerLine.includes("volts/turn")) {
            const vtMatch = textLine.match(/Volts\/Turn\s*=\s*([\d\.]+)/i);
            if (vtMatch) {
                data.voltsPerTurn = vtMatch[1];
                debugLog.push(`[Volts/Turn] Extracted: ${data.voltsPerTurn}`);
            }
        }

        // Line Voltage Extraction (Spatial Aware)
        if ((lowerLine.includes("line volts") || lowerLine.includes("rated voltage") || lowerLine.includes("line-line voltage")) && !lowerLine.includes("volts/turn") && !lowerLine.includes("volts/t")) {
            // Try spatial mapping first
            const mapped = extractColumnarValues(items, wdgXPositions);
            if (mapped[0] || mapped[1] || mapped[2]) {
                if (mapped[0]) data.wdg1.lineVoltage = mapped[0];
                if (mapped[1]) data.wdg2.lineVoltage = mapped[1];
                if (mapped[2]) data.wdg3.lineVoltage = mapped[2];
            } else {
                // Fallback to sequential if spatial failed
                const vNums = getRowNumbers(items);
                if (vNums.length > 0) {
                    if (detectedCount === 3 && vNums.length >= 3) {
                        data.wdg1.lineVoltage = vNums[0];
                        data.wdg2.lineVoltage = vNums[1];
                        data.wdg3.lineVoltage = vNums[2];
                    } else if (vNums.length >= 2) {
                        data.wdg1.lineVoltage = vNums[0];
                        data.wdg2.lineVoltage = vNums[1];
                    }
                }
            }
        }

        // Coil Voltage Extraction (Spatial Aware)
        if ((lowerLine.includes("coil voltage") || lowerLine.includes("coil volts")) && !lowerLine.includes("max coil") && !lowerLine.includes("min coil")) {
            // Try spatial mapping first
            const mapped = extractColumnarValues(items, wdgXPositions);
            if (mapped[0] || mapped[1] || mapped[2]) {
                if (mapped[0]) data.wdg1.coilVoltage = mapped[0];
                if (mapped[1]) data.wdg2.coilVoltage = mapped[1];
                if (mapped[2]) data.wdg3.coilVoltage = mapped[2];
            } else {
                // Fallback to sequential if spatial failed
                const vNums = getRowNumbers(items);
                if (vNums.length > 0) {
                    if (detectedCount === 3 && vNums.length >= 3) {
                        data.wdg1.coilVoltage = vNums[0];
                        data.wdg2.coilVoltage = vNums[1];
                        data.wdg3.coilVoltage = vNums[2];
                    } else if (vNums.length >= 2) {
                        data.wdg1.coilVoltage = vNums[0];
                        data.wdg2.coilVoltage = vNums[1];
                    }
                }
            }
        }

        // Impedance Extraction (%Z)
        if (lowerLine.includes("terminal pair") && lowerLine.includes("%iz")) {
            impedanceHeaderIndex = idx;
            debugLog.push(`[IMPEDANCE] Header found at index ${idx}`);
        }
        // Look for values in rows following the Impedance Header
        if (impedanceHeaderIndex !== -1 && idx > impedanceHeaderIndex && idx < impedanceHeaderIndex + 10) {
            const izNums = getRowNumbers(items);
            if (izNums.length >= 4) {
                const potentialZ = izNums[izNums.length - 1];
                const potentialZStr = String(potentialZ);

                // Basic validity check
                if (potentialZ < 20) {
                    // Check for MAIN Impedance (HV to LV / LV to HV) without Tertiary mix
                    const hasHV = lowerLine.includes("hv");
                    const hasLV = lowerLine.includes("lv");
                    const hasTV = lowerLine.includes("tv") || lowerLine.includes("tertiary");
                    const hasPlus = lowerLine.includes("+");
                    const hasParens = lowerLine.includes("(") && lowerLine.includes(")");

                    const isCombinedPair = hasPlus && hasParens && (hasHV || hasLV);
                    const isMainPair = hasHV && hasLV && !hasTV && !hasPlus;
                    const isTertiaryPair = (lowerLine.includes("tv to") || lowerLine.includes("to tv"));

                    // Priority 4: Combined Impedance (e.g. HV to (LV+TV))
                    if (isCombinedPair) {
                        data.impedance.percentZ = potentialZStr;
                        impedancePriorityFound = 4;
                    }
                    // Priority 3: Pure HV-LV pair (only if Combined not found yet)
                    else if (impedancePriorityFound < 4 && isMainPair) {
                        data.impedance.percentZ = potentialZStr;
                        impedancePriorityFound = 3;
                    }
                    // Priority 2: Tertiary pairs (only if main/combined not found yet)
                    else if (impedancePriorityFound < 3 && isTertiaryPair) {
                        data.impedance.percentZ = potentialZStr;
                        impedancePriorityFound = 2;
                    }
                    // Priority 1: Fallback (any valid row if nothing better found)
                    else if (impedancePriorityFound === 0) {
                        data.impedance.percentZ = potentialZStr;
                        impedancePriorityFound = 1;
                    }
                }
            }
        }

        // NLL Exp Extraction
        // Look for "Exp=" pattern
        if (lowerLine.includes("exp=") || lowerLine.includes("exp =")) {
            const expMatch = textLine.match(/Exp\s*=\s*(\d+)/i);
            if (expMatch && !data.nllExp) {
                // We take the first match, which in standard format (NLL | Load Loss) corresponds to NLL
                data.nllExp = expMatch[1];
            }
        }

        // Bracket & KeepBack Extraction
        if (lowerLine.includes("wdgspace") && lowerLine.includes("totop")) {
            // WdgSpace/toTop/BotYoke 59.25 / 4.625 / 2.375
            // Update: Capturing first value as wdgSpace
            const match = textLine.match(/([\d\.]+)\s*\/\s*([\d\.]+)\s*\/\s*([\d\.]+)/);
            if (match) {
                data.brackets.wdgSpace = parseFloat(match[1]);
                data.brackets.top = parseFloat(match[2]);
                data.brackets.bottom = parseFloat(match[3]);
            }
        }

        if (lowerLine.includes("keepback")) {
            // KeepBack 4 4
            const kbNums = getRowNumbers(items);
            if (kbNums.length > 0) {
                // Determine which value corresponds to the outermost winding
                // Assuming order corresponds to windings: Wdg1, Wdg2, Wdg3...
                const outerIndex = detectedCount - 1;
                if (kbNums[outerIndex] !== undefined) {
                    data.keepBack = kbNums[outerIndex];
                } else {
                    data.keepBack = kbNums[kbNums.length - 1]; // Fallback to last
                }
            }
        }

        // 1. PRIMARY ANCHOR: "Total ->"
        if (lowerLine.includes("total") && (lowerLine.includes("->") || lowerLine.includes(">")) && !lowerLine.includes("=")) {
            const hasBigNumber = items.some(i => parseFloat(i.str.replace(/,/g, '')) > 1000);
            if (hasBigNumber) {
                totalRowIndex = idx;

                const totalItem = items.find(i => i.str.toLowerCase().includes("total"));
                if (totalItem) totalRowX = totalItem.x;

                const weightNums = items.filter(i => i.str.match(/^\d+$/) && parseFloat(i.str) > 1000).sort((a, b) => b.x - a.x);
                if (weightNums.length) data.core.weight = weightNums[0].str;
            }
        }

        // --- TUBE DETAILS ---
        const rightSideItems = items.filter(i => i.x > 270);
        rightSideItems.sort((a, b) => a.x - b.x);
        const rightLine = rightSideItems.map(i => i.str).join(' ').trim();
        const rightLineLower = rightLine.toLowerCase();

        if (rightLineLower.match(/(core tube|major|cover).*details/)) {
            if (currentTubeTable) { data.tubeTables.push(currentTubeTable); }
            
            // STRICT NAMING CLEANUP
            let cleanTitle = rightLine.trim();
            if (rightLineLower.includes("cover details")) cleanTitle = "Cover Details";
            else if (rightLineLower.includes("major 1 details")) cleanTitle = "Major 1 Details";
            else if (rightLineLower.includes("major 2 details")) cleanTitle = "Major 2 Details";
            else if (rightLineLower.includes("core tube details")) cleanTitle = "Core Tube Details";
            else if (rightLineLower.includes("major details")) cleanTitle = "Major Details";

            currentTubeTable = { title: cleanTitle, rows: [] };
        } else if (currentTubeTable) {
            if (rightLineLower.match(/total\s*=/) || (rightLineLower.startsWith("total") && !rightLineLower.includes("->"))) {
                data.tubeTables.push(currentTubeTable);
                currentTubeTable = null;
            }
            else if (rightLineLower.match(/material\s+thk\s+qty/)) { }
            else {
                const rowMatch = rightLine.match(/(.*?)\s+(\d*\.?\d+)\s+(\d+)\s*$/);
                if (rowMatch) {
                    let material = rowMatch[1].trim();
                    material = material.replace(/^[\d\s\.]+/, '');
                    material = material.replace(/width\s+ht\s+area/i, '').trim();
                    if (material.length > 1) {
                        currentTubeTable.rows.push({ material: material, thk: rowMatch[2], qty: rowMatch[3] });
                    }
                }
            }
        }

        // Field extraction
        const extractField = (regex: RegExp) => { const match = textLine.match(regex); return match ? match[1] : null; };
        if (!data.core.fluxDen) data.core.fluxDen = extractField(/Flux Den\(T\)\s*=\s*([\d\.]+)/i);
        if (!data.core.feCircle) data.core.feCircle = extractField(/Fe Circle\s*=\s*([\d\.]+)/i);
        if (!data.core.windowHt) data.core.windowHt = extractField(/Window Ht\s*=\s*([\d\.]+)/i);
        if (!data.core.windowWidth) data.core.windowWidth = extractField(/Window Width\s*=\s*([\d\.]+)/i);
        if (!data.core.legCenter) data.core.legCenter = extractField(/Leg Center\s*=\s*([\d\.]+)/i);
        if (!data.core.coreLength) data.core.coreLength = extractField(/Core Length\s*=\s*([\d\.]+)/i);
        if (lowerLine.includes("lg") && lowerLine.includes("ht") && lowerLine.includes("=")) {
            const htMatch = textLine.match(/[\d\.]+\s*[xX]\s*([\d\.]+)/);
            if (htMatch) data.core.coreHt = htMatch[1];
        }

        // Tank Clearances & Dimensions
        if (lowerLine.includes("right") && lowerLine.includes("left")) {
            const rightMatch = textLine.match(/Right\s*=\s*([\d\.]+)/i);
            const leftMatch = textLine.match(/Left\s*=\s*([\d\.]+)/i);
            if (rightMatch) data.tank.clearanceRight = rightMatch[1];
            if (leftMatch) data.tank.clearanceLeft = leftMatch[1];
        }
        if (lowerLine.includes("front") && lowerLine.includes("back")) {
            const frontMatch = textLine.match(/Front\s*=\s*([\d\.]+)/i);
            const backMatch = textLine.match(/Back\s*=\s*([\d\.]+)/i);
            if (frontMatch) data.tank.clearanceFront = frontMatch[1];
            if (backMatch) data.tank.clearanceBack = backMatch[1];
        }

        // Tank Dims - Robust Check
        if (lowerLine.includes("tank w") || lowerLine.includes("tank w x d")) {
            const dimMatch = textLine.match(/(\d+\.?\d*)\s*X\s*(\d+\.?\d*)\s*X\s*(\d+\.?\d*)/i);
            if (dimMatch) {
                data.tank.width = dimMatch[1];
                data.tank.depth = dimMatch[2];
                data.tank.height = dimMatch[3];
            } else {
                for (let j = 1; j <= 2; j++) {
                    const nextRow = processedRows[idx + j];
                    if (nextRow) {
                        const nextMatch = nextRow.textLine.match(/(\d+\.?\d*)\s*X\s*(\d+\.?\d*)\s*X\s*(\d+\.?\d*)/i);
                        if (nextMatch) {
                            data.tank.width = nextMatch[1];
                            data.tank.depth = nextMatch[2];
                            data.tank.height = nextMatch[3];
                            break;
                        }
                    }
                }
            }
        } else {
            const prevRow = processedRows[idx - 1];
            if (prevRow && (prevRow.lowerLine.includes("tank w"))) {
                const dimMatch = textLine.match(/(\d+\.?\d*)\s*X\s*(\d+\.?\d*)\s*X\s*(\d+\.?\d*)/i);
                if (dimMatch && !data.tank.width) {
                    data.tank.width = dimMatch[1];
                    data.tank.depth = dimMatch[2];
                    data.tank.height = dimMatch[3];
                }
            }
        }

        // Winding data extraction
        // Use Spatial mapping for robust assignment
        if (lowerLine.includes("rated turns")) {
            const mapped = extractColumnarValues(items, wdgXPositions);
            if (mapped[0]) data.wdg1.ratedTurns = roundVal(parseFloat(mapped[0]));
            if (mapped[1]) data.wdg2.ratedTurns = roundVal(parseFloat(mapped[1]));
            if (mapped[2]) data.wdg3.ratedTurns = roundVal(parseFloat(mapped[2]));
        }

        if (lowerLine.includes("maximum turns")) {
            const mapped = extractColumnarValues(items, wdgXPositions);
            if (detectedCount === 3) {
                if (mapped[2]) data.wdg3.maxTurns = roundVal(parseFloat(mapped[2]));
            } else {
                if (mapped[1]) data.wdg2.maxTurns = roundVal(parseFloat(mapped[1]));
            }
        }

        if (lowerLine.includes("minimum turns")) {
            const mapped = extractColumnarValues(items, wdgXPositions);
            if (detectedCount === 3) {
                if (mapped[2]) data.wdg3.minTurns = roundVal(parseFloat(mapped[2]));
            } else {
                if (mapped[1]) data.wdg2.minTurns = roundVal(parseFloat(mapped[1]));
            }
        }

        if (lowerLine.includes("rated coil amps")) {
            const mapped = extractColumnarValues(items, wdgXPositions);
            if (mapped[0]) data.wdg1.ratedAmps = mapped[0];
            if (mapped[1]) data.wdg2.ratedAmps = mapped[1];
            if (mapped[2]) data.wdg3.ratedAmps = mapped[2];
        }

        if (lowerLine.includes("wire space") || lowerLine.includes("winding ht")) {
            const mapped = extractColumnarValues(items, wdgXPositions);
            if (mapped[0]) data.wdg1.wireSpaceMech = mapped[0];
            if (mapped[1]) data.wdg2.wireSpaceMech = mapped[1];
            if (mapped[2]) data.wdg3.wireSpaceMech = mapped[2];
        }

        // Extract Design ElecHt values (e.g., "ElecHt 40.012 41.958 41.981")
        if (lowerLine.includes("elecht") || (lowerLine.includes("elec") && lowerLine.includes("ht") && !lowerLine.includes("winding"))) {
            // Try to extract all numbers that look like heights (between 10 and 100)
            const elecHtNums = nums.filter(n => n >= 10 && n <= 100);
            if (elecHtNums.length >= 3) {
                data.designElecHt = elecHtNums.slice(0, 3);
                debugLog.push(`[DESIGN ELECHT] Found ${elecHtNums.length} values: ${elecHtNums.join(', ')}`);
            } else if (elecHtNums.length > 0) {
                data.designElecHt = elecHtNums;
                debugLog.push(`[DESIGN ELECHT] Found ${elecHtNums.length} values: ${elecHtNums.join(', ')}`);
            }
        }

        // Extract "Add #OfKS/Col/Grp" value(s) - can have multiple values (inner and outmost)
        if (lowerLine.includes("add") && (lowerLine.includes("ks") || lowerLine.includes("k/s")) && (lowerLine.includes("col") || lowerLine.includes("grp"))) {
            // Initialize if not exists
            if (!data.addKSPerWinding) {
                data.addKSPerWinding = {};
            }

            // Extract all numbers from the line - could be "Add #OfKS/Col/Grp: 28 12" or "Add #OfKS/Col/Grp 28 12"
            const allNums = nums.filter(n => n >= 0); // Filter valid numbers

            if (allNums.length >= detectedCount) {
                // We have exactly one value per winding - assign directly
                // For 3 windings with values [30, 30, 7]: store as {1: 30, 2: 30, 3: 7}
                for (let i = 0; i < detectedCount; i++) {
                    data.addKSPerWinding[i + 1] = allNums[i]; // Store with winding NUMBER (1, 2, 3)
                }
                // Also set legacy addKSColGrp for backward compatibility (use outmost value)
                data.addKSColGrp = allNums[detectedCount - 1];
                debugLog.push(`[ADD KS COL GRP] Extracted ${detectedCount} values: ${allNums.slice(0, detectedCount).join(', ')} from "${textLine}"`);
            }
            else if (allNums.length >= 2) {
                // Two values: first is for inner winding(s), second is for outmost winding
                // For 3 windings: indices 0,1 are inner, 2 is outmost
                // For 2 windings: index 0 is inner, 1 is outmost
                const innerValue = allNums[0]; // First value for inner winding
                const outmostValue = allNums[1]; // Second value for outmost winding

                // Assign to inner windings (all except the last one)
                const innerWindingCount = detectedCount - 1;
                for (let i = 0; i < innerWindingCount; i++) {
                    data.addKSPerWinding[i + 1] = innerValue; // Store with winding NUMBER (1, 2, ...)
                }
                // Assign to outmost winding (last one)
                if (detectedCount > 0) {
                    data.addKSPerWinding[detectedCount] = outmostValue; // Store with winding NUMBER
                }

                // Also set legacy addKSColGrp for backward compatibility (use outmost value)
                data.addKSColGrp = outmostValue;

                debugLog.push(`[ADD KS COL GRP] Extracted per-winding: Inner=${innerValue}, Outmost=${outmostValue} from "${textLine}"`);
            } else if (allNums.length === 1) {
                // Single value: assign to all windings (backward compatibility)
                const addKSValue = allNums[0];
                for (let i = 0; i < detectedCount; i++) {
                    data.addKSPerWinding[i + 1] = addKSValue; // Store with winding NUMBER
                }
                data.addKSColGrp = addKSValue;
                debugLog.push(`[ADD KS COL GRP] Extracted single value: ${addKSValue} from "${textLine}"`);
            } else {
                // Try regex match as fallback
                const numMatch = textLine.match(/(?:add\s*#?of\s*ks\/?col\/?grp[:\s]*)?(\d+\.?\d*)(?:\s+(\d+\.?\d*))?/i);
                if (numMatch) {
                    if (numMatch[2]) {
                        // Two values found
                        const innerValue = parseFloat(numMatch[1]);
                        const outmostValue = parseFloat(numMatch[2]);
                        if (!isNaN(innerValue) && !isNaN(outmostValue)) {
                            const innerWindingCount = detectedCount - 1;
                            for (let i = 0; i < innerWindingCount; i++) {
                                data.addKSPerWinding[i + 1] = innerValue; // Store with winding NUMBER
                            }
                            if (detectedCount > 0) {
                                data.addKSPerWinding[detectedCount] = outmostValue; // Store with winding NUMBER
                            }
                            data.addKSColGrp = outmostValue;
                            debugLog.push(`[ADD KS COL GRP] Extracted via regex: Inner=${innerValue}, Outmost=${outmostValue}`);
                        }
                    } else if (numMatch[1]) {
                        // Single value
                        const addKSValue = parseFloat(numMatch[1]);
                        if (!isNaN(addKSValue)) {
                            for (let i = 0; i < detectedCount; i++) {
                                data.addKSPerWinding[i + 1] = addKSValue; // Store with winding NUMBER
                            }
                            data.addKSColGrp = addKSValue;
                            debugLog.push(`[ADD KS COL GRP] Extracted via regex: ${addKSValue}`);
                        }
                    }
                }
            }
        }

        if (lowerLine.includes("type of wdg")) {
            const textItems = items.filter(i => !isNaN(parseFloat(i.str)) === false && i.str.length > 1);
            // Can't easily use columnar extract for text, rely on simple filter
            const words = textItems.map(i => i.str.trim());
            if (detectedCount === 3 && words.length >= 3) { data.wdg1.type = words[0]; data.wdg2.type = words[1]; data.wdg3.type = words[2]; }
            else if (words.length >= 2) { data.wdg1.type = words[0]; data.wdg2.type = words[1]; }
        }
        if (lowerLine.includes("trns/lyr") && nums.length >= 2) { data.wdg1.discVal = roundVal(nums[0]); data.wdg2.discVal = roundVal(nums[1]); if (nums.length > 2) data.wdg3.discVal = roundVal(nums[2]); }
        if (lowerLine.includes("trns/disc") && nums.length >= 2) { data.wdg1.lyrsVal = nums[0]; data.wdg2.lyrsVal = nums[1]; if (nums.length > 2) data.wdg3.lyrsVal = nums[2]; }
        if (lowerLine.includes("total paper") && nums.length >= 2) { data.wdg1.paperInsul = nums[0]; data.wdg2.paperInsul = nums[1]; if (nums.length > 2) data.wdg3.paperInsul = nums[2]; }
        if (lowerLine.includes("bare cond thk") && nums.length >= 2) { data.wdg1.bareThk = nums[0]; data.wdg2.bareThk = nums[1]; if (nums.length > 2) data.wdg3.bareThk = nums[2]; }
        if (lowerLine.includes("bare cond width") && nums.length >= 2) {
            data.wdg1.bareWidth = nums[0];
            data.wdg2.bareWidth = nums[1];
            if (nums.length > 2) data.wdg3.bareWidth = nums[2];
            debugLog.push(`[BARE WIDTH] Extracted: W1=${nums[0]}, W2=${nums[1]}, W3=${nums[2] || 'N/A'} from "${textLine}"`);
        }

        // Radial Build: Use Spatial if possible, else fallback
        if (lowerLine.includes("radial build")) {
            const mapped = extractColumnarValues(items, wdgXPositions);
            if (mapped.some(v => v !== null)) {
                if (mapped[0]) data.wdg1.radial = mapped[0];
                if (mapped[1]) data.wdg2.radial = mapped[1];
                if (mapped[2]) data.wdg3.radial = mapped[2];
            } else if (nums.length >= 2) {
                data.wdg1.radial = nums[0]; data.wdg2.radial = nums[1]; if (nums.length > 2) data.wdg3.radial = nums[2];
            }
        }

        if (lowerLine.includes("i2r loss") || lowerLine.includes("12r loss")) {
            // Cut off potential next table headers on the same line to avoid grabbing wrong numbers
            let cleanLine = textLine;
            // Common delimiters for subsequent tables on the same line
            const delimiters = ["tv to", "hv to", "lv to", "terminal pair"];
            const lowerClean = cleanLine.toLowerCase();

            let cutoffIndex = -1;
            for (const d of delimiters) {
                const idx = lowerClean.indexOf(d);
                if (idx !== -1 && (cutoffIndex === -1 || idx < cutoffIndex)) {
                    cutoffIndex = idx;
                }
            }

            if (cutoffIndex !== -1) {
                cleanLine = cleanLine.substring(0, cutoffIndex);
            }

            const rawLosses = cleanLine.replace(/i2r loss/gi, '').replace(/12r loss/gi, '').trim();
            const parts = rawLosses.split(/[\s\/]+/).filter(p => !isNaN(parseFloat(p)) && parseFloat(p) > 10);

            if (parts.length > 0) {
                if (detectedCount === 3) {
                    if (parts.length >= 4) {
                        data.wdg1.i2r = `${parts[0]}/${parts[1]}`; data.wdg2.i2r = parts[2]; data.wdg3.i2r = parts[3];
                    }
                    else if (parts.length === 3) {
                        data.wdg1.i2r = parts[0]; data.wdg2.i2r = parts[1]; data.wdg3.i2r = parts[2];
                    } else if (parts.length >= 1) {
                        data.wdg1.i2r = parts[0];
                        if (parts.length > 1) data.wdg2.i2r = parts[1];
                        if (parts.length > 2) data.wdg3.i2r = parts[2];
                    }
                } else {
                    if (parts.length >= 2) {
                        data.wdg1.i2r = parts[0]; data.wdg2.i2r = parts[1];
                    } else if (parts.length >= 1) {
                        data.wdg1.i2r = parts[0];
                    }
                }
            }
        }

        // ID / OD use spatial mapping
        if (lowerLine.match(/^i\.?\s*d\.?/)) {
            const mapped = extractColumnarValues(items, wdgXPositions);
            if (mapped[0]) data.wdg1.id = parseFloat(mapped[0]);
            if (mapped[1]) data.wdg2.id = parseFloat(mapped[1]);
            if (mapped[2]) data.wdg3.id = parseFloat(mapped[2]);
            // Fallback
            if (!mapped.some(v => v)) { if (nums.length >= 2) { data.wdg1.id = nums[0]; data.wdg2.id = nums[1]; if (nums.length > 2) data.wdg3.id = nums[2]; } }
        }
        if (lowerLine.match(/^o\.?\s*d\.?/)) {
            const mapped = extractColumnarValues(items, wdgXPositions);
            if (mapped[0]) data.wdg1.od = parseFloat(mapped[0]);
            if (mapped[1]) data.wdg2.od = parseFloat(mapped[1]);
            if (mapped[2]) data.wdg3.od = parseFloat(mapped[2]);
            // Fallback
            if (!mapped.some(v => v)) { if (nums.length >= 2) { data.wdg1.od = nums[0]; data.wdg2.od = nums[1]; if (nums.length > 2) data.wdg3.od = nums[2]; } }
        }
        if (lowerLine.includes("mean turn")) {
            const mapped = extractColumnarValues(items, wdgXPositions);
            if (mapped[0]) data.wdg1.meanTurn = parseFloat(mapped[0]);
            if (mapped[1]) data.wdg2.meanTurn = parseFloat(mapped[1]);
            if (mapped[2]) data.wdg3.meanTurn = parseFloat(mapped[2]);
            if (!mapped.some(v => v)) { if (nums.length >= 2) { data.wdg1.meanTurn = nums[0]; data.wdg2.meanTurn = nums[1]; if (nums.length > 2) data.wdg3.meanTurn = nums[2]; } }
        }

        if (lowerLine.includes("ks/circle")) {
            const ksMatches = items.filter(i => i.str.match(/\d+\.?\d*\s*\/\s*\d+\.?\d*/));
            // Ensure strict Left-to-Right order for accurate mapping
            ksMatches.sort((a, b) => a.x - b.x);

            const parsedKS = ksMatches.map(i => { const parts = i.str.split('/'); return { circle: parseFloat(parts[0]), width: parseFloat(parts[1]) }; });

            if (parsedKS.length > 0) {
                if (detectedCount === 3 && parsedKS.length === 2) {
                    // 3 Windings detected but only 2 KS values found -> Assign to W2 & W3 (Assumption: Inner wdg might not have KS or spatial missed)
                    // Try spatial?
                    // Spatial Check:
                    const ksItems = ksMatches;
                    let assigned = false;
                    // Only use spatial if we have column centers
                    if (wdgXPositions.every(c => c > 0)) {
                        ksItems.forEach((kItem, kIdx) => {
                            const center = kItem.x + kItem.w / 2;
                            // Check which it belongs to
                            let best = -1;
                            let minDist = 80;
                            wdgXPositions.forEach((pos, posIdx) => {
                                const d = Math.abs(center - pos);
                                if (d < minDist) { minDist = d; best = posIdx; }
                            });
                            if (best === 0) { data.wdg1.ksCircle = parsedKS[kIdx].circle; data.wdg1.ksWidth = parsedKS[kIdx].width; assigned = true; }
                            if (best === 1) { data.wdg2.ksCircle = parsedKS[kIdx].circle; data.wdg2.ksWidth = parsedKS[kIdx].width; assigned = true; }
                            if (best === 2) { data.wdg3.ksCircle = parsedKS[kIdx].circle; data.wdg3.ksWidth = parsedKS[kIdx].width; assigned = true; }
                        });
                    }

                    if (!assigned) {
                        debugLog.push(`[KS/Circle] 3 Windings, 2 Values -> Shifting to W2/W3 Fallback`);
                        data.wdg2.ksCircle = parsedKS[0].circle; data.wdg2.ksWidth = parsedKS[0].width;
                        data.wdg3.ksCircle = parsedKS[1].circle; data.wdg3.ksWidth = parsedKS[1].width;
                    }
                } else {
                    // Standard Assignment
                    if (parsedKS.length >= 1) { data.wdg1.ksCircle = parsedKS[0].circle; data.wdg1.ksWidth = parsedKS[0].width; }
                    if (parsedKS.length >= 2) { data.wdg2.ksCircle = parsedKS[1].circle; data.wdg2.ksWidth = parsedKS[1].width; }
                    if (parsedKS.length >= 3) { data.wdg3.ksCircle = parsedKS[2].circle; data.wdg3.ksWidth = parsedKS[2].width; }
                }
            }
        }

        if (lowerLine.includes("ks thk") || lowerLine.includes("btwn disc")) {
            const valueRegex = /(\d+\.?\d*\s*\/\s*\d+)/g;
            const matches = [...textLine.matchAll(valueRegex)].map(m => m[0]);

            if (matches.length > 0) {
                if (detectedCount === 3 && matches.length === 2) {
                    data.wdg2.ksThk = matches[0];
                    data.wdg3.ksThk = matches[1];
                } else {
                    ['wdg1', 'wdg2', 'wdg3'].slice(0, detectedCount).forEach((k, idx) => {
                        if (matches[idx]) {
                            data[k].ksThk = matches[idx];
                        }
                    });
                }
            }
        }

        if (lowerLine.includes("pulls")) {
            const pullMatches = items.filter(i => i.str.match(/\d+\s*X\s*\d+/)).sort((a, b) => a.x - b.x);
            const parsePulls = (str: string) => {
                const cleanStr = str.replace(/^[^\d]+/, '');
                const parts = cleanStr.toUpperCase().split('X').map(s => s.trim());
                return { w: parts[0] || '-', h: parts[1] || '-', s: parts.length > 2 ? parts[2] : '-' };
            };
            if (pullMatches.length > 0) {
                ['wdg1', 'wdg2', 'wdg3'].slice(0, detectedCount).forEach((k, idx) => {
                    if (pullMatches[idx]) {
                        const p = parsePulls(pullMatches[idx].str);
                        data[k].pullsW = p.w;
                        data[k].pullsH = p.h;
                        data[k].strands = p.s;
                    }
                });
            }
        }
        if (lowerLine.includes("watts/in")) {
            const wMatches = items.filter(i => i.str.match(/\d+\.?\d*\s*\/\s*\d+\.?\d*/)).sort((a, b) => a.x - b.x);
            const mapWatts = (str: string) => { const p = str.split('/'); return { oa: p[0], max: p[1] }; };
            if (wMatches.length > 0) { ['wdg1', 'wdg2', 'wdg3'].slice(0, detectedCount).forEach((k, idx) => { if (wMatches[idx]) { const v = mapWatts(wMatches[idx].str); data[k].wattsOA = v.oa; data[k].wattsMax = v.max; } }); }
        }

        if (lowerLine.includes("grad") || lowerLine.includes("gradient")) {
            const isSGrad = lowerLine.includes("s_grad") || lowerLine.includes("s_");
            const targetFieldOA = isSGrad ? 'sGradOA' : 'gradOA';
            const targetFieldMax = isSGrad ? 'sGradMax' : 'gradMax';

            const slashRegex = /([\d\.]+)\s*\/\s*([\d\.]+)/g;
            let findings: any[] = [];

            const slashMatches = [...textLine.matchAll(slashRegex)];
            if (slashMatches.length > 0) {
                findings = slashMatches.map(m => ({ oa: m[1], max: m[2] }));
            }
            else {
                const codeMatches = items.filter(i => i.str.match(/^\d{8}$/)).sort((a, b) => a.x - b.x);
                findings = codeMatches.map(i => ({ oa: i.str.substring(0, 4), max: i.str.substring(4, 8) }));
            }

            if (findings.length > 0) {
                if (detectedCount === 3 && findings.length === 2) {
                    data.wdg2[targetFieldOA] = findings[0].oa; data.wdg2[targetFieldMax] = findings[0].max;
                    data.wdg3[targetFieldOA] = findings[1].oa; data.wdg3[targetFieldMax] = findings[1].max;
                } else {
                    ['wdg1', 'wdg2', 'wdg3'].slice(0, detectedCount).forEach((k, idx) => {
                        if (findings[idx]) {
                            data[k][targetFieldOA] = findings[idx].oa;
                            data[k][targetFieldMax] = findings[idx].max;
                        }
                    });
                }
            }
        }

        if (lowerLine.includes("wdg eddy/stray") || lowerLine.includes("stray")) {
            const lossMatches = items.filter(i => i.str.match(/\d+\s*\/\s*\d+/)).sort((a, b) => a.x - b.x);
            if (lossMatches.length >= 2) { data.wdg1.lossStr = lossMatches[0].str; data.wdg2.lossStr = lossMatches[1].str; if (lossMatches.length > 2) data.wdg3.lossStr = lossMatches[2].str; }
            else if (lossMatches.length >= 2) { data.wdg1.lossStr = lossMatches[0].str; data.wdg2.lossStr = lossMatches[1].str; }
        }
        if (lowerLine.includes("total loss in wdg") && nums.length >= 2) { data.wdg1.totalLoss = nums[0]; data.wdg2.totalLoss = nums[1]; if (nums.length > 2) data.wdg3.totalLoss = nums[2]; }

        if (lowerLine.includes("#of parallel grps") || lowerLine.includes("parallel grps")) {
            const grpNums = getRowNumbers(items);
            if (grpNums.length > 0) {
                if (detectedCount === 3 && grpNums.length >= 3) {
                    data.wdg1.parallelGroups = grpNums[0];
                    data.wdg2.parallelGroups = grpNums[1];
                    data.wdg3.parallelGroups = grpNums[2];
                } else if (grpNums.length >= 2) {
                    data.wdg1.parallelGroups = grpNums[0];
                    data.wdg2.parallelGroups = grpNums[1];
                }
            }
        }
    });

    if (currentTubeTable) { data.tubeTables.push(currentTubeTable); }

    if (totalRowIndex !== -1) {
        let collectedRows: CoreRow[] = [];
        debugLog.push("--- CORE TABLE EXTRACTION STARTED ---");

        let startX = 180;
        if (totalRowX > 0) {
            startX = totalRowX - 15;
        }
        const totalRowItems = processedRows[totalRowIndex].items;
        const totalRowNumbers = totalRowItems.filter(i => i.str.match(/[\d\.]+/));
        let endX = startX + 300;
        if (totalRowNumbers.length > 0) {
            endX = totalRowNumbers[totalRowNumbers.length - 1].x + 30;
        }

        debugLog.push(`[ZONE DEFINITION] Anchor 'Total' at X=${totalRowX.toFixed(2)}`);
        debugLog.push(`   Active Scan Zone: X=[${startX.toFixed(2)}, ${endX.toFixed(2)}]`);

        const totalVals = totalRowItems.filter(i => i.x >= startX && i.x <= endX && i.str.match(/[\d\.]+/));
        if (totalVals.length >= 3) {
            collectedRows.push({
                col1: 'Total',
                col2: totalVals[0].str,
                col3: totalVals[1].str,
                col4: totalVals[2].str,
                isTotal: true
            });
        }

        for (let i = totalRowIndex - 1; i >= 0; i--) {
            const row = processedRows[i];
            const { items } = row;
            const validItems = items.filter(itm => itm.x >= startX && itm.x <= endX).sort((a, b) => a.x - b.x);
            const validLine = validItems.map(itm => itm.str).join(' ').trim();
            const validLineLower = validLine.toLowerCase();

            if ((validLineLower.includes("width") && validLineLower.includes("ht")) || (validLineLower.includes("lam") && validLineLower.includes("stack"))) {
                debugLog.push(`[STOP] Header detected at Y=${row.y.toFixed(2)}: "${validLine}"`);
                break;
            }

            const rowNums = validItems.filter(itm => itm.str.match(/^[\d\.]+$/));
            if (rowNums.length >= 4) {
                debugLog.push(`[DATA] Row accepted at Y=${row.y.toFixed(2)}: "${validLine}" (4 nums)`);
                collectedRows.push({
                    col1: rowNums[0]?.str || '',
                    col2: rowNums[1]?.str || '',
                    col3: rowNums[2]?.str || '',
                    col4: rowNums[3]?.str || '',
                    isDuct: false
                });
            } else if (rowNums.length === 3) {
                debugLog.push(`[DATA] Row accepted at Y=${row.y.toFixed(2)}: "${validLine}" (3 nums - partial)`);
                collectedRows.push({
                    col1: rowNums[0]?.str || '',
                    col2: rowNums[1]?.str || '',
                    col3: rowNums[2]?.str || '',
                    col4: '',
                    isDuct: false
                });
            }
        }

        collectedRows.reverse();
        data.coreTable = collectedRows;

        const firstData = collectedRows.find(r => !r.isTotal);
        if (firstData) {
            data.core.lamWidth = firstData.col1;
        }
    }

    data.debugLog = debugLog;
    return { data, windingCount: detectedCount, windingNames: detectedNames };
};


import { WindingStats, ExtractedData } from '../types';

export const parseNum = (val: string | number | null): number => {
  if (!val || val === '-') return 0;
  const clean = String(val).replace(/[^\d.]/g, '');
  return parseFloat(clean) || 0;
};

export const calculateWindingDetails = (w: WindingStats) => {
  const rawStrands = parseNum(w.strands);
  const high = parseNum(w.pullsH);
  const wide = parseNum(w.pullsW);
  const turnsPerDisc = parseNum(w.lyrsVal); 

  const effectiveStrandsBase = rawStrands > 0 ? rawStrands : 1;
  const effectiveHigh = high > 0 ? high : 1;
  const effectiveWide = wide > 0 ? wide : 1;
  
  const calcStrands = effectiveStrandsBase * effectiveHigh * effectiveWide;

  const strandsPart = Math.ceil(effectiveStrandsBase / 2) * effectiveHigh;
  const turnsPart = Math.ceil(turnsPerDisc);
  const calcTotal = strandsPart * turnsPart;

  return {
    calcStrands: calcStrands,
    calcTotal: calcTotal,
    thk: w.bareThk || '-',
    width: w.bareWidth || '-'
  };
};

export const calculateTurnsDrop = (wdg: WindingStats): number | string => {
  if (!wdg) return '-';
  const valTrnsLyr = wdg.discVal;
  const valTrnsDisc = typeof wdg.lyrsVal === 'string' ? parseFloat(wdg.lyrsVal) : wdg.lyrsVal;
  
  if (valTrnsLyr == null || valTrnsDisc == null) return '-';
  
  const base = (wdg.maxTurns != null) ? wdg.maxTurns : wdg.ratedTurns;
  if (base == null) return '-';
  
  const result = (valTrnsLyr * Math.ceil(valTrnsDisc)) - base;
  return Number(result.toFixed(2));
};

export const calculateBayDrop = (wdg: WindingStats): number | string => {
  const turnsDrop = calculateTurnsDrop(wdg);
  if (turnsDrop === '-' || typeof turnsDrop !== 'number') return '-';
  if (!wdg.ksCircle || !wdg.meanTurn) return '-';
  const result = turnsDrop * (wdg.ksCircle / wdg.meanTurn);
  return Number(result.toFixed(4));
};

export const getBayDropColor = (val: number | string) => {
  if (val === '-' || typeof val !== 'number') return 'text-slate-700';
  return val > 2 ? 'text-emerald-600 font-extrabold' : 'text-rose-600 font-bold';
};

export const calculateKSFactor = (wdg: WindingStats): string | number => {
  if (!wdg || !wdg.ksCircle || !wdg.ksWidth || !wdg.meanTurn) return '-';
  const val = ((wdg.ksCircle * wdg.ksWidth) / wdg.meanTurn) * 100;
  return Number(val.toFixed(2)) + '%';
};

export const calculateIDSpaceFactor = (wdg: WindingStats): number | string => {
  if (!wdg || !wdg.id || !wdg.ksCircle || !wdg.ksWidth) return '-';
  const val = ((wdg.id * Math.PI) / wdg.ksCircle) - wdg.ksWidth;
  return Number(val.toFixed(4));
};

export const calculateODSpaceFactor = (wdg: WindingStats): number | string => {
  if (!wdg || !wdg.od || !wdg.ksCircle || !wdg.ksWidth) return '-';
  const val = ((wdg.od * Math.PI) / wdg.ksCircle) - wdg.ksWidth;
  return Number(val.toFixed(4));
};

export const getFactorColor = (val: number | string, target: number) => {
  if (val === '-' || typeof val !== 'number') return 'text-slate-700';
  const diff = Math.abs(val - target);
  if (diff <= 0.5) return 'text-emerald-600 font-extrabold';
  if (diff <= 1.0) return 'text-amber-600 font-bold';
  return 'text-rose-600 font-bold';
};

export const calculateTotalStrayEddy = (data: ExtractedData | null, count: number): number => {
  if (!data) return 0;
  let total = 0;
  ['wdg1', 'wdg2', 'wdg3'].slice(0, count).forEach(key => {
    const s = data[key].lossStr;
    if (s) {
      const parts = s.split('/').map(v => parseFloat(v) || 0);
      total += parts.reduce((a, b) => a + b, 0);
    }
  });
  return total;
};

export const calculateGrandTotalLoss = (data: ExtractedData | null, count: number): number => {
  if (!data) return 0;
  let total = 0;
  ['wdg1', 'wdg2', 'wdg3'].slice(0, count).forEach(key => {
    const loss = parseFloat(String(data[key].totalLoss)) || 0;
    total += loss;
  });
  return total;
};

export const calculateLossFactor = (data: ExtractedData | null, count: number): string | '-' => {
  const strayEddy = calculateTotalStrayEddy(data, count);
  const totalLoss = calculateGrandTotalLoss(data, count);
  if (totalLoss === 0) return '-';
  const factor = (strayEddy / totalLoss) * 100;
  return factor.toFixed(2) + '%';
};

export const calculateTotalI2R = (data: ExtractedData | null, count: number): number => {
  if (!data) return 0;
  let total = 0;
  ['wdg1', 'wdg2', 'wdg3'].slice(0, count).forEach(key => {
    const val = data[key].i2r;
    if (val && typeof val === 'string') {
      const parts = val.split(/[\s\/]+/).map(v => parseFloat(v) || 0);
      const sum = parts.reduce((a, b) => a + b, 0);
      total += sum;
    } else if (typeof val === 'number') {
      total += val;
    }
  });
  return total;
};

export const calculateStrayI2RFactor = (data: ExtractedData | null, count: number): string | '-' => {
  const stray = calculateTotalStrayEddy(data, count);
  const i2r = calculateTotalI2R(data, count);
  if (i2r === 0) return '-';
  const ratio = (stray / i2r) * 100;
  return ratio.toFixed(2) + '%';
};

export const getLossAdditionString = (data: ExtractedData | null, count: number, type: 'total' | 'stray'): string => {
  if (!data) return '';
  const parts: any[] = [];
  ['wdg1', 'wdg2', 'wdg3'].slice(0, count).forEach(key => {
    if (type === 'total') {
      const loss = data[key].totalLoss;
      if (loss) parts.push(loss);
    } else if (type === 'stray') {
      const s = data[key].lossStr;
      if (s) {
        parts.push(s.replace(/\//g, '+'));
      }
    }
  });
  return parts.join('+');
};

export const getI2RDisplayString = (data: ExtractedData | null, count: number): string => {
  if (!data) return '';
  const parts: string[] = [];
  ['wdg1', 'wdg2', 'wdg3'].slice(0, count).forEach(key => {
    const val = data[key].i2r;
    if (val) {
        // Normalize slashes to + for display
        parts.push(String(val).replace(/\//g, '+'));
    }
  });
  return parts.join('+');
};

export interface I2RComponent {
    value: number;
    label: string;
    id: string;
}

export const getI2RComponents = (data: ExtractedData | null, count: number): I2RComponent[] => {
    if (!data) return [];
    const components: I2RComponent[] = [];
    ['wdg1', 'wdg2', 'wdg3'].slice(0, count).forEach((key, idx) => {
        const val = data[key].i2r;
        const wdgName = `W${idx + 1}`;
        if (val && typeof val === 'string') {
            const parts = val.split(/[\s\/]+/).map(v => parseFloat(v) || 0);
            parts.forEach((p, pIdx) => {
                if (p > 0) {
                    components.push({
                        value: p,
                        label: parts.length > 1 ? `${wdgName}` : wdgName, // Simplification: just W1 unless we want W1-1, W1-2
                        id: `${key}-${pIdx}`
                    });
                }
            });
        } else if (typeof val === 'number' && val > 0) {
             components.push({ value: val, label: wdgName, id: `${key}-0` });
        }
    });
    return components;
};
